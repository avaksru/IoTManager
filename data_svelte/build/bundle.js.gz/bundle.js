!(function () {
  function t() { }
  function e(t) {
    return t();
  }
  function n() {
    return Object.create(null);
  }
  function s(t) {
    t.forEach(e);
  }
  function r(t) {
    return "function" == typeof t;
  }
  function o(t, e) {
    return t != t
      ? e == e
      : t !== e || (t && "object" == typeof t) || "function" == typeof t;
  }
  let l;
  function i(t, e) {
    return l || (l = document.createElement("a")), (l.href = e), t === l.href;
  }
  function c(e, ...n) {
    if (null == e) return t;
    const s = e.subscribe(...n);
    return s.unsubscribe ? () => s.unsubscribe() : s;
  }
  function a(t, e, n) {
    t.$$.on_destroy.push(c(e, n));
  }
  function u(t, e, n, s) {
    if (t) {
      const r = d(t, e, n, s);
      return t[0](r);
    }
  }
  function d(t, e, n, s) {
    return t[1] && s
      ? (function (t, e) {
        for (const n in e) t[n] = e[n];
        return t;
      })(n.ctx.slice(), t[1](s(e)))
      : n.ctx;
  }
  function f(t, e, n, s) {
    if (t[2] && s) {
      const r = t[2](s(n));
      if (void 0 === e.dirty) return r;
      if ("object" == typeof r) {
        const t = [],
          n = Math.max(e.dirty.length, r.length);
        for (let s = 0; s < n; s += 1) t[s] = e.dirty[s] | r[s];
        return t;
      }
      return e.dirty | r;
    }
    return e.dirty;
  }
  function p(t, e, n, s, r, o) {
    if (r) {
      const l = d(e, n, s, o);
      t.p(l, r);
    }
  }
  function g(t) {
    if (t.ctx.length > 32) {
      const e = [],
        n = t.ctx.length / 32;
      for (let t = 0; t < n; t++) e[t] = -1;
      return e;
    }
    return -1;
  }
  const h =
    "undefined" != typeof window
      ? window
      : "undefined" != typeof globalThis
        ? globalThis
        : global;
  function m(t, e) {
    t.appendChild(e);
  }
  function b(t, e, n) {
    t.insertBefore(e, n || null);
  }
  function x(t) {
    t.parentNode && t.parentNode.removeChild(t);
  }
  function v(t, e) {
    for (let n = 0; n < t.length; n += 1) t[n] && t[n].d(e);
  }
  function $(t) {
    return document.createElement(t);
  }
  function w(t) {
    return document.createElementNS("http://www.w3.org/2000/svg", t);
  }
  function y(t) {
    return document.createTextNode(t);
  }
  function k() {
    return y(" ");
  }
  function _() {
    return y("");
  }
  function j(t, e, n, s) {
    return t.addEventListener(e, n, s), () => t.removeEventListener(e, n, s);
  }
  function C(t) {
    return function (e) {
      return e.preventDefault(), t.call(this, e);
    };
  }
  function L(t, e, n) {
    null == n
      ? t.removeAttribute(e)
      : t.getAttribute(e) !== n && t.setAttribute(e, n);
  }
  function S(t) {
    return "" === t ? null : +t;
  }
  function M(t, e) {
    (e = "" + e), t.data !== e && (t.data = e);
  }
  function T(t, e) {
    t.value = e ?? "";
  }
  function J(t, e, n, s) {
    null == n
      ? t.style.removeProperty(e)
      : t.style.setProperty(e, n, s ? "important" : "");
  }
  function O(t, e, n) {
    for (let n = 0; n < t.options.length; n += 1) {
      const s = t.options[n];
      if (s.__value === e) return void (s.selected = !0);
    }
    (n && void 0 === e) || (t.selectedIndex = -1);
  }
  function E(t) {
    const e = t.querySelector(":checked");
    return e && e.__value;
  }
  let N;
  function P(t) {
    N = t;
  }
  function D() {
    if (!N) throw new Error("Function called outside component initialization");
    return N;
  }
  function H(t) {
    D().$$.on_mount.push(t);
  }
  function A(t) {
    return D().$$.context.get(t);
  }
  function I(t, e) {
    const n = t.$$.callbacks[e.type];
    n && n.slice().forEach((t) => t.call(this, e));
  }
  const q = [],
    z = [];
  let B = [];
  const R = [],
    F = Promise.resolve();
  let Z = !1;
  function W() {
    Z || ((Z = !0), F.then(G));
  }
  function U(t) {
    B.push(t);
  }
  function Y(t) {
    R.push(t);
  }
  const V = new Set();
  let X = 0;
  function G() {
    if (0 !== X) return;
    const t = N;
    do {
      try {
        for (; X < q.length;) {
          const t = q[X];
          X++, P(t), K(t.$$);
        }
      } catch (t) {
        throw ((q.length = 0), (X = 0), t);
      }
      for (P(null), q.length = 0, X = 0; z.length;) z.pop()();
      for (let t = 0; t < B.length; t += 1) {
        const e = B[t];
        V.has(e) || (V.add(e), e());
      }
      B.length = 0;
    } while (q.length);
    for (; R.length;) R.pop()();
    (Z = !1), V.clear(), P(t);
  }
  function K(t) {
    if (null !== t.fragment) {
      t.update(), s(t.before_update);
      const e = t.dirty;
      (t.dirty = [-1]),
        t.fragment && t.fragment.p(t.ctx, e),
        t.after_update.forEach(U);
    }
  }
  const Q = new Set();
  let tt;
  function et() {
    tt = { r: 0, c: [], p: tt };
  }
  function nt() {
    tt.r || s(tt.c), (tt = tt.p);
  }
  function st(t, e) {
    t && t.i && (Q.delete(t), t.i(e));
  }
  function rt(t, e, n, s) {
    if (t && t.o) {
      if (Q.has(t)) return;
      Q.add(t),
        tt.c.push(() => {
          Q.delete(t), s && (n && t.d(1), s());
        }),
        t.o(e);
    } else s && s();
  }
  function ot(t, e, n) {
    const s = t.$$.props[e];
    void 0 !== s && ((t.$$.bound[s] = n), n(t.$$.ctx[s]));
  }
  function lt(t) {
    t && t.c();
  }
  function it(t, n, o, l) {
    const { fragment: i, after_update: c } = t.$$;
    i && i.m(n, o),
      l ||
      U(() => {
        const n = t.$$.on_mount.map(e).filter(r);
        t.$$.on_destroy ? t.$$.on_destroy.push(...n) : s(n),
          (t.$$.on_mount = []);
      }),
      c.forEach(U);
  }
  function ct(t, e) {
    const n = t.$$;
    null !== n.fragment &&
      ((function (t) {
        const e = [],
          n = [];
        B.forEach((s) => (-1 === t.indexOf(s) ? e.push(s) : n.push(s))),
          n.forEach((t) => t()),
          (B = e);
      })(n.after_update),
        s(n.on_destroy),
        n.fragment && n.fragment.d(e),
        (n.on_destroy = n.fragment = null),
        (n.ctx = []));
  }
  function at(e, r, o, l, i, c, a, u = [-1]) {
    const d = N;
    P(e);
    const f = (e.$$ = {
      fragment: null,
      ctx: [],
      props: c,
      update: t,
      not_equal: i,
      bound: n(),
      on_mount: [],
      on_destroy: [],
      on_disconnect: [],
      before_update: [],
      after_update: [],
      context: new Map(r.context || (d ? d.$$.context : [])),
      callbacks: n(),
      dirty: u,
      skip_bound: !1,
      root: r.target || d.$$.root,
    });
    a && a(f.root);
    let p = !1;
    if (
      ((f.ctx = o
        ? o(e, r.props || {}, (t, n, ...s) => {
          const r = s.length ? s[0] : n;
          return (
            f.ctx &&
            i(f.ctx[t], (f.ctx[t] = r)) &&
            (!f.skip_bound && f.bound[t] && f.bound[t](r),
              p &&
              (function (t, e) {
                -1 === t.$$.dirty[0] &&
                  (q.push(t), W(), t.$$.dirty.fill(0)),
                  (t.$$.dirty[(e / 31) | 0] |= 1 << e % 31);
              })(e, t)),
            n
          );
        })
        : []),
        f.update(),
        (p = !0),
        s(f.before_update),
        (f.fragment = !!l && l(f.ctx)),
        r.target)
    ) {
      if (r.hydrate) {
        const t = (function (t) {
          return Array.from(t.childNodes);
        })(r.target);
        f.fragment && f.fragment.l(t), t.forEach(x);
      } else f.fragment && f.fragment.c();
      r.intro && st(e.$$.fragment),
        it(e, r.target, r.anchor, r.customElement),
        G();
    }
    P(d);
  }
  class ut {
    $destroy() {
      ct(this, 1), (this.$destroy = t);
    }
    $on(e, n) {
      if (!r(n)) return t;
      const s = this.$$.callbacks[e] || (this.$$.callbacks[e] = []);
      return (
        s.push(n),
        () => {
          const t = s.indexOf(n);
          -1 !== t && s.splice(t, 1);
        }
      );
    }
    $set(t) {
      var e;
      this.$$set &&
        ((e = t), 0 !== Object.keys(e).length) &&
        ((this.$$.skip_bound = !0), this.$$set(t), (this.$$.skip_bound = !1));
    }
  }
  const dt = [];
  function ft(e, n = t) {
    let s;
    const r = new Set();
    function l(t) {
      if (o(e, t) && ((e = t), s)) {
        const t = !dt.length;
        for (const t of r) t[1](), dt.push(t, e);
        if (t) {
          for (let t = 0; t < dt.length; t += 2) dt[t][0](dt[t + 1]);
          dt.length = 0;
        }
      }
    }
    return {
      set: l,
      update: function (t) {
        l(t(e));
      },
      subscribe: function (o, i = t) {
        const c = [o, i];
        return (
          r.add(c),
          1 === r.size && (s = n(l) || t),
          o(e),
          () => {
            r.delete(c), 0 === r.size && s && (s(), (s = null));
          }
        );
      },
    };
  }
  function pt(t, e = !1) {
    return (
      (t = t.slice(
        t.startsWith("/#") ? 2 : 0,
        t.endsWith("/*") ? -2 : void 0
      )).startsWith("/") || (t = "/" + t),
      "/" === t && (t = ""),
      e && !t.endsWith("/") && (t += "/"),
      t
    );
  }
  function gt(t, e, n) {
    if ("" === n) return t;
    if ("/" === n[0]) return n;
    let s = (t) => t.split("/").filter((t) => "" !== t),
      r = s(t);
    return "/" + (e ? s(e) : []).map((t, e) => r[e]).join("/") + "/" + n;
  }
  function ht(t, e, n, s) {
    let r = [e, "data-" + e].reduce((e, s) => {
      let r = t.getAttribute(s);
      return n && t.removeAttribute(s), null === r ? e : r;
    }, !1);
    return (!s && "" === r) || r || s || !1;
  }
  function mt(t) {
    let e = t
      .split("&")
      .map((t) => t.split("="))
      .reduce((t, e) => {
        let n = e[0];
        if (!n) return t;
        let s = !(e.length > 1) || e[e.length - 1];
        return (
          "string" == typeof s && s.includes(",") && (s = s.split(",")),
          void 0 === t[n] ? (t[n] = [s]) : t[n].push(s),
          t
        );
      }, {});
    return Object.entries(e).reduce(
      (t, e) => ((t[e[0]] = e[1].length > 1 ? e[1] : e[1][0]), t),
      {}
    );
  }
  function bt(t, e) {
    return t ? e + t : "";
  }
  function xt(t) {
    throw new Error("[Tinro] " + t);
  }
  var vt,
    $t,
    wt,
    yt = {
      HISTORY: 1,
      HASH: 2,
      MEMORY: 3,
      OFF: 4,
      run(t, e, n, s) {
        return t === this.HISTORY
          ? e && e()
          : t === this.HASH
            ? n && n()
            : s && s();
      },
      getDefault() {
        return window && "srcdoc" !== window.location.pathname
          ? this.HISTORY
          : this.MEMORY;
      },
    },
    kt = "",
    _t = (function () {
      let t,
        e = yt.getDefault(),
        n = (n) => t && t(jt(e)),
        s = (t) => {
          t && (e = t),
            (window.onhashchange = window.onpopstate = vt = null),
            e !== yt.OFF &&
            yt.run(
              e,
              (t) => (window.onpopstate = n),
              (t) => (window.onhashchange = n)
            ) &&
            n();
        };
      return {
        mode: s,
        get: (t) => jt(e),
        go(t, s) {
          (function (t, e, n) {
            !n && ($t = wt);
            let s = (t) =>
              history[(n ? "replace" : "push") + "State"]({}, "", t);
            yt.run(
              t,
              (t) => s(kt + e),
              (t) => s(`#${e}`),
              (t) => (vt = e)
            );
          })(e, t, s),
            n();
        },
        start(e) {
          (t = e), s();
        },
        stop() {
          (t = null), s(yt.OFF);
        },
        set(t) {
          this.go(
            ((t) => {
              let n = Object.assign(jt(e), t);
              return (
                n.path +
                bt(
                  (function (t) {
                    return Object.entries(t)
                      .map(([t, e]) =>
                        e
                          ? !0 === e
                            ? t
                            : `${t}=${Array.isArray(e) ? e.join(",") : e}`
                          : null
                      )
                      .filter((t) => t)
                      .join("&");
                  })(n.query),
                  "?"
                ) +
                bt(n.hash, "#")
              );
            })(t),
            !t.path
          );
        },
        methods() {
          return (function (t) {
            let e = () => t.get().query,
              n = (e) => t.set({ query: e }),
              s = (t) => n(t(e())),
              r = (e) => t.set({ hash: e });
            return {
              hash: { get: () => t.get().hash, set: r, clear: () => r("") },
              query: {
                replace: n,
                clear: () => n(""),
                get: (t) => (t ? e()[t] : e()),
                set(t, e) {
                  s((n) => ((n[t] = e), n));
                },
                delete(t) {
                  s((e) => (e[t] && delete e[t], e));
                },
              },
            };
          })(this);
        },
        base: (t) => (kt = t),
      };
    })();
  function jt(t) {
    let e = window.location,
      n = yt.run(
        t,
        (t) =>
          (kt ? e.pathname.replace(kt, "") : e.pathname) + e.search + e.hash,
        (t) => String(e.hash.slice(1) || "/"),
        (t) => vt || "/"
      ),
      s = n.match(/^([^?#]+)(?:\?([^#]+))?(?:\#(.+))?$/);
    return (
      (wt = n),
      {
        url: n,
        from: $t,
        path: s[1] || "",
        query: mt(s[2] || ""),
        hash: s[3] || "",
      }
    );
  }
  var Ct = (function () {
    let { subscribe: t } = ft(_t.get(), (t) => {
      _t.start(t);
      let e = (function (t) {
        let e = (e) => {
          let n = e.target.closest("a[href]"),
            s = n && ht(n, "target", !1, "_self"),
            r = n && ht(n, "tinro-ignore"),
            o = e.ctrlKey || e.metaKey || e.altKey || e.shiftKey;
          if ("_self" == s && !r && !o && n) {
            let s = n.getAttribute("href").replace(/^\/#/, "");
            /^\/\/|^#|^[a-zA-Z]+:/.test(s) ||
              (e.preventDefault(),
                t(
                  s.startsWith("/")
                    ? s
                    : n.href.replace(window.location.origin, "")
                ));
          }
        };
        return (
          addEventListener("click", e), () => removeEventListener("click", e)
        );
      })(_t.go);
      return () => {
        _t.stop(), e();
      };
    });
    return {
      subscribe: t,
      goto: _t.go,
      params: Lt,
      meta: Tt,
      useHashNavigation: (t) => _t.mode(t ? yt.HASH : yt.HISTORY),
      mode: {
        hash: () => _t.mode(yt.HASH),
        history: () => _t.mode(yt.HISTORY),
        memory: () => _t.mode(yt.MEMORY),
      },
      base: _t.base,
      location: _t.methods(),
    };
  })();
  function Lt() {
    return A("tinro").meta.params;
  }
  var St = "tinro",
    Mt = Jt({ pattern: "", matched: !0 });
  function Tt() {
    return (
      St,
      D().$$.context.has("tinro")
        ? A(St).meta
        : xt(
          "meta() function must be run inside any `<Route>` child component only"
        )
    );
  }
  function Jt(t) {
    let e = {
      router: {},
      exact: !1,
      pattern: null,
      meta: null,
      parent: null,
      fallback: !1,
      redirect: !1,
      firstmatch: !1,
      breadcrumb: null,
      matched: !1,
      childs: new Set(),
      activeChilds: new Set(),
      fallbacks: new Set(),
      async showFallbacks() {
        if (
          !this.fallback &&
          (await (W(), F),
            (this.childs.size > 0 && 0 == this.activeChilds.size) ||
            (0 == this.childs.size && this.fallbacks.size > 0))
        ) {
          let t = this;
          for (; 0 == t.fallbacks.size;) if (((t = t.parent), !t)) return;
          t &&
            t.fallbacks.forEach((t) => {
              if (t.redirect) {
                let e = gt("/", t.parent.pattern, t.redirect);
                Ct.goto(e, !0);
              } else t.show();
            });
        }
      },
      start() {
        this.router.un ||
          (this.router.un = Ct.subscribe((t) => {
            (this.router.location = t), null !== this.pattern && this.match();
          }));
      },
      match() {
        this.showFallbacks();
      },
    };
    return Object.assign(e, t), e.start(), e;
  }
  const Ot = (t) => ({ params: 2 & t, meta: 4 & t }),
    Et = (t) => ({ params: t[1], meta: t[2] });
  function Nt(t) {
    let e;
    const n = t[9].default,
      s = u(n, t, t[8], Et);
    return {
      c() {
        s && s.c();
      },
      m(t, n) {
        s && s.m(t, n), (e = !0);
      },
      p(t, r) {
        s &&
          s.p &&
          (!e || 262 & r) &&
          p(s, n, t, t[8], e ? f(n, t[8], r, Ot) : g(t[8]), Et);
      },
      i(t) {
        e || (st(s, t), (e = !0));
      },
      o(t) {
        rt(s, t), (e = !1);
      },
      d(t) {
        s && s.d(t);
      },
    };
  }
  function Pt(t) {
    let e,
      n,
      s = t[0] && Nt(t);
    return {
      c() {
        s && s.c(), (e = _());
      },
      m(t, r) {
        s && s.m(t, r), b(t, e, r), (n = !0);
      },
      p(t, [n]) {
        t[0]
          ? s
            ? (s.p(t, n), 1 & n && st(s, 1))
            : ((s = Nt(t)), s.c(), st(s, 1), s.m(e.parentNode, e))
          : s &&
          (et(),
            rt(s, 1, 1, () => {
              s = null;
            }),
            nt());
      },
      i(t) {
        n || (st(s), (n = !0));
      },
      o(t) {
        rt(s), (n = !1);
      },
      d(t) {
        s && s.d(t), t && x(e);
      },
    };
  }
  function Dt(t, e, n) {
    let { $$slots: s = {}, $$scope: r } = e,
      { path: o = "/*" } = e,
      { fallback: l = !1 } = e,
      { redirect: i = !1 } = e,
      { firstmatch: c = !1 } = e,
      { breadcrumb: a = null } = e,
      u = !1,
      d = {},
      f = {};
    const p = (function (t) {
      let e = A(St) || Mt;
      (e.exact || e.fallback) &&
        xt(
          `${t.fallback ? "<Route fallback>" : `<Route path="${t.path}">`
          }  can't be inside ${e.fallback
            ? "<Route fallback>"
            : `<Route path="${e.path || "/"}"> with exact path`
          }`
        );
      let n = t.fallback ? "fallbacks" : "childs",
        s = ft({}),
        r = Jt({
          fallback: t.fallback,
          parent: e,
          update(t) {
            (r.exact = !t.path.endsWith("/*")),
              (r.pattern = pt(`${r.parent.pattern || ""}${t.path}`)),
              (r.redirect = t.redirect),
              (r.firstmatch = t.firstmatch),
              (r.breadcrumb = t.breadcrumb),
              r.match();
          },
          register: () => (
            r.parent[n].add(r),
            async () => {
              r.parent[n].delete(r),
                r.parent.activeChilds.delete(r),
                r.router.un && r.router.un(),
                r.parent.match();
            }
          ),
          show: () => {
            t.onShow(), !r.fallback && r.parent.activeChilds.add(r);
          },
          hide: () => {
            t.onHide(), r.parent.activeChilds.delete(r);
          },
          match: async () => {
            r.matched = !1;
            let { path: e, url: n, from: o, query: l } = r.router.location,
              i = (function (t, e) {
                (t = pt(t, !0)), (e = pt(e, !0));
                let n = [],
                  s = {},
                  r = !0,
                  o = t
                    .split("/")
                    .map((t) =>
                      t.startsWith(":") ? (n.push(t.slice(1)), "([^\\/]+)") : t
                    )
                    .join("\\/"),
                  l = e.match(new RegExp(`^${o}$`));
                return (
                  l || ((r = !1), (l = e.match(new RegExp(`^${o}`)))),
                  l
                    ? (n.forEach((t, e) => (s[t] = l[e + 1])),
                      { exact: r, params: s, part: l[0].slice(0, -1) })
                    : null
                );
              })(r.pattern, e);
            if (
              !r.fallback &&
              i &&
              r.redirect &&
              (!r.exact || (r.exact && i.exact))
            ) {
              let t = gt(e, r.parent.pattern, r.redirect);
              return Ct.goto(t, !0);
            }
            (r.meta = i && {
              from: o,
              url: n,
              query: l,
              match: i.part,
              pattern: r.pattern,
              breadcrumbs:
                (r.parent.meta && r.parent.meta.breadcrumbs.slice()) || [],
              params: i.params,
              subscribe: s.subscribe,
            }),
              r.breadcrumb &&
              r.meta &&
              r.meta.breadcrumbs.push({ name: r.breadcrumb, path: i.part }),
              s.set(r.meta),
              !i ||
                r.fallback ||
                !(!r.exact || (r.exact && i.exact)) ||
                (r.parent.firstmatch && r.parent.matched)
                ? r.hide()
                : (t.onMeta(r.meta), (r.parent.matched = !0), r.show()),
              i && r.showFallbacks();
          },
        });
      return (o = r), D().$$.context.set("tinro", o), H(() => r.register()), r;
      var o;
    })({
      fallback: l,
      onShow() {
        n(0, (u = !0));
      },
      onHide() {
        n(0, (u = !1));
      },
      onMeta(t) {
        n(2, (f = t)), n(1, (d = f.params));
      },
    });
    return (
      (t.$$set = (t) => {
        "path" in t && n(3, (o = t.path)),
          "fallback" in t && n(4, (l = t.fallback)),
          "redirect" in t && n(5, (i = t.redirect)),
          "firstmatch" in t && n(6, (c = t.firstmatch)),
          "breadcrumb" in t && n(7, (a = t.breadcrumb)),
          "$$scope" in t && n(8, (r = t.$$scope));
      }),
      (t.$$.update = () => {
        232 & t.$$.dirty &&
          p.update({ path: o, redirect: i, firstmatch: c, breadcrumb: a });
      }),
      [u, d, f, o, l, i, c, a, r, s]
    );
  }
  class Ht extends ut {
    constructor(t) {
      super(),
        at(this, t, Dt, Pt, o, {
          path: 3,
          fallback: 4,
          redirect: 5,
          firstmatch: 6,
          breadcrumb: 7,
        });
    }
  }
  function At(e) {
    let n, s, o, l, i;
    return {
      c() {
        (n = w("svg")),
          (s = w("line")),
          (o = w("line")),
          L(s, "x1", "18"),
          L(s, "y1", "6"),
          L(s, "x2", "6"),
          L(s, "y2", "18"),
          L(o, "x1", "6"),
          L(o, "y1", "6"),
          L(o, "x2", "18"),
          L(o, "y2", "18"),
          L(n, "class", "h-6 w-6 text-red-400 cursor-pointer"),
          L(n, "viewBox", "0 -2 24 24"),
          L(n, "fill", "none"),
          L(n, "stroke", "currentColor"),
          L(n, "stroke-width", "2"),
          L(n, "stroke-linecap", "round"),
          L(n, "stroke-linejoin", "round");
      },
      m(t, c) {
        b(t, n, c),
          m(n, s),
          m(n, o),
          l ||
          ((i = j(n, "click", function () {
            r(e[0]()) && e[0]().apply(this, arguments);
          })),
            (l = !0));
      },
      p(t, [n]) {
        e = t;
      },
      i: t,
      o: t,
      d(t) {
        t && x(n), (l = !1), i();
      },
    };
  }
  function It(t, e, n) {
    let { click: s = () => { } } = e;
    return (
      (t.$$set = (t) => {
        "click" in t && n(0, (s = t.click));
      }),
      [s]
    );
  }
  class qt extends ut {
    constructor(t) {
      super(), at(this, t, It, At, o, { click: 0 });
    }
  }
  function zt(t) {
    let e, n, s, r, o, l, i, c;
    return (
      (i = new qt({ props: { click: t[5] } })),
      {
        c() {
          (e = $("div")),
            (n = $("div")),
            (s = $("h1")),
            (r = y(t[0])),
            (o = k()),
            (l = $("div")),
            lt(i.$$.fragment),
            L(s, "class", "alm-hdr"),
            L(n, "class", "w-11/12"),
            L(l, "class", "flex justify-end w-1/12"),
            L(e, "class", "flex items-center");
        },
        m(t, a) {
          b(t, e, a),
            m(e, n),
            m(n, s),
            m(s, r),
            m(e, o),
            m(e, l),
            it(i, l, null),
            (c = !0);
        },
        p(t, e) {
          (!c || 1 & e) && M(r, t[0]);
          const n = {};
          4 & e && (n.click = t[5]), i.$set(n);
        },
        i(t) {
          c || (st(i.$$.fragment, t), (c = !0));
        },
        o(t) {
          rt(i.$$.fragment, t), (c = !1);
        },
        d(t) {
          t && x(e), ct(i);
        },
      }
    );
  }
  function Bt(e) {
    let n, s;
    return {
      c() {
        (n = $("h1")), (s = y(e[0])), L(n, "class", "alm-hdr");
      },
      m(t, e) {
        b(t, n, e), m(n, s);
      },
      p(t, e) {
        1 & e && M(s, t[0]);
      },
      i: t,
      o: t,
      d(t) {
        t && x(n);
      },
    };
  }
  function Rt(t) {
    let e, n, s, r, o;
    const l = [Bt, zt],
      i = [];
    function c(t, e) {
      return t[0] && !t[1] ? 0 : t[0] && t[1] ? 1 : -1;
    }
    ~(n = c(t)) && (s = i[n] = l[n](t));
    const a = t[4].default,
      d = u(a, t, t[3], null);
    return {
      c() {
        (e = $("div")), s && s.c(), (r = k()), d && d.c(), L(e, "class", "alm");
      },
      m(t, s) {
        b(t, e, s), ~n && i[n].m(e, null), m(e, r), d && d.m(e, null), (o = !0);
      },
      p(t, [u]) {
        let h = n;
        (n = c(t)),
          n === h
            ? ~n && i[n].p(t, u)
            : (s &&
              (et(),
                rt(i[h], 1, 1, () => {
                  i[h] = null;
                }),
                nt()),
              ~n
                ? ((s = i[n]),
                  s ? s.p(t, u) : ((s = i[n] = l[n](t)), s.c()),
                  st(s, 1),
                  s.m(e, r))
                : (s = null)),
          d &&
          d.p &&
          (!o || 8 & u) &&
          p(d, a, t, t[3], o ? f(a, t[3], u, null) : g(t[3]), null);
      },
      i(t) {
        o || (st(s), st(d, t), (o = !0));
      },
      o(t) {
        rt(s), rt(d, t), (o = !1);
      },
      d(t) {
        t && x(e), ~n && i[n].d(), d && d.d(t);
      },
    };
  }
  function Ft(t, e, n) {
    let { $$slots: s = {}, $$scope: r } = e,
      { title: o = !1 } = e,
      { cross: l = !1 } = e,
      { close: i = () => { } } = e;
    return (
      (t.$$set = (t) => {
        "title" in t && n(0, (o = t.title)),
          "cross" in t && n(1, (l = t.cross)),
          "close" in t && n(2, (i = t.close)),
          "$$scope" in t && n(3, (r = t.$$scope));
      }),
      [o, l, i, r, s, () => i()]
    );
  }
  class Zt extends ut {
    constructor(t) {
      super(), at(this, t, Ft, Rt, o, { title: 0, cross: 1, close: 2 });
    }
  }
  function Wt(e) {
    let n;
    return {
      c() {
        (n = $("div")),
          (n.innerHTML =
            '<div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0"><div class="fixed inset-0 bg-gray-100 bg-opacity-75 transition-opacity" aria-hidden="true"></div> \n    <div class="flex h-screen justify-center items-center"><div class="m-auto"><div style="border-top-color:transparent" class="w-10 h-10 border-4 border-blue-400 border-solid rounded-full animate-spin"></div></div></div></div>'),
          L(n, "class", "fixed z-10 inset-0 overflow-y-auto"),
          L(n, "aria-labelledby", "modal-title"),
          L(n, "role", "dialog"),
          L(n, "aria-modal", "true");
      },
      m(t, e) {
        b(t, n, e);
      },
      p: t,
      i: t,
      o: t,
      d(t) {
        t && x(n);
      },
    };
  }
  class Ut extends ut {
    constructor(t) {
      super(), at(this, t, null, Wt, o, {});
    }
  }
  function Yt(t) {
    let e,
      n,
      s,
      r = t[0] && Vt(t);
    const o = t[3].default,
      l = u(o, t, t[2], null);
    return {
      c() {
        (e = $("div")), r && r.c(), (n = k()), l && l.c(), L(e, "class", "crd");
      },
      m(t, o) {
        b(t, e, o), r && r.m(e, null), m(e, n), l && l.m(e, null), (s = !0);
      },
      p(t, i) {
        t[0]
          ? r
            ? r.p(t, i)
            : ((r = Vt(t)), r.c(), r.m(e, n))
          : r && (r.d(1), (r = null)),
          l &&
          l.p &&
          (!s || 4 & i) &&
          p(l, o, t, t[2], s ? f(o, t[2], i, null) : g(t[2]), null);
      },
      i(t) {
        s || (st(l, t), (s = !0));
      },
      o(t) {
        rt(l, t), (s = !1);
      },
      d(t) {
        t && x(e), r && r.d(), l && l.d(t);
      },
    };
  }
  function Vt(t) {
    let e, n;
    return {
      c() {
        (e = $("h1")), (n = y(t[0])), L(e, "class", "crd-hdr");
      },
      m(t, s) {
        b(t, e, s), m(e, n);
      },
      p(t, e) {
        1 & e && M(n, t[0]);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function Xt(t) {
    let e,
      n,
      s = t[1] && Yt(t);
    return {
      c() {
        s && s.c(), (e = _());
      },
      m(t, r) {
        s && s.m(t, r), b(t, e, r), (n = !0);
      },
      p(t, [n]) {
        t[1]
          ? s
            ? (s.p(t, n), 2 & n && st(s, 1))
            : ((s = Yt(t)), s.c(), st(s, 1), s.m(e.parentNode, e))
          : s &&
          (et(),
            rt(s, 1, 1, () => {
              s = null;
            }),
            nt());
      },
      i(t) {
        n || (st(s), (n = !0));
      },
      o(t) {
        rt(s), (n = !1);
      },
      d(t) {
        s && s.d(t), t && x(e);
      },
    };
  }
  function Gt(t, e, n) {
    let { $$slots: s = {}, $$scope: r } = e,
      { title: o = !1 } = e,
      { show: l = !0 } = e;
    return (
      (t.$$set = (t) => {
        "title" in t && n(0, (o = t.title)),
          "show" in t && n(1, (l = t.show)),
          "$$scope" in t && n(2, (r = t.$$scope));
      }),
      [o, l, r, s]
    );
  }
  class Kt extends ut {
    constructor(t) {
      super(), at(this, t, Gt, Xt, o, { title: 0, show: 1 });
    }
  }
  function Qt(t) {
    let e, n, r, o;
    return {
      c() {
        (e = $("input")),
          L(
            e,
            "class",
            (n = t[0].sent
              ? "ipt-rnd text-right border-red-500"
              : "ipt-rnd text-right focus:border-indigo-500")
          ),
          L(e, "step", "0.1"),
          L(e, "type", "number");
      },
      m(n, s) {
        b(n, e, s),
          T(e, t[0].status),
          r || ((o = [j(e, "change", t[4]), j(e, "input", t[5])]), (r = !0));
      },
      p(t, s) {
        1 & s &&
          n !==
          (n = t[0].sent
            ? "ipt-rnd text-right border-red-500"
            : "ipt-rnd text-right focus:border-indigo-500") &&
          L(e, "class", n),
          1 & s && S(e.value) !== t[0].status && T(e, t[0].status);
      },
      d(t) {
        t && x(e), (r = !1), s(o);
      },
    };
  }
  function te(t) {
    let e, n, r, o;
    return {
      c() {
        (e = $("input")),
          L(
            e,
            "class",
            (n = t[0].sent
              ? "ipt-rnd text-right border-red-500"
              : "ipt-rnd text-right focus:border-indigo-500")
          ),
          L(e, "type", "text");
      },
      m(n, s) {
        b(n, e, s),
          T(e, t[0].status),
          r || ((o = [j(e, "change", t[6]), j(e, "input", t[7])]), (r = !0));
      },
      p(t, s) {
        1 & s &&
          n !==
          (n = t[0].sent
            ? "ipt-rnd text-right border-red-500"
            : "ipt-rnd text-right focus:border-indigo-500") &&
          L(e, "class", n),
          1 & s && e.value !== t[0].status && T(e, t[0].status);
      },
      d(t) {
        t && x(e), (r = !1), s(o);
      },
    };
  }
  function ee(t) {
    let e, n, r, o;
    return {
      c() {
        (e = $("input")),
          L(
            e,
            "class",
            (n = t[0].sent
              ? "ipt-rnd text-right border-red-500"
              : "ipt-rnd text-right focus:border-indigo-500")
          ),
          L(e, "type", "date");
      },
      m(n, s) {
        b(n, e, s),
          T(e, t[2]),
          r || ((o = [j(e, "change", t[8]), j(e, "input", t[9])]), (r = !0));
      },
      p(t, s) {
        1 & s &&
          n !==
          (n = t[0].sent
            ? "ipt-rnd text-right border-red-500"
            : "ipt-rnd text-right focus:border-indigo-500") &&
          L(e, "class", n),
          4 & s && T(e, t[2]);
      },
      d(t) {
        t && x(e), (r = !1), s(o);
      },
    };
  }
  function ne(t) {
    let e, n, r, o;
    return {
      c() {
        (e = $("input")),
          L(
            e,
            "class",
            (n = t[0].sent
              ? "ipt-rnd text-right border-red-500"
              : "ipt-rnd text-right focus:border-indigo-500")
          ),
          L(e, "type", "time");
      },
      m(n, s) {
        b(n, e, s),
          T(e, t[0].status),
          r || ((o = [j(e, "change", t[10]), j(e, "input", t[11])]), (r = !0));
      },
      p(t, s) {
        1 & s &&
          n !==
          (n = t[0].sent
            ? "ipt-rnd text-right border-red-500"
            : "ipt-rnd text-right focus:border-indigo-500") &&
          L(e, "class", n),
          1 & s && T(e, t[0].status);
      },
      d(t) {
        t && x(e), (r = !1), s(o);
      },
    };
  }
  function se(e) {
    let n,
      s,
      r,
      o,
      l,
      i,
      c,
      a,
      u,
      d,
      f = (e[0].descr ? e[0].descr : "") + "",
      p = "number" == e[0].type && Qt(e),
      g = "text" == e[0].type && te(e),
      h = "date" == e[0].type && ee(e),
      v = "time" == e[0].type && ne(e);
    return {
      c() {
        (n = $("div")),
          (s = $("div")),
          (r = $("p")),
          (o = y(f)),
          (i = k()),
          (c = $("div")),
          p && p.c(),
          (a = k()),
          g && g.c(),
          (u = k()),
          h && h.c(),
          (d = k()),
          v && v.c(),
          L(
            r,
            "class",
            (l =
              "pr-4 truncate text-" +
              (e[0].descrColor ? e[0].descrColor : "gray") +
              "-500 font-bold")
          ),
          L(s, "class", "w-2/3"),
          L(c, "class", "flex justify-end w-1/3"),
          L(n, "class", "crd-itm-psn");
      },
      m(t, e) {
        b(t, n, e),
          m(n, s),
          m(s, r),
          m(r, o),
          m(n, i),
          m(n, c),
          p && p.m(c, null),
          m(c, a),
          g && g.m(c, null),
          m(c, u),
          h && h.m(c, null),
          m(c, d),
          v && v.m(c, null);
      },
      p(t, [e]) {
        1 & e && f !== (f = (t[0].descr ? t[0].descr : "") + "") && M(o, f),
          1 & e &&
          l !==
          (l =
            "pr-4 truncate text-" +
            (t[0].descrColor ? t[0].descrColor : "gray") +
            "-500 font-bold") &&
          L(r, "class", l),
          "number" == t[0].type
            ? p
              ? p.p(t, e)
              : ((p = Qt(t)), p.c(), p.m(c, a))
            : p && (p.d(1), (p = null)),
          "text" == t[0].type
            ? g
              ? g.p(t, e)
              : ((g = te(t)), g.c(), g.m(c, u))
            : g && (g.d(1), (g = null)),
          "date" == t[0].type
            ? h
              ? h.p(t, e)
              : ((h = ee(t)), h.c(), h.m(c, d))
            : h && (h.d(1), (h = null)),
          "time" == t[0].type
            ? v
              ? v.p(t, e)
              : ((v = ne(t)), v.c(), v.m(c, null))
            : v && (v.d(1), (v = null));
      },
      i: t,
      o: t,
      d(t) {
        t && x(n), p && p.d(), g && g.d(), h && h.d(), v && v.d();
      },
    };
  }
  function re(t, e, n) {
    t += e;
    let s = 0;
    do {
      if (s == n) return oe(t, e);
      (t = le(t, e)), s++;
    } while (0 != t.length);
    return "not found";
  }
  function oe(t, e) {
    let n = t.indexOf(e);
    return t.substring(0, n);
  }
  function le(t, e) {
    let n = t.indexOf(e) + e.length;
    return t.substring(n);
  }
  function ie(t, e, n) {
    let { widget: s } = e,
      { wsPush: r = (t, e, n) => { } } = e,
      o = "";
    function l() {
      n(
        0,
        (s.status = re(o, "-", 2) + "." + re(o, "-", 1) + "." + re(o, "-", 0)),
        s
      ),
        r(s.ws, s.topic, s.status);
    }
    return (
      (t.$$set = (t) => {
        "widget" in t && n(0, (s = t.widget)),
          "wsPush" in t && n(1, (r = t.wsPush));
      }),
      (t.$$.update = () => {
        1 & t.$$.dirty &&
          (s.status,
            (function () {
              let t = s.status;
              n(
                2,
                (o = re(t, ".", 2) + "-" + re(t, ".", 1) + "-" + re(t, ".", 0))
              );
            })());
      }),
      [
        s,
        r,
        o,
        l,
        () => (n(0, (s.sent = !0), s), r(s.ws, s.topic, s.status)),
        function () {
          (s.status = S(this.value)), n(0, s);
        },
        () => (n(0, (s.sent = !0), s), r(s.ws, s.topic, s.status)),
        function () {
          (s.status = this.value), n(0, s);
        },
        () => (n(0, (s.sent = !0), s), l()),
        function () {
          (o = this.value), n(2, o);
        },
        () => (n(0, (s.sent = !0), s), r(s.ws, s.topic, s.status)),
        function () {
          (s.status = this.value), n(0, s);
        },
      ]
    );
  }
  class ce extends ut {
    constructor(t) {
      super(), at(this, t, ie, se, o, { widget: 0, wsPush: 1 });
    }
  }
  function ae(e) {
    let n,
      r,
      o,
      l,
      i,
      c,
      a,
      u,
      d,
      f,
      p,
      g,
      h,
      v = (e[0].descr ? e[0].descr : "") + "",
      w = e[0].after + "";
    return {
      c() {
        (n = $("div")),
          (r = $("p")),
          (o = y(v)),
          (l = k()),
          (i = y(e[4])),
          (c = k()),
          (a = y(w)),
          (d = k()),
          (f = $("input")),
          L(
            r,
            "class",
            (u =
              "pr-4 truncate text-" +
              (e[0].descrColor ? e[0].descrColor : "gray") +
              "-500 font-bold")
          ),
          L(n, "class", "text-center"),
          L(
            f,
            "class",
            (p =
              "form-range range-secondary w-full h-2 p-0 rounded-lg " +
              (e[0].sent ? "bg-red-300" : "bg-gray-300") +
              " focus:outline-none appearance-none")
          ),
          L(f, "type", "range"),
          L(f, "min", e[2]),
          L(f, "max", e[3]);
      },
      m(t, s) {
        b(t, n, s),
          m(n, r),
          m(r, o),
          m(r, l),
          m(r, i),
          m(r, c),
          m(r, a),
          b(t, d, s),
          b(t, f, s),
          T(f, e[0].status),
          g ||
          ((h = [
            j(f, "change", e[5]),
            j(f, "input", e[5]),
            j(f, "change", e[6]),
          ]),
            (g = !0));
      },
      p(t, [e]) {
        1 & e && v !== (v = (t[0].descr ? t[0].descr : "") + "") && M(o, v),
          16 & e && M(i, t[4]),
          1 & e && w !== (w = t[0].after + "") && M(a, w),
          1 & e &&
          u !==
          (u =
            "pr-4 truncate text-" +
            (t[0].descrColor ? t[0].descrColor : "gray") +
            "-500 font-bold") &&
          L(r, "class", u),
          1 & e &&
          p !==
          (p =
            "form-range range-secondary w-full h-2 p-0 rounded-lg " +
            (t[0].sent ? "bg-red-300" : "bg-gray-300") +
            " focus:outline-none appearance-none") &&
          L(f, "class", p),
          4 & e && L(f, "min", t[2]),
          8 & e && L(f, "max", t[3]),
          1 & e && T(f, t[0].status);
      },
      i: t,
      o: t,
      d(t) {
        t && x(n), t && x(d), t && x(f), (g = !1), s(h);
      },
    };
  }
  function ue(t, e, n) {
    let s,
      { widget: r } = e,
      { wsPush: o = (t, e, n) => { } } = e,
      l = r.min,
      i = r.max;
    return (
      (t.$$set = (t) => {
        "widget" in t && n(0, (r = t.widget)),
          "wsPush" in t && n(1, (o = t.wsPush));
      }),
      (t.$$.update = () => {
        1 & t.$$.dirty &&
          (r.status,
            (function () {
              var t, e, o, c, a;
              n(4, (s = Math.round(r.status))),
                r.k &&
                0 !== r.k &&
                (n(2, (l = r.min / r.k)),
                  n(3, (i = r.max / r.k)),
                  n(
                    4,
                    ((t = r.status),
                      (e = l),
                      (o = i),
                      (c = r.min),
                      (a = r.max),
                      (s = Math.round(((t - e) * (a - c)) / (o - e) + c)))
                  ));
            })());
      }),
      [
        r,
        o,
        l,
        i,
        s,
        function () {
          (r.status = S(this.value)), n(0, r);
        },
        () => (n(0, (r.sent = !0), r), o(r.ws, r.topic, r.status)),
      ]
    );
  }
  class de extends ut {
    constructor(t) {
      super(), at(this, t, ue, ae, o, { widget: 0, wsPush: 1 });
    }
  }
  class fe {
    static ctx;
    constructor(t, e = {}, n = !1) {
      (fe.ctx = this), (this.$root = fe.make(t, e, n));
    }
    static make(t, e = {}, n = !1) {
      return t && "object" == typeof e
        ? e instanceof Node
          ? e
          : ("svg" == t && (n = !0),
            fe.config(
              n
                ? document.createElementNS("http://www.w3.org/2000/svg", t)
                : document.createElement(t),
              e,
              n
            ))
        : null;
    }
    static config(t, e, n = !1) {
      if (Array.isArray(t)) return t.forEach((t) => fe.config(t, e, n)), null;
      if (!(t instanceof Node) || "object" != typeof e) return t;
      let s = e.context;
      (fe.ctx = null === s ? null : s || fe.ctx), (s = fe.ctx);
      let r = (e) => {
        if (e)
          if (e instanceof Node) t.appendChild(e);
          else if (e instanceof fe) t.appendChild(e.$root);
          else if ("string" == typeof e) t.innerHTML += e;
          else if ("object" == typeof e) {
            let s = fe.make(e.tag ?? "div", e, n || "svg" == e.tag);
            s && t.appendChild(s);
          }
      };
      for (const [n, o] of Object.entries(e))
        if (o)
          switch (n) {
            case "tag":
            case "context":
            case "get":
            case "also":
              continue;
            case "text":
              t.textContent = o + "";
              break;
            case "html":
              t.innerHTML = o;
              break;
            case "class":
              (Array.isArray(o) ? o : o.split(" ")).map(
                (e) => e && t.classList.add(e)
              );
              break;
            case "push":
              o.push(t);
              break;
            case "var":
              s && (s["$" + o] = t);
              break;
            case "events":
              for (let e in o) t.addEventListener(e, o[e].bind(s));
              break;
            case "parent":
              o && o.appendChild(t);
              break;
            case "attrs":
              for (let e in o) t.setAttribute(e, o[e]);
              break;
            case "props":
              for (let e in o) t[e] = o[e];
              break;
            case "child_r":
              t.replaceChildren();
            case "child":
              r(o);
              break;
            case "children_r":
              t.replaceChildren();
            case "children":
              for (const t of o) r(t);
              break;
            case "style":
              if ("string" == typeof o) t.style.cssText += o + ";";
              else for (let e in o) t.style[e] = o[e];
              break;
            default:
              t[n] = o;
          }
      return e.also && s && e.also.call(s, t), t;
    }
    static makeArray(t, e = !1) {
      return t && Array.isArray(t) ? t.map((t) => fe.make(t.tag, t, e)) : [];
    }
    static makeShadow(t, e = {}, n = null) {
      if (!t || "object" != typeof e) return null;
      let s = t instanceof Node ? t : document.createElement(t);
      return (
        s.attachShadow({ mode: "open" }),
        fe.config(s.shadowRoot, {
          context: e.context,
          children: [
            { tag: "style", textContent: n ?? "" },
            e.child ?? {},
            ...(e.children ?? []),
          ],
        }),
        delete e.children,
        delete e.child,
        fe.config(s, e),
        s
      );
    }
  }
  class pe {
    static make = (t, e) => fe.make(t, e, !0);
    static config = (t, e) => fe.config(t, e, !0);
    static makeArray = (t) => fe.makeArray(t, !0);
    static svg = (t = {}, e = {}) => pe._make("svg", t, e);
    static rect = (t, e, n, s, r, o, l = {}, i = {}) =>
      pe._make(
        "rect",
        { ...l, x: t, y: e, width: n, height: s, rx: r, ry: o },
        i
      );
    static circle = (t, e, n, s = {}, r = {}) =>
      pe._make("circle", { ...s, cx: t, cy: e, r: n }, r);
    static line = (t, e, n, s, r = {}, o = {}) =>
      pe._make("line", { ...r, x1: t, y1: e, x2: n, y2: s }, o);
    static polyline = (t, e = {}, n = {}) =>
      pe._make("polyline", { ...e, points: t }, n);
    static polygon = (t, e = {}, n = {}) =>
      pe._make("polygon", { ...e, points: t }, n);
    static path = (t, e = {}, n = {}) => pe._make("path", { ...e, d: t }, n);
    static text = (t, e, n, s = {}, r = {}) =>
      pe._make("text", { ...s, x: e, y: n }, { ...r, text: t });
    static _make = (t, e = {}, n = {}) => pe.make(t, { attrs: { ...e }, ...n });
  }
  const ge = (t, e, n) => (t < e ? e : t > n ? n : t),
    he = (t, e, n, s, r) => (n == e ? s : ((t - e) * (r - s)) / (n - e) + s),
    me = (t, e = 1) => t[t.length - e],
    be = () => new Date().getTime(),
    xe = 16,
    ve = 15,
    $e = 12,
    we = 16;
  class ye {
    data = {};
    cfg = { dark: !1, type: "bar", labels: [], period: 200 };
    sel_mode = !1;
    pressX = 0;
    constructor(t, e = {}, n = window) {
      ye.css &&
        ((function (t) {
          let e = document.createElement("style");
          (e.innerText = t), document.head.appendChild(e);
        })(ye.css),
          (ye.css = null)),
        (t.style.overflow = "hidden"),
        fe.make("div", {
          context: this,
          parent: t,
          class: "svp",
          var: "svp",
          children: [
            {
              class: "menu",
              children: [
                { class: "labels", var: "labels" },
                {
                  style: "display:flex",
                  children: [
                    {
                      class: "buttons none",
                      var: "buttons",
                      children: [
                        {
                          class: "button",
                          child: Ce(
                            "M 2,12 H 22 M 2,12 6.2,16.2 M 2,12 6.2,7.7 M 22,12 17.7,7.7 M 22,12 17.7,16.2"
                          ),
                          events: { click: () => this.fitData() },
                        },
                        {
                          class: "button",
                          var: "single",
                          child: Ce(
                            "M17 4V20M17 20L13 16M17 20L21 16M7 20V4M7 4L3 8M7 4L11 8"
                          ),
                          events: {
                            click: () => {
                              this.$single.classList.toggle("active"),
                                this._render();
                            },
                          },
                        },
                        {
                          class: "button",
                          text: "1s",
                          events: { click: () => this._setMax(1) },
                        },
                        {
                          class: "button",
                          text: "1m",
                          events: { click: () => this._setMax(60) },
                        },
                        {
                          class: "button",
                          text: "1h",
                          events: { click: () => this._setMax(3600) },
                        },
                        {
                          class: "button",
                          text: "1d",
                          events: { click: () => this._setMax(86400) },
                        },
                        {
                          class: "button",
                          text: "1w",
                          events: { click: () => this._setMax(604800) },
                        },
                        {
                          class: ["sel_mode", "button"],
                          var: "sel_mode",
                          child: Ce(
                            "M4.4 3.4c-.5-.1-.7-.2-.84-.14a.5.5 0 0 0-.3.3c-.1.16.0.4.14.84l4.21 14.3c.13.4.2.64.3.7a.5.5 0 0 0 .4.1c.16-.03.3-.2.6-.5L12 16l4.4 4.4.2.2.3.3.4.3a.5.5 0 0 0 .31 0c.1-.0.2-.14.41-.3l2.9-2.9c.2-.2.3-.3.3-.41a.5.5 0 0 0 0-.31c-.1-.1-.1-.2-.3-.41L16 12l3.1-3.1c.3-.3.47-.47.5-.63a.5.5 0 0 0-.1-.4c-.1-.13-.3-.2-.74-.31l-14.3-4.2Z"
                          ),
                          events: {
                            click: () => {
                              (this.sel_mode = !this.sel_mode),
                                this.$sel_mode.classList.toggle("active");
                            },
                          },
                        },
                        {
                          class: "button",
                          child: Ce(
                            "M3 21L21 3M3 21H9M3 21L3 15M21 3H15M21 3V9"
                          ),
                          var: "fullscr",
                          events: {
                            click: () => {
                              this.$svp.classList.toggle("fullscreen"),
                                this.$fullscr.classList.toggle("active");
                            },
                          },
                        },
                        {
                          class: "button",
                          child: Ce("M21 21H3M18 11L12 17M12 17L6 11M12 17V3"),
                          events: {
                            click: () =>
                              (function (t) {
                                (t.style.width = t.clientWidth + "px"),
                                  (t.style.height = t.clientHeight + "px");
                                let e = new XMLSerializer(),
                                  n = document.createElement("a");
                                (n.href =
                                  "data:image/svg+xml;charset=utf-8," +
                                  encodeURIComponent(e.serializeToString(t))),
                                  (n.download = "plot.svg"),
                                  n.click(),
                                  (t.style.width = "100%"),
                                  (t.style.height = "100%");
                              })(this.$plot),
                          },
                        },
                        {
                          class: "button",
                          child: Ce("M18 6L6 18M6 6L18 18"),
                          events: { click: () => this.clearData() },
                        },
                        {
                          class: "button",
                          child: Ce("M4 12H20M20 12L14 6M20 12L14 18"),
                          var: "auto",
                          events: { click: () => this.autoData() },
                        },
                      ],
                    },
                  ],
                },
                {
                  class: "dots",
                  child: {
                    tag: "svg",
                    var: "dots",
                    style: "width: 4px;height: 18px",
                    children: [...Array(3).keys()].map((t) => ({
                      tag: "circle",
                      attrs: {
                        cx: 2,
                        cy: 2 + 7 * t,
                        r: 2,
                        fill: "var(--font)",
                      },
                    })),
                  },
                  events: {
                    click: () => {
                      this.$buttons.classList.toggle("none"),
                        this.$labels.classList.toggle("none");
                    },
                  },
                },
              ],
            },
            {
              class: "svcont",
              var: "svcont",
              child: {
                tag: "svg",
                var: "plot",
                class: "svg",
                style: "font-family: Verdana, sans-serif;pointer-events: none;",
                attrs: { width: "100%", height: "100%" },
                children: [
                  { tag: "g", var: "grid" },
                  { tag: "g", var: "cursor" },
                  { tag: "g", var: "lines" },
                  { tag: "g", var: "markers" },
                  { tag: "g", var: "gtext" },
                  {
                    tag: "g",
                    var: "dur",
                    children: [
                      {
                        tag: "rect",
                        var: "dur_rect",
                        attrs: {
                          y: 15,
                          width: 0,
                          stroke: "none",
                          fill: "black",
                        },
                        style: "filter: opacity(0.3)",
                      },
                      {
                        tag: "text",
                        var: "dur_text",
                        attrs: {
                          y: 11,
                          fill: "--font",
                          "text-anchor": "middle",
                        },
                        style: "font-size: 13px",
                      },
                    ],
                  },
                  { tag: "g", var: "tooltip", style: "filter: opacity(0.9)" },
                ],
              },
            },
          ],
        }),
        (function (t, e, n = window, s = 300, r = 5) {
          const o = "ontouchstart" in n.document.documentElement;
          let l = 0,
            i = [],
            c = null,
            a = { x: 0, y: 0 },
            u = !1,
            d = (t, n) => {
              e({
                type: t,
                touch: o,
                move: { x: 0, y: 0 },
                pos: { x: 0, y: 0 },
                drag: a,
                pressed: o ? i.length >= 2 : l,
                ...n,
              });
            },
            f = (e, s) => ({
              x: Math.round(e - t.getBoundingClientRect().left),
              y: Math.round(
                s -
                t.getBoundingClientRect().top -
                n.document.documentElement.scrollTop
              ),
            }),
            p = (t) => f(t.pageX, t.pageY),
            g = () => {
              (a = { x: 0, y: 0 }),
                c && clearTimeout(c),
                (c = setTimeout(() => (c = null), s));
            },
            h = () => {
              c && (clearTimeout(c), (c = null));
            },
            m = () => {
              let t = 0;
              return (
                c && (h(), (t = Math.abs(a.x) < r && Math.abs(a.y) < r)),
                (a = { x: 0, y: 0 }),
                t
              );
            };
          if (o) {
            let e = (t, e) => {
              for (let n in t.changedTouches)
                if (t.changedTouches[n].identifier == e) return s(t, n);
              return null;
            },
              s = (t, e) => {
                let n = t.changedTouches[e];
                return { id: n.identifier, x: n.pageX, y: n.pageY };
              },
              r = (e) => {
                u &&
                  e.target != t &&
                  !i.length &&
                  ((u = !1),
                    d("leave"),
                    n.document.removeEventListener("touchstart", r),
                    n.document.removeEventListener("touchmove", o),
                    n.document.removeEventListener("touchend", l),
                    n.document.removeEventListener("touchcancel ", l));
              },
              o = (t) => {
                if (i.length) {
                  if (1 == i.length) {
                    let n = i[0],
                      s = e(t, n.id);
                    if (!s) return;
                    t.preventDefault(),
                      d("move", {
                        move: { x: s.x - n.x, y: s.y - n.y },
                        pos: f(s.x, s.y),
                      }),
                      h();
                  } else {
                    let n = [0, 0],
                      s = [0, 0],
                      r = 0;
                    for (let o in n)
                      (s[o] = i[o]),
                        (n[o] = e(t, s[o].id)),
                        n[o] ? (r = 1) : (n[o] = s[o]);
                    if (r) {
                      t.preventDefault();
                      let e = (n[0].x + n[1].x) / 2,
                        r = (n[0].y + n[1].y) / 2,
                        o = e - (s[0].x + s[1].x) / 2,
                        l = r - (s[0].y + s[1].y) / 2;
                      (a.x += o),
                        (a.y += l),
                        d("drag", { move: { x: o, y: l }, pos: f(e, r) });
                      let i = Math.abs(n[0].x - n[1].x),
                        c = Math.abs(n[0].y - n[1].y),
                        u = Math.abs(s[0].x - s[1].x),
                        p = Math.abs(s[0].y - s[1].y);
                      d("zoom", {
                        zoom: Math.hypot(i, c) - Math.hypot(u, p),
                        pos: f(e, r),
                      });
                    }
                  }
                  for (let n in i) {
                    let s = e(t, i[n].id);
                    s && (i[n] = s);
                  }
                }
              },
              l = (t) => {
                if (i.length) {
                  let e = s(t, 0);
                  if (!e) return;
                  let n = i.findIndex((t) => e.id == t.id);
                  ~n &&
                    (t.preventDefault(),
                      i.splice(n, 1),
                      i.length ||
                      (d("trelease", { pos: f(e.x, e.y) }),
                        m() && d("click", { pos: f(e.x, e.y) })),
                      1 == i.length && d("release", { pos: f(e.x, e.y) }));
                }
              };
            t.addEventListener(
              "touchstart",
              (t) => {
                t.preventDefault();
                let e = s(t, 0);
                if (!e) return;
                let c = i.findIndex((t) => e.id == t.id);
                ~c && i.splice(c, 1),
                  i.unshift(e),
                  1 == i.length &&
                  (g(),
                    u ||
                    ((u = !0),
                      n.document.addEventListener("touchstart", r, {
                        passive: !1,
                      }),
                      n.document.addEventListener("touchmove", o, {
                        passive: !1,
                      }),
                      n.document.addEventListener("touchend", l),
                      n.document.addEventListener("touchcancel ", l),
                      d("enter", { pos: f(e.x, e.y) })),
                    d("tpress", { pos: f(e.x, e.y) })),
                  2 == i.length && (d("press", { pos: f(e.x, e.y) }), h());
              },
              { passive: !1 }
            );
          } else {
            let e = () => {
              n.document.removeEventListener("mousemove", r),
                n.document.removeEventListener("mouseup", o);
            },
              s = () => {
                n.document.addEventListener("mousemove", r),
                  n.document.addEventListener("mouseup", o);
              },
              r = (t) => {
                l &&
                  (t.preventDefault(),
                    (a.x += t.movementX),
                    (a.y += t.movementY),
                    d("drag", {
                      move: { x: t.movementX, y: t.movementY },
                      pos: p(t),
                    }));
              },
              o = (n) => {
                l &&
                  (n.preventDefault(),
                    (l = 0),
                    d("release", { pos: p(n) }),
                    m() && d("click", { pos: p(n) }),
                    n.target !== t && e());
              };
            t.addEventListener("mouseenter", (t) => {
              d("enter", { pos: p(t) }), s();
            }),
              t.addEventListener("mouseleave", (t) => {
                d("leave", { pos: p(t) }), l || e();
              }),
              t.addEventListener("mousedown", (t) => {
                l ||
                  (s(),
                    t.preventDefault(),
                    (l = 1),
                    g(),
                    d("press", { pos: p(t) }));
              }),
              t.addEventListener("mousemove", (t) => {
                l ||
                  d("move", {
                    move: { x: t.movementX, y: t.movementY },
                    pos: p(t),
                  });
              }),
              t.addEventListener(
                "wheel",
                (t) => {
                  t.preventDefault(),
                    d("zoom", { zoom: -t.deltaY / 100, pos: p(t) });
                },
                { passive: !1 }
              );
          }
        })(
          this.$svcont,
          (t) => {
            let e = this.$plot.clientWidth,
              n = this.$plot.clientHeight,
              s = "timeline" == this.cfg.type;
            switch (
            (t.touch && "move" === t.type && (t.type = "drag"), t.type)
            ) {
              case "zoom":
                {
                  let n = () => (this.maxSecs = ge(this.maxSecs, 1, 31536e4)),
                    s = this.maxSecs;
                  t.touch
                    ? ((this.maxSecs -= t.zoom / (e / this.maxSecs / 2)),
                      n(),
                      (this.tZero += (this.maxSecs - s) / 2))
                    : ((this.maxSecs *= -t.zoom / 5 + 1),
                      n(),
                      (this.tZero += (this.maxSecs - s) * (1 - t.pos.x / e))),
                    this.auto && this._resetZ(),
                    this._clearMarkers(),
                    this._render();
                }
                break;
              case "drag":
                if (this.sel_mode) {
                  let n = Math.abs(t.pos.x - this.pressX),
                    s = Math.min(this.pressX, t.pos.x),
                    r = (n / e) * this.maxSecs;
                  pe.config(this.$dur_rect, {
                    attrs: { x: Math.min(this.pressX, t.pos.x), width: n },
                  }),
                    pe.config(this.$dur_text, {
                      attrs: { x: s + n / 2, fill: this._getProp("--font") },
                      text:
                        Math.floor(r / 86400) +
                        ":" +
                        new Date(1e3 * r).toISOString().slice(11, 22),
                    });
                } else
                  (this.tZero -= t.move.x / (e / this.maxSecs)),
                    this._auto(!1),
                    this._render();
                break;
              case "press":
              case "tpress":
                this._clearMarkers(),
                  (this.pressX = t.pos.x),
                  this.sel_mode &&
                  (pe.config(this.$dur_rect, {
                    attrs: { x: t.pos.x, width: 0, height: n - ve - xe },
                  }),
                    (this.$dur.style.display = "unset"));
                break;
              case "release":
              case "trelease":
                this.$dur.style.display = "none";
                break;
              case "leave":
                this._clearMarkers();
                break;
              case "move":
              case "click": {
                let r = 1e3 * (this.tZero - (1 - t.pos.x / e) * this.maxSecs),
                  o = 150,
                  l = ge(t.pos.x, o / 2, e - o / 2),
                  i = (t) =>
                    ((t) => new Date(t - 6e4 * new Date().getTimezoneOffset()))(
                      t
                    )
                      .toISOString()
                      .split("T");
                if (
                  (pe.config(this.$cursor, {
                    children_r: [
                      je(
                        t.pos.x,
                        s ? 0 : xe,
                        t.pos.x,
                        n - ve,
                        this._getProp("--grid"),
                        1
                      ),
                      pe.rect(l - o / 2, n - ve, o, ve, 3, 0, {
                        fill: this._getProp("--grid"),
                      }),
                      _e(
                        i(r).join(" ").slice(0, -3),
                        l,
                        n - 3,
                        this._getProp("--font"),
                        12,
                        { "text-anchor": "middle" }
                      ),
                    ],
                  }),
                    !this.points)
                )
                  break;
                let c = (t) => {
                  let n = pe.make("rect");
                  pe.config(this.$tooltip, { children_r: [n, ...t] });
                  let s = this.$tooltip.getBBox();
                  pe.config(n, {
                    attrs: {
                      x: s.x - 4,
                      width: s.width + 8,
                      y: s.y - 4,
                      height: s.height + 8,
                      rx: 4,
                      fill: this._getProp("--back"),
                      stroke: this._getProp("--font"),
                    },
                  }),
                    pe.config(this.$tooltip, {
                      attrs: {
                        transform: `translate(${e - 1 - s.width - 4} 18)`,
                      },
                    });
                },
                  a = this._getProp("--font");
                if (s) {
                  if ("click" == t.type) {
                    for (let t of this.points)
                      t.rect.classList.remove("active");
                    for (let e of this.points)
                      if (
                        t.pos.x >= e.x1 &&
                        t.pos.x <= e.x2 &&
                        t.pos.y >= e.y1 &&
                        t.pos.y <= e.y2
                      ) {
                        let t = -16,
                          n = (t, e, n, s) =>
                            _e(
                              t +
                              ": " +
                              (e ? "-" : i(n).join(" ").slice(0, -5)),
                              0,
                              s,
                              a,
                              $e
                            );
                        c([
                          _e(
                            this.cfg.labels[e.axis],
                            0,
                            (t += we),
                            this._getCol(e.axis),
                            $e,
                            {},
                            !0
                          ),
                          n("Start", e.block.fstart, e.block.start, (t += 19)),
                          n("Stop", e.block.fstop, e.block.stop, (t += we)),
                          _e(
                            "Duration: " +
                            new Date(e.block.stop - e.block.start)
                              .toISOString()
                              .substring(11, 19),
                            0,
                            (t += we),
                            a,
                            $e
                          ),
                        ]),
                          e.rect.classList.add("active");
                        break;
                      }
                  }
                } else if ("bar" === this.cfg.type && this.points) {
                  const e = Object.keys(this.points)
                    .map(Number)
                    .sort((t, e) => t - e),
                    s = this.$plot.clientWidth;
                  for (const r of e) {
                    const o = (s / e.length) * 0.8,
                      l =
                        s - ((1e3 * this.tZero - r) * s) / (1e3 * this.maxSecs),
                      u = l - o / 2,
                      d = l + o / 2;
                    if (t.pos.x >= u && t.pos.x <= d) {
                      const t = this.points[r][0],
                        e = Number(t);
                      if (isNaN(e)) {
                        console.warn("Invalid data value:", t);
                        break;
                      }
                      const s = i(r);
                      let l = -16;
                      c([
                        _e(
                          `${this.cfg.labels[0] || "Value"}: ${e.toFixed(2)}`,
                          0,
                          (l += we),
                          this._getCol(0),
                          $e,
                          {},
                          !0
                        ),
                        _e(s[0], 0, (l += we), a, $e),
                        _e(s[1].slice(0, -2), 0, (l += we), a, $e),
                      ]),
                        pe.config(this.$markers, {
                          children_r: [
                            pe.rect(u, xe, o, n - ve - xe, 2, 2, {
                              fill: this._getCol(1),
                              "fill-opacity": 0.3,
                            }),
                          ],
                        }),
                        (found = !0);
                      break;
                    }
                  }
                } else {
                  let t = 0,
                    e = Object.keys(this.points).map(Number);
                  for (let n = 1; n < e.length; n++)
                    if (e[n] >= r) {
                      t = e[e[n] - r < r - e[n - 1] ? n : n - 1];
                      break;
                    }
                  if (t && this.points[t].y) {
                    pe.config(this.$markers, {
                      children_r: this.points[t].y.map((e, n) =>
                        this._disabled(n)
                          ? null
                          : pe.circle(this.points[t].x, e, 4, {
                            stroke: this._getCol(n),
                            fill: this._getProp("--back"),
                            "stroke-width": 2,
                          })
                      ),
                    });
                    let e = -16;
                    c([
                      ...this.points[t].y.map((n, s) =>
                        _e(
                          `${this.cfg.labels[s] ?? s}: ${this.data[t][
                            s
                          ].toFixed(2)}${this.units[s] ?? ""}`,
                          0,
                          (e += we),
                          this._getCol(s),
                          $e,
                          {},
                          !0
                        )
                      ),
                      _e(i(t)[0], 0, (e += 21), a, $e),
                      _e(i(t)[1].slice(0, -2), 0, (e += we), a, $e),
                    ]);
                  }
                }
              }
            }
          },
          n
        ),
        (this.maxSecs = this.$plot.clientWidth / 10),
        this.maxSecs < 30 && (this.maxSecs = 30),
        this.setConfig(e),
        (this._resizer = new ResizeObserver(async () => {
          await new Promise(requestAnimationFrame), this._render();
        })),
        this._resizer.observe(this.$plot);
    }
    release() {
      this._resizer.disconnect();
    }
    setConfig(t) {
      (this.cfg = { ...this.cfg, ...t }),
        (this.$svp.className = "svp " + (this.cfg.dark ? "dark" : "light")),
        (this.$plot.style.background = this._getProp("--back")),
        (this.units = []),
        (this.cfg.labels = this.cfg.labels.map((t) => {
          let e = "",
            n = t.match(/(.*)\[(.*)\]$/);
          return n && ((t = n[1]), (e = n[2])), this.units.push(e), t;
        })),
        (this.labels = []),
        fe.config(this.$labels, {
          children_r: this.cfg.labels.map((t, e) =>
            fe.make("div", {
              class: "label",
              push: this.labels,
              children: [
                { class: "marker", style: `background:${this._getCol(e)}` },
                { tag: "span", text: t },
              ],
              events: {
                click: () => {
                  "timeline" != this.cfg.type &&
                    (this.labels[e].classList.toggle("tint"), this._render());
                },
              },
            })
          ),
        }),
        this.tmr && clearTimeout(this.tmr),
        this._render();
    }
    clearData() {
      (this.data = {}), (this.tZero = (be() / 1e3) | 0), this._render();
    }
    fitData() {
      this._resetZ(), this._fit(), this._render();
    }
    autoData() {
      this._resetZ(), this._auto(!0), this._render();
    }
    setData(t) {
      let e = Array.isArray(t);
      switch (this.cfg.type) {
        case "bar":
          for (let e in t) {
            let n = Number(e);
            (n = Math.floor(n < 99999999999 ? 1e3 * n : n)),
              (this.data[n] = [t[e]]);
          }
          break;
        case "running":
          this.tmr && clearTimeout(this.tmr),
            (this.tmr = setTimeout(() => {
              let t = Object.values(this.data);
              var e, n;
              t.length < 2 ||
                ((e = me(t)),
                  (n = me(t, 2)),
                  e &&
                  n &&
                  e.every((t, e) => t === n[e]) &&
                  delete this.data[me(Object.keys(this.data))],
                  this.setData([...me(t)]));
            }, this.cfg.period));
        case "stack":
          if (!e) return;
          this.data[be()] = t.map(Number);
          break;
        case "timeline":
          if (e) return;
          if (!Array.isArray(Object.values(t)[0])) {
            let e = {};
            for (let n in t) for (let s in t[n]) e[s] = !0;
            let n = new Array(Object.keys(e).length).fill(!1),
              s = Object.values(this.data);
            s.length && (n = [...me(s)]);
            for (let e in t) {
              for (let s in t[e]) n[s] = t[e][s];
              t[e] = [...n];
            }
          }
        default:
          if (e) return;
          let n = Number(me(Object.keys(this.data)));
          for (let e in t) {
            let s = Number(e);
            (s = Math.floor(s < 99999999999 ? 1e3 * s : s)),
              (!n || n < s) && (this.data[s] = t[e].map(Number));
          }
      }
      if (!this.cfg.labels.length) {
        let t = Object.values(this.data);
        t.length && this.setConfig({ labels: t[0].map((t, e) => "Line " + e) });
      }
      this.tZero || (this._auto(!0), this._fit()),
        this.auto && (this._resetZ(), this._clearMarkers()),
        this._render();
    }
    _render() {
      if (
        (this.$lines.replaceChildren(),
          this.$grid.replaceChildren(),
          this.$gtext.replaceChildren(),
          (this.points = null),
          !this.tZero)
      )
        return;
      let t = this.$plot.clientWidth,
        e = this.$plot.clientHeight;
      if (e < 50) return;
      let n = Object.keys(this.data).map(Number),
        s = (t, n, s) => he(t, n, s, e - ve, xe),
        r = (e) => t + ((e / 1e3 - this.tZero) * t) / this.maxSecs,
        o = (t) => (this.points[n[t]] = this.data[n[t]]);
      for (let t = 0; t < n.length; t++)
        if (this.points) {
          if ((o(t), n[t] >= 1e3 * this.tZero)) break;
        } else
          t + 1 < n.length &&
            n[t + 1] >= 1e3 * (this.tZero - this.maxSecs) &&
            ((this.points = {}), o(t));
      if (this.points)
        if ("bar" === this.cfg.type && this.points) {
          const t = this.$plot.clientWidth,
            e = this.$plot.clientHeight,
            n = Object.keys(this.points)
              .map(Number)
              .sort((t, e) => t - e);
          let s = 1 / 0,
            r = -1 / 0;
          for (const t of n) {
            const e = this.points[t][0];
            e < s && (s = e), e > r && (r = e);
          }
          s === 1 / 0 && (s = 0), r === -1 / 0 && (r = 1);
          const o = (e) =>
            t - ((1e3 * this.tZero - e) * t) / (1e3 * this.maxSecs),
            l = (t) => he(t, s, r, e - ve, xe);
          for (const s of n) {
            const r = (t / n.length) * 0.8,
              i = o(s) - r / 2,
              c = l(this.points[s][0]);
            pe.config(this.$lines, {
              child: pe.rect(i, c, r, e - ve - c, 2, 2, {
                fill: this._getCol(0),
                stroke: this._getProp("--back"),
                "stroke-width": 1,
              }),
            });
          }
        } else if ("timeline" == this.cfg.type) {
          let t = Object.values(this.points),
            n = Object.keys(this.points).map(Number),
            s = [];
          for (let e in t[0]) {
            let r = [],
              o = 0;
            t[0][e] && (r.push({ fstart: !0, start: n[0] }), (o = 1));
            for (let t in this.points) {
              t = Number(t);
              let n = this.points[t][e];
              o && !n && ((me(r).stop = t), (o = 0)),
                !o && n && (r.push({ start: t }), (o = 1));
            }
            if (o) {
              let t = me(r);
              (t.stop = me(n)), (t.fstop = !0);
            }
            s.push(r);
          }
          let o = t[0].length,
            l = (e - ve - 5) / o,
            i = 0.8 * l;
          this.points = [];
          for (let t in s) {
            t = Number(t);
            for (let e of s[t]) {
              let n = r(e.start),
                s = r(e.stop),
                o = l * t + (l - i) / 2,
                c = pe.rect(
                  n,
                  o,
                  s - n,
                  i,
                  3,
                  0,
                  { fill: this._getCol(t) },
                  { class: "tblock" }
                );
              this.$lines.appendChild(c),
                c.style.setProperty(
                  "--active",
                  ke(t, 1, this._getColv() + 0.1)
                ),
                this.points.push({
                  x1: n,
                  x2: s,
                  y1: o,
                  y2: o + i,
                  axis: t,
                  block: e,
                  rect: c,
                });
            }
          }
        } else {
          let n = Object.keys(this.points).length,
            o = t / 1;
          if (n > o) {
            let t = this.points;
            this.points = {};
            let e = Object.keys(t);
            for (let s = 0; s < o; s++) {
              let r = Math.floor((s / o) * n);
              this.points[e[r]] = t[e[r]];
            }
          }
          const l = 999999999;
          let i = -l,
            c = l,
            a = {},
            u = {};
          for (let t in this.points) {
            let e = this.points[t];
            for (let t in e)
              this._disabled(t) ||
                (e[t] > i && (i = e[t]),
                  e[t] < c && (c = e[t]),
                  t in a || (a[t] = -l),
                  t in u || (u[t] = l),
                  e[t] > a[t] && (a[t] = e[t]),
                  e[t] < u[t] && (u[t] = e[t]));
          }
          if (c != l) {
            let n = this.$single.classList.contains("active");
            for (let t in this.points) {
              let e,
                o = r(t);
              (e = n
                ? this.points[t].map((t, e) => s(t, u[e], a[e]))
                : this.points[t].map((t) => s(t, c, i))),
                (this.points[t] = { x: o, y: e });
            }
            let o = Object.values(this.points);
            for (let t in o[0].y) {
              if (this._disabled(t)) continue;
              let e = "";
              o.forEach((n) => (e += `${n.x},${n.y[t]} `)),
                pe.config(this.$lines, {
                  child: pe.polyline(e, {
                    fill: "none",
                    stroke: this._getCol(t),
                    "stroke-width": 2,
                  }),
                });
            }
            {
              const r = 9;
              let o = Math.round(e / 80),
                l = (i - c) / o,
                d = {
                  filter: `drop-shadow(0 0 1px ${this._getProp("--back")})`,
                };
              for (let e = 0; e < o + 1; e++) {
                let r = s(i - l * e, c, i);
                e != o &&
                  this.$grid.appendChild(
                    je(0, r, t, r, this._getProp("--grid"), 1, {
                      "stroke-dasharray": "7 8",
                    })
                  ),
                  n ||
                  this.$gtext.appendChild(
                    _e(
                      (i - l * e).toFixed(1),
                      0,
                      r - 5,
                      this._getProp("--font"),
                      12,
                      d
                    )
                  );
              }
              if (n) {
                let t = 0;
                for (let e in a) {
                  e = Number(e);
                  for (let n = 0; n < o + 1; n++) {
                    let r = s(i - l * n, c, i);
                    this.$gtext.appendChild(
                      _e(
                        (a[e] - ((a[e] - u[e]) / o) * n).toFixed(1),
                        t,
                        r - 5,
                        this._getCol(e),
                        12,
                        d
                      )
                    );
                  }
                  t +=
                    Math.max(a[e].toFixed(1).length, u[e].toFixed(1).length) *
                    r;
                }
              }
            }
          }
        }
      {
        let n = Math.round(t / 150),
          s = this.maxSecs / n,
          r = 0;
        for (let t of [86400, 3600, 1800, 60, 30, 10, 5, 1])
          if (s >= t) {
            r = t;
            break;
          }
        r || (r = 0.1), (s = Math.floor(s / r) * r);
        let o = Math.ceil(this.tZero / s) * s;
        if (!s) return;
        let l = 0;
        for (; ;) {
          let n = o - s * l,
            r = t - (t * (this.tZero - n)) / this.maxSecs;
          if (r < -75) break;
          l++;
          let i =
            this.maxSecs < 86400
              ? new Date(1e3 * n).toTimeString().split(" ")[0]
              : new Date(1e3 * n).toISOString().split("T")[0];
          pe.config(this.$grid, {
            children: [
              je(0, e - ve, t, e - ve, this._getProp("--grid"), 1.5),
              je(r, e - ve - 6, r, e - ve - 1, this._getProp("--grid"), 2),
              _e(i, r, e - ve + 14, this._getProp("--font"), 11, {
                "text-anchor": "middle",
              }),
            ],
          });
        }
      }
    }
    _getProp(t) {
      return window.getComputedStyle(this.$svp).getPropertyValue(t);
    }
    _resetZ() {
      let t = Object.keys(this.data);
      this.tZero = (t.length ? Number(t.slice(-1)[0]) : be()) / 1e3;
    }
    _clearMarkers() {
      this.$cursor.replaceChildren(),
        this.$markers.replaceChildren(),
        this.$tooltip.replaceChildren();
    }
    _disabled(t) {
      return this.labels[t] && this.labels[t].classList.contains("tint");
    }
    _getColv() {
      return this.cfg.dark ? 0.55 : 0.47;
    }
    _getCol(t) {
      return ke(t, 0.6, this._getColv());
    }
    _fit() {
      let t = Object.keys(this.data).map(Number);
      t.length > 2 && (this.maxSecs = (me(t) - t[0]) / 1e3);
    }
    _auto(t) {
      this.auto != t &&
        ((this.auto = t),
          t
            ? this.$auto.classList.add("active")
            : this.$auto.classList.remove("active"));
    }
    _setMax(t) {
      (this.maxSecs = t), this._render();
    }
    labels = [];
    units = [];
    points = null;
    tZero = 0;
    maxSecs = 10;
    auto = !1;
    static css =
      ".svp.light{--back:#fff;--font:#111;--grid:#cacaca}.svp.dark{--back:#1c1d22;--font:#c3c3c3;--grid:#4a4a4a}.svp{all:unset;font-family:Verdana,sans-serif;background:var(--back);height:100%;width:100%;display:flex;flex-direction:column;color:var(--font);user-select:none;padding:4px;box-sizing:border-box}.svp.fullscreen{position:fixed;left:0;top:0}.svp .svcont{width:100%;height:100%;overflow:hidden;touch-action:none}.svp .menu{all:unset;flex-shrink:0;display:flex;justify-content:space-between;align-items:center;padding:5px 3px;min-height:24px}.svp .label{all:unset;display:inline-flex;vertical-align:middle;align-items:center;padding-right:7px;font-size:14px;cursor:pointer}.svp .label.tint{filter:opacity(.4)}.svp .label .marker{all:unset;width:7px;height:7px;margin-right:6px}.svp .buttons{all:unset;display:flex;align-items:stretch;gap:3px;flex-wrap:wrap}.svp .tblock.active{fill:var(--active);stroke:#000;stroke-width:3}.svp .button{all:unset;display:inline-flex;align-items:center;justify-content:center;cursor:pointer;border:1px solid var(--grid);border-radius:7px;padding:2px;width:16px;height:16px;font-size:11px}.svp .button.active{border:1px solid var(--font)}.svp .button:hover{border:1px solid var(--font)}.svp .none{display:none}.svp .dots{all:unset;display:flex;align-items:center;justify-content:center;cursor:pointer;padding-left:7px}";
  }
  const ke = (t, e, n) =>
    ((t, e, n) => {
      t %= 360;
      let s = e * Math.min(n, 1 - n),
        r = (e, r = (e + t / 30) % 12) =>
          n - s * Math.max(Math.min(r - 3, 9 - r, 1), -1);
      return (
        "rgb(" +
        Math.round(255 * r(0)) +
        "," +
        Math.round(255 * r(8)) +
        "," +
        Math.round(255 * r(4)) +
        ")"
      );
    })(260 * t + 0, e, n),
    _e = (t, e, n, s, r, o = {}, l = !1) =>
      pe.text(
        t,
        e,
        n,
        { fill: s, ...o },
        { style: `font-size: ${r}px;font-weight:${l ? "bold" : "unset"}` }
      ),
    je = (t, e, n, s, r, o, l = {}) =>
      pe.line(t, e, n, s, { stroke: r, fill: "none", "stroke-width": o, ...l }),
    Ce = (t) =>
      pe.svg(
        { viewBox: "0 0 24 24" },
        {
          style: "width:24px;height:24px",
          child: pe.path(t, {
            fill: "none",
            stroke: "var(--font)",
            "stroke-width": 2,
            "stroke-linecap": "round",
            "stroke-linejoin": "round",
          }),
        }
      );
  function Le(e) {
    let n,
      s,
      r,
      o,
      l,
      i,
      c = e[0].descr + "";
    return {
      c() {
        (n = $("div")),
          (s = $("div")),
          (r = $("p")),
          (o = y(c)),
          (l = k()),
          (i = $("div")),
          L(r, "class", "descr"),
          L(s, "class", "text-center"),
          L(i, "class", "svp-container"),
          L(n, "class", "chart-container");
      },
      m(t, c) {
        b(t, n, c), m(n, s), m(s, r), m(r, o), m(n, l), m(n, i), e[4](i);
      },
      p(t, [e]) {
        1 & e && c !== (c = t[0].descr + "") && M(o, c);
      },
      i: t,
      o: t,
      d(t) {
        t && x(n), e[4](null);
      },
    };
  }
  function Se(t, e, n) {
    let s,
      r,
      o,
      { widget: l } = e;
    function i() {
      const t = {};
      return (
        l.status &&
        l.status.forEach((e) => {
          const n = [];
          for (let t = 1; ; t++) {
            const s = `y${t}`;
            if (void 0 === e[s]) break;
            n.push(e[s]);
          }
          n.length > 0 && (t[e.x] = n);
        }),
        t
      );
    }
    const c = {
      dark: !1,
      type: "bar" === l.type ? "bar" : "plot",
      labels: Array.isArray(l.series) ? l.series : ["Data"],
      period: 2e3,
    };
    var a;
    return (
      H(() => {
        s && (n(2, (r = new ye(s, c))), r.setData(i()), r.fitData());
      }),
      (a = () => {
        r && r.release();
      }),
      D().$$.on_destroy.push(a),
      (t.$$set = (t) => {
        "widget" in t && n(0, (l = t.widget));
      }),
      (t.$$.update = () => {
        13 & t.$$.dirty &&
          r &&
          l.status &&
          (l.status != o &&
            (r.setData(i()),
              r.setConfig({
                labels: Array.isArray(l.series) ? l.series : ["Данные"],
                type: "bar" === l.type ? "bar" : "plot",
              }),
              r.fitData()),
            n(3, (o = l.status)));
      }),
      [
        l,
        s,
        r,
        o,
        function (t) {
          z[t ? "unshift" : "push"](() => {
            (s = t), n(1, s);
          });
        },
      ]
    );
  }
  class Me extends ut {
    constructor(t) {
      super(), at(this, t, Se, Le, o, { widget: 0 });
    }
  }
  function Te(t) {
    let e,
      n,
      s,
      r,
      o,
      l,
      i,
      c = (t[0].descr ? t[0].descr : "") + "";
    return (
      (l = new Me({
        props: {
          widget: t[0],
          id: "notes",
          title: "",
          height: "150",
          padding: "0px",
          margin: "0px",
        },
      })),
      {
        c() {
          (e = $("div")),
            (n = $("p")),
            (s = y(c)),
            (o = k()),
            lt(l.$$.fragment),
            L(
              n,
              "class",
              (r =
                "inline-block italic truncate align-top text-center text-" +
                (t[0].descrColor ? t[0].descrColor : "gray") +
                "-500 txt-sz")
            ),
            L(e, "class", "text-center");
        },
        m(t, r) {
          b(t, e, r), m(e, n), m(n, s), b(t, o, r), it(l, t, r), (i = !0);
        },
        p(t, [e]) {
          (!i || 1 & e) &&
            c !== (c = (t[0].descr ? t[0].descr : "") + "") &&
            M(s, c),
            (!i ||
              (1 & e &&
                r !==
                (r =
                  "inline-block italic truncate align-top text-center text-" +
                  (t[0].descrColor ? t[0].descrColor : "gray") +
                  "-500 txt-sz"))) &&
            L(n, "class", r);
          const o = {};
          1 & e && (o.widget = t[0]), l.$set(o);
        },
        i(t) {
          i || (st(l.$$.fragment, t), (i = !0));
        },
        o(t) {
          rt(l.$$.fragment, t), (i = !1);
        },
        d(t) {
          t && x(e), t && x(o), ct(l, t);
        },
      }
    );
  }
  function Je(t, e, n) {
    let { widget: s } = e;
    return (
      (t.$$set = (t) => {
        "widget" in t && n(0, (s = t.widget));
      }),
      [s]
    );
  }
  class Oe extends ut {
    constructor(t) {
      super(), at(this, t, Je, Te, o, { widget: 0 });
    }
  }
  function Ee(e) {
    let n,
      r,
      o,
      l,
      i,
      c,
      a,
      u,
      d,
      f,
      p,
      g,
      h,
      v,
      w,
      _,
      C,
      S,
      T,
      J,
      O = (e[0].descr ? e[0].descr : "") + "";
    return {
      c() {
        (n = $("div")),
          (r = $("div")),
          (o = $("p")),
          (l = y(O)),
          (c = k()),
          (a = $("div")),
          (u = $("label")),
          (d = $("div")),
          (f = $("input")),
          (g = k()),
          (h = $("div")),
          (w = k()),
          (_ = $("div")),
          L(
            o,
            "class",
            (i =
              "pr-4 truncate text-" +
              (e[0].descrColor ? e[0].descrColor : "gray") +
              "-500 font-bold")
          ),
          L(r, "class", "w-2/3"),
          L(f, "id", (p = e[0].topic)),
          L(f, "type", "checkbox"),
          L(f, "class", "sr-only"),
          L(
            h,
            "class",
            (v =
              "block " +
              (e[1] ? "bg-blue-600" : "bg-gray-600") +
              " w-10 h-6 rounded-full shadow-lg")
          ),
          L(
            _,
            "class",
            (C =
              "dot " +
              (e[0].sent ? "bg-red-300" : "bg-gray-100") +
              " absolute left-1 top-1 w-4 h-4 rounded-full transition shadow-lg")
          ),
          L(d, "class", "relative"),
          L(u, "for", (S = e[0].topic)),
          L(u, "class", "items-center cursor-pointer"),
          L(a, "class", "flex justify-end w-1/3"),
          L(n, "class", "crd-itm-psn");
      },
      m(t, s) {
        b(t, n, s),
          m(n, r),
          m(r, o),
          m(o, l),
          m(n, c),
          m(n, a),
          m(a, u),
          m(u, d),
          m(d, f),
          (f.checked = e[1]),
          m(d, g),
          m(d, h),
          m(d, w),
          m(d, _),
          T || ((J = [j(f, "change", e[4]), j(f, "change", e[5])]), (T = !0));
      },
      p(t, [e]) {
        1 & e && O !== (O = (t[0].descr ? t[0].descr : "") + "") && M(l, O),
          1 & e &&
          i !==
          (i =
            "pr-4 truncate text-" +
            (t[0].descrColor ? t[0].descrColor : "gray") +
            "-500 font-bold") &&
          L(o, "class", i),
          1 & e && p !== (p = t[0].topic) && L(f, "id", p),
          2 & e && (f.checked = t[1]),
          2 & e &&
          v !==
          (v =
            "block " +
            (t[1] ? "bg-blue-600" : "bg-gray-600") +
            " w-10 h-6 rounded-full shadow-lg") &&
          L(h, "class", v),
          1 & e &&
          C !==
          (C =
            "dot " +
            (t[0].sent ? "bg-red-300" : "bg-gray-100") +
            " absolute left-1 top-1 w-4 h-4 rounded-full transition shadow-lg") &&
          L(_, "class", C),
          1 & e && S !== (S = t[0].topic) && L(u, "for", S);
      },
      i: t,
      o: t,
      d(t) {
        t && x(n), (T = !1), s(J);
      },
    };
  }
  function Ne(t, e, n) {
    let { widget: s } = e,
      { toggleState: r = !1 } = e,
      { wsPush: o = (t, e, n) => { } } = e;
    function l() {
      n(0, (s.sent = !0), s), n(0, (s.status = r ? "1" : "0"), s);
    }
    return (
      (t.$$set = (t) => {
        "widget" in t && n(0, (s = t.widget)),
          "toggleState" in t && n(1, (r = t.toggleState)),
          "wsPush" in t && n(2, (o = t.wsPush));
      }),
      (t.$$.update = () => {
        1 & t.$$.dirty &&
          (s.status,
            "1" == s.status ? n(1, (r = !0)) : "0" == s.status && n(1, (r = !1)));
      }),
      [
        s,
        r,
        o,
        l,
        function () {
          (r = this.checked), n(1, r);
        },
        () => (l(), o(s.ws, s.topic, s.status)),
      ]
    );
  }
  class Pe extends ut {
    constructor(t) {
      super(), at(this, t, Ne, Ee, o, { widget: 0, toggleState: 1, wsPush: 2 });
    }
  }
  function De(e) {
    let n,
      s,
      r,
      o,
      l,
      i,
      c,
      a,
      u,
      d,
      f,
      p,
      g,
      h,
      v,
      w = (e[0].descr ? e[0].descr : "") + "",
      _ = (e[0].status ? e[0].status : "") + "",
      j = (e[0].after ? e[0].after : "") + "";
    return {
      c() {
        (n = $("div")),
          (s = $("div")),
          (r = $("p")),
          (o = y(w)),
          (i = k()),
          (c = $("div")),
          (a = $("p")),
          (u = y(_)),
          (f = k()),
          (p = $("p")),
          (g = y(" ")),
          (h = y(j)),
          L(
            r,
            "class",
            (l =
              "pr-4 truncate text-" +
              (e[0].descrColor ? e[0].descrColor : "gray") +
              "-500 font-bold")
          ),
          L(s, "class", "w-2/3"),
          L(
            a,
            "class",
            (d = "wgt-adt-stl truncate " + (e[1] ? "text-green-500" : ""))
          ),
          L(
            p,
            "class",
            (v = "wgt-adt-stl truncate " + (e[1] ? "text-green-500" : ""))
          ),
          L(c, "class", "flex justify-end w-1/3"),
          L(n, "class", "crd-itm-psn");
      },
      m(t, e) {
        b(t, n, e),
          m(n, s),
          m(s, r),
          m(r, o),
          m(n, i),
          m(n, c),
          m(c, a),
          m(a, u),
          m(c, f),
          m(c, p),
          m(p, g),
          m(p, h);
      },
      p(t, [e]) {
        1 & e && w !== (w = (t[0].descr ? t[0].descr : "") + "") && M(o, w),
          1 & e &&
          l !==
          (l =
            "pr-4 truncate text-" +
            (t[0].descrColor ? t[0].descrColor : "gray") +
            "-500 font-bold") &&
          L(r, "class", l),
          1 & e && _ !== (_ = (t[0].status ? t[0].status : "") + "") && M(u, _),
          2 & e &&
          d !==
          (d = "wgt-adt-stl truncate " + (t[1] ? "text-green-500" : "")) &&
          L(a, "class", d),
          1 & e && j !== (j = (t[0].after ? t[0].after : "") + "") && M(h, j),
          2 & e &&
          v !==
          (v = "wgt-adt-stl truncate " + (t[1] ? "text-green-500" : "")) &&
          L(p, "class", v);
      },
      i: t,
      o: t,
      d(t) {
        t && x(n);
      },
    };
  }
  function He(t, e, n) {
    let s,
      { widget: r } = e,
      { value: o } = e,
      l = !1;
    function i() {
      n(1, (l = !1));
    }
    return (
      (t.$$set = (t) => {
        "widget" in t && n(0, (r = t.widget)),
          "value" in t && n(2, (o = t.value));
      }),
      (t.$$.update = () => {
        1 & t.$$.dirty &&
          (r.status,
            r.status &&
            (r.status != s && (setTimeout(i, 300), n(1, (l = !0))),
              (s = r.status)));
      }),
      [r, l, o]
    );
  }
  class Ae extends ut {
    constructor(t) {
      super(), at(this, t, He, De, o, { widget: 0, value: 2 });
    }
  }
  function Ie(t, e, n) {
    const s = t.slice();
    return (s[15] = e[n]), (s[17] = n), s;
  }
  function qe(t, e, n) {
    const s = t.slice();
    return (s[18] = e[n]), (s[19] = e), (s[20] = n), s;
  }
  function ze(e) {
    let n, s;
    return (
      (n = new Zt({ props: { title: "Загрузка..." } })),
      {
        c() {
          lt(n.$$.fragment);
        },
        m(t, e) {
          it(n, t, e), (s = !0);
        },
        p: t,
        i(t) {
          s || (st(n.$$.fragment, t), (s = !0));
        },
        o(t) {
          rt(n.$$.fragment, t), (s = !1);
        },
        d(t) {
          ct(n, t);
        },
      }
    );
  }
  function Be(t) {
    let e,
      n,
      s,
      r,
      o,
      l = t[4] && Re(),
      i = t[1],
      c = [];
    for (let e = 0; e < i.length; e += 1) c[e] = Ke(Ie(t, i, e));
    const a = (t) =>
      rt(c[t], 1, 1, () => {
        c[t] = null;
      });
    return {
      c() {
        (e = $("div")), (n = $("div")), l && l.c(), (s = k()), (r = $("div"));
        for (let t = 0; t < c.length; t += 1) c[t].c();
        L(n, "class", "grd-1col1 animate-pulse"),
          L(r, "class", "grd-3col1"),
          L(e, "class", "my-4");
      },
      m(t, i) {
        b(t, e, i), m(e, n), l && l.m(n, null), m(e, s), m(e, r);
        for (let t = 0; t < c.length; t += 1) c[t] && c[t].m(r, null);
        o = !0;
      },
      p(t, e) {
        if (
          (t[4]
            ? l
              ? 16 & e && st(l, 1)
              : ((l = Re()), l.c(), st(l, 1), l.m(n, null))
            : l &&
            (et(),
              rt(l, 1, 1, () => {
                l = null;
              }),
              nt()),
            11 & e)
        ) {
          let n;
          for (i = t[1], n = 0; n < i.length; n += 1) {
            const s = Ie(t, i, n);
            c[n]
              ? (c[n].p(s, e), st(c[n], 1))
              : ((c[n] = Ke(s)), c[n].c(), st(c[n], 1), c[n].m(r, null));
          }
          for (et(), n = i.length; n < c.length; n += 1) a(n);
          nt();
        }
      },
      i(t) {
        if (!o) {
          st(l);
          for (let t = 0; t < i.length; t += 1) st(c[t]);
          o = !0;
        }
      },
      o(t) {
        rt(l), (c = c.filter(Boolean));
        for (let t = 0; t < c.length; t += 1) rt(c[t]);
        o = !1;
      },
      d(t) {
        t && x(e), l && l.d(), v(c, t);
      },
    };
  }
  function Re(t) {
    let e, n;
    return (
      (e = new Kt({
        props: {
          title:
            "Ваша панель управления пуста, вначале добавьте новые элементы в конфигураторе!",
        },
      })),
      {
        c() {
          lt(e.$$.fragment);
        },
        m(t, s) {
          it(e, t, s), (n = !0);
        },
        i(t) {
          n || (st(e.$$.fragment, t), (n = !0));
        },
        o(t) {
          rt(e.$$.fragment, t), (n = !1);
        },
        d(t) {
          ct(e, t);
        },
      }
    );
  }
  function Fe(t) {
    let e,
      n,
      s,
      r,
      o,
      l,
      i = "input" === t[18].widget && Ze(t),
      c = "toggle" === t[18].widget && We(t),
      a = "anydata" === t[18].widget && Ue(t),
      u = "range" === t[18].widget && Ye(t),
      d = "chart" === t[18].widget && Ve(t);
    return {
      c() {
        i && i.c(),
          (e = k()),
          c && c.c(),
          (n = k()),
          a && a.c(),
          (s = k()),
          u && u.c(),
          (r = k()),
          d && d.c(),
          (o = _());
      },
      m(t, f) {
        i && i.m(t, f),
          b(t, e, f),
          c && c.m(t, f),
          b(t, n, f),
          a && a.m(t, f),
          b(t, s, f),
          u && u.m(t, f),
          b(t, r, f),
          d && d.m(t, f),
          b(t, o, f),
          (l = !0);
      },
      p(t, l) {
        "input" === t[18].widget
          ? i
            ? (i.p(t, l), 1 & l && st(i, 1))
            : ((i = Ze(t)), i.c(), st(i, 1), i.m(e.parentNode, e))
          : i &&
          (et(),
            rt(i, 1, 1, () => {
              i = null;
            }),
            nt()),
          "toggle" === t[18].widget
            ? c
              ? (c.p(t, l), 1 & l && st(c, 1))
              : ((c = We(t)), c.c(), st(c, 1), c.m(n.parentNode, n))
            : c &&
            (et(),
              rt(c, 1, 1, () => {
                c = null;
              }),
              nt()),
          "anydata" === t[18].widget
            ? a
              ? (a.p(t, l), 1 & l && st(a, 1))
              : ((a = Ue(t)), a.c(), st(a, 1), a.m(s.parentNode, s))
            : a &&
            (et(),
              rt(a, 1, 1, () => {
                a = null;
              }),
              nt()),
          "range" === t[18].widget
            ? u
              ? (u.p(t, l), 1 & l && st(u, 1))
              : ((u = Ye(t)), u.c(), st(u, 1), u.m(r.parentNode, r))
            : u &&
            (et(),
              rt(u, 1, 1, () => {
                u = null;
              }),
              nt()),
          "chart" === t[18].widget
            ? d
              ? (d.p(t, l), 1 & l && st(d, 1))
              : ((d = Ve(t)), d.c(), st(d, 1), d.m(o.parentNode, o))
            : d &&
            (et(),
              rt(d, 1, 1, () => {
                d = null;
              }),
              nt());
      },
      i(t) {
        l || (st(i), st(c), st(a), st(u), st(d), (l = !0));
      },
      o(t) {
        rt(i), rt(c), rt(a), rt(u), rt(d), (l = !1);
      },
      d(t) {
        i && i.d(t),
          t && x(e),
          c && c.d(t),
          t && x(n),
          a && a.d(t),
          t && x(s),
          u && u.d(t),
          t && x(r),
          d && d.d(t),
          t && x(o);
      },
    };
  }
  function Ze(t) {
    let e, n, s;
    function r(e) {
      t[6](e, t[18]);
    }
    let o = { widget: t[18], wsPush: t[5] };
    return (
      void 0 !== t[18].status && (o.value = t[18].status),
      (e = new ce({ props: o })),
      z.push(() => ot(e, "value", r)),
      {
        c() {
          lt(e.$$.fragment);
        },
        m(t, n) {
          it(e, t, n), (s = !0);
        },
        p(s, r) {
          t = s;
          const o = {};
          1 & r && (o.widget = t[18]),
            8 & r && (o.wsPush = t[5]),
            !n &&
            1 & r &&
            ((n = !0), (o.value = t[18].status), Y(() => (n = !1))),
            e.$set(o);
        },
        i(t) {
          s || (st(e.$$.fragment, t), (s = !0));
        },
        o(t) {
          rt(e.$$.fragment, t), (s = !1);
        },
        d(t) {
          ct(e, t);
        },
      }
    );
  }
  function We(t) {
    let e, n, s;
    function r(e) {
      t[8](e, t[18]);
    }
    let o = { widget: t[18], wsPush: t[7] };
    return (
      void 0 !== t[18].status && (o.value = t[18].status),
      (e = new Pe({ props: o })),
      z.push(() => ot(e, "value", r)),
      {
        c() {
          lt(e.$$.fragment);
        },
        m(t, n) {
          it(e, t, n), (s = !0);
        },
        p(s, r) {
          t = s;
          const o = {};
          1 & r && (o.widget = t[18]),
            8 & r && (o.wsPush = t[7]),
            !n &&
            1 & r &&
            ((n = !0), (o.value = t[18].status), Y(() => (n = !1))),
            e.$set(o);
        },
        i(t) {
          s || (st(e.$$.fragment, t), (s = !0));
        },
        o(t) {
          rt(e.$$.fragment, t), (s = !1);
        },
        d(t) {
          ct(e, t);
        },
      }
    );
  }
  function Ue(t) {
    let e, n, s;
    function r(e) {
      t[9](e, t[18]);
    }
    let o = { widget: t[18] };
    return (
      void 0 !== t[18].status && (o.value = t[18].status),
      (e = new Ae({ props: o })),
      z.push(() => ot(e, "value", r)),
      {
        c() {
          lt(e.$$.fragment);
        },
        m(t, n) {
          it(e, t, n), (s = !0);
        },
        p(s, r) {
          t = s;
          const o = {};
          1 & r && (o.widget = t[18]),
            !n &&
            1 & r &&
            ((n = !0), (o.value = t[18].status), Y(() => (n = !1))),
            e.$set(o);
        },
        i(t) {
          s || (st(e.$$.fragment, t), (s = !0));
        },
        o(t) {
          rt(e.$$.fragment, t), (s = !1);
        },
        d(t) {
          ct(e, t);
        },
      }
    );
  }
  function Ye(t) {
    let e, n, s;
    function r(e) {
      t[11](e, t[18]);
    }
    let o = { widget: t[18], wsPush: t[10] };
    return (
      void 0 !== t[18].status && (o.value = t[18].status),
      (e = new de({ props: o })),
      z.push(() => ot(e, "value", r)),
      {
        c() {
          lt(e.$$.fragment);
        },
        m(t, n) {
          it(e, t, n), (s = !0);
        },
        p(s, r) {
          t = s;
          const o = {};
          1 & r && (o.widget = t[18]),
            8 & r && (o.wsPush = t[10]),
            !n &&
            1 & r &&
            ((n = !0), (o.value = t[18].status), Y(() => (n = !1))),
            e.$set(o);
        },
        i(t) {
          s || (st(e.$$.fragment, t), (s = !0));
        },
        o(t) {
          rt(e.$$.fragment, t), (s = !1);
        },
        d(t) {
          ct(e, t);
        },
      }
    );
  }
  function Ve(t) {
    let e, n, s;
    function r(e) {
      t[12](e, t[18]);
    }
    let o = { widget: t[18] };
    return (
      void 0 !== t[18].status && (o.value = t[18].status),
      (e = new Oe({ props: o })),
      z.push(() => ot(e, "value", r)),
      {
        c() {
          lt(e.$$.fragment);
        },
        m(t, n) {
          it(e, t, n), (s = !0);
        },
        p(s, r) {
          t = s;
          const o = {};
          1 & r && (o.widget = t[18]),
            !n &&
            1 & r &&
            ((n = !0), (o.value = t[18].status), Y(() => (n = !1))),
            e.$set(o);
        },
        i(t) {
          s || (st(e.$$.fragment, t), (s = !0));
        },
        o(t) {
          rt(e.$$.fragment, t), (s = !1);
        },
        d(t) {
          ct(e, t);
        },
      }
    );
  }
  function Xe(t) {
    let e,
      n,
      s = t[18].page === t[15].page && Fe(t);
    return {
      c() {
        s && s.c(), (e = _());
      },
      m(t, r) {
        s && s.m(t, r), b(t, e, r), (n = !0);
      },
      p(t, n) {
        t[18].page === t[15].page
          ? s
            ? (s.p(t, n), 3 & n && st(s, 1))
            : ((s = Fe(t)), s.c(), st(s, 1), s.m(e.parentNode, e))
          : s &&
          (et(),
            rt(s, 1, 1, () => {
              s = null;
            }),
            nt());
      },
      i(t) {
        n || (st(s), (n = !0));
      },
      o(t) {
        rt(s), (n = !1);
      },
      d(t) {
        s && s.d(t), t && x(e);
      },
    };
  }
  function Ge(t) {
    let e,
      n,
      s = t[0],
      r = [];
    for (let e = 0; e < s.length; e += 1) r[e] = Xe(qe(t, s, e));
    const o = (t) =>
      rt(r[t], 1, 1, () => {
        r[t] = null;
      });
    return {
      c() {
        for (let t = 0; t < r.length; t += 1) r[t].c();
        e = k();
      },
      m(t, s) {
        for (let e = 0; e < r.length; e += 1) r[e] && r[e].m(t, s);
        b(t, e, s), (n = !0);
      },
      p(t, n) {
        if (11 & n) {
          let l;
          for (s = t[0], l = 0; l < s.length; l += 1) {
            const o = qe(t, s, l);
            r[l]
              ? (r[l].p(o, n), st(r[l], 1))
              : ((r[l] = Xe(o)),
                r[l].c(),
                st(r[l], 1),
                r[l].m(e.parentNode, e));
          }
          for (et(), l = s.length; l < r.length; l += 1) o(l);
          nt();
        }
      },
      i(t) {
        if (!n) {
          for (let t = 0; t < s.length; t += 1) st(r[t]);
          n = !0;
        }
      },
      o(t) {
        r = r.filter(Boolean);
        for (let t = 0; t < r.length; t += 1) rt(r[t]);
        n = !1;
      },
      d(t) {
        v(r, t), t && x(e);
      },
    };
  }
  function Ke(t) {
    let e, n;
    return (
      (e = new Kt({
        props: {
          title: t[15].page,
          $$slots: { default: [Ge] },
          $$scope: { ctx: t },
        },
      })),
      {
        c() {
          lt(e.$$.fragment);
        },
        m(t, s) {
          it(e, t, s), (n = !0);
        },
        p(t, n) {
          const s = {};
          2 & n && (s.title = t[15].page),
            2097163 & n && (s.$$scope = { dirty: n, ctx: t }),
            e.$set(s);
        },
        i(t) {
          n || (st(e.$$.fragment, t), (n = !0));
        },
        o(t) {
          rt(e.$$.fragment, t), (n = !1);
        },
        d(t) {
          ct(e, t);
        },
      }
    );
  }
  function Qe(t) {
    let e, n, s, r;
    const o = [Be, ze],
      l = [];
    function i(t, e) {
      return t[2] ? 0 : 1;
    }
    return (
      (e = i(t)),
      (n = l[e] = o[e](t)),
      {
        c() {
          n.c(), (s = _());
        },
        m(t, n) {
          l[e].m(t, n), b(t, s, n), (r = !0);
        },
        p(t, [r]) {
          let c = e;
          (e = i(t)),
            e === c
              ? l[e].p(t, r)
              : (et(),
                rt(l[c], 1, 1, () => {
                  l[c] = null;
                }),
                nt(),
                (n = l[e]),
                n ? n.p(t, r) : ((n = l[e] = o[e](t)), n.c()),
                st(n, 1),
                n.m(s.parentNode, s));
        },
        i(t) {
          r || (st(n), (r = !0));
        },
        o(t) {
          rt(n), (r = !1);
        },
        d(t) {
          l[e].d(t), t && x(s);
        },
      }
    );
  }
  function tn(t, e, n) {
    let { layoutJson: s } = e,
      r = !1,
      { pages: o } = e,
      { show: l } = e,
      { wsPush: i = (t, e, n) => { } } = e;
    function c() {
      0 === s.length && n(4, (r = !0));
    }
    return (
      (t.$$set = (t) => {
        "layoutJson" in t && n(0, (s = t.layoutJson)),
          "pages" in t && n(1, (o = t.pages)),
          "show" in t && n(2, (l = t.show)),
          "wsPush" in t && n(3, (i = t.wsPush));
      }),
      (t.$$.update = () => {
        1 & t.$$.dirty && (s.length, n(4, (r = !1)), setTimeout(c, 3e3));
      }),
      [
        s,
        o,
        l,
        i,
        r,
        (t, e, n) => i(t, e, n),
        function (e, r) {
          t.$$.not_equal(r.status, e) && ((r.status = e), n(0, s));
        },
        (t, e, n) => i(t, e, n),
        function (e, r) {
          t.$$.not_equal(r.status, e) && ((r.status = e), n(0, s));
        },
        function (e, r) {
          t.$$.not_equal(r.status, e) && ((r.status = e), n(0, s));
        },
        (t, e, n) => i(t, e, n),
        function (e, r) {
          t.$$.not_equal(r.status, e) && ((r.status = e), n(0, s));
        },
        function (e, r) {
          t.$$.not_equal(r.status, e) && ((r.status = e), n(0, s));
        },
      ]
    );
  }
  class en extends ut {
    constructor(t) {
      super(),
        at(this, t, tn, Qe, o, { layoutJson: 0, pages: 1, show: 2, wsPush: 3 });
    }
  }
  function nn(e) {
    let n, s, o, l, i, c, a;
    return {
      c() {
        (n = w("svg")),
          (s = w("path")),
          (o = w("circle")),
          (l = w("circle")),
          (i = w("circle")),
          L(s, "stroke", "none"),
          L(s, "d", "M0 0h24v24H0z"),
          L(o, "cx", "5"),
          L(o, "cy", "12"),
          L(o, "r", "1"),
          L(l, "cx", "12"),
          L(l, "cy", "12"),
          L(l, "r", "1"),
          L(i, "cx", "19"),
          L(i, "cy", "12"),
          L(i, "r", "1"),
          L(n, "class", "h-6 w-6 text-green-400 cursor-pointer"),
          L(n, "width", "24"),
          L(n, "height", "24"),
          L(n, "viewBox", "0 -2 24 24"),
          L(n, "stroke-width", "2"),
          L(n, "stroke", "currentColor"),
          L(n, "fill", "none"),
          L(n, "stroke-linecap", "round"),
          L(n, "stroke-linejoin", "round");
      },
      m(t, u) {
        b(t, n, u),
          m(n, s),
          m(n, o),
          m(n, l),
          m(n, i),
          c ||
          ((a = j(n, "click", function () {
            r(e[0]()) && e[0]().apply(this, arguments);
          })),
            (c = !0));
      },
      p(t, [n]) {
        e = t;
      },
      i: t,
      o: t,
      d(t) {
        t && x(n), (c = !1), a();
      },
    };
  }
  function sn(t, e, n) {
    let { click: s = () => { } } = e;
    return (
      (t.$$set = (t) => {
        "click" in t && n(0, (s = t.click));
      }),
      [s]
    );
  }
  class rn extends ut {
    constructor(t) {
      super(), at(this, t, sn, nn, o, { click: 0 });
    }
  }
  function on(e) {
    let n, s, o, l, i;
    return {
      c() {
        (n = w("svg")),
          (s = w("line")),
          (o = w("circle")),
          L(s, "x1", "12"),
          L(s, "y1", "18"),
          L(s, "x2", "12"),
          L(s, "y2", "8"),
          L(o, "cx", "12"),
          L(o, "cy", "4"),
          L(o, "r", "1"),
          L(n, "class", "h-6 w-6 text-blue-400 cursor-pointer"),
          L(n, "viewBox", "0 -2 24 24"),
          L(n, "fill", "none"),
          L(n, "stroke", "currentColor"),
          L(n, "stroke-width", "2"),
          L(n, "stroke-linecap", "round"),
          L(n, "stroke-linejoin", "round");
      },
      m(t, c) {
        b(t, n, c),
          m(n, s),
          m(n, o),
          l ||
          ((i = j(n, "click", function () {
            r(e[0]()) && e[0]().apply(this, arguments);
          })),
            (l = !0));
      },
      p(t, [n]) {
        e = t;
      },
      i: t,
      o: t,
      d(t) {
        t && x(n), (l = !1), i();
      },
    };
  }
  function ln(t, e, n) {
    let { click: s = () => { } } = e;
    return (
      (t.$$set = (t) => {
        "click" in t && n(0, (s = t.click));
      }),
      [s]
    );
  }
  class cn extends ut {
    constructor(t) {
      super(), at(this, t, ln, on, o, { click: 0 });
      /*! js-cookie v3.0.5 | MIT */
    }
  }
  function an(t) {
    for (var e = 1; e < arguments.length; e++) {
      var n = arguments[e];
      for (var s in n) t[s] = n[s];
    }
    return t;
  }
  var un = (function t(e, n) {
    function s(t, s, r) {
      if ("undefined" != typeof document) {
        "number" == typeof (r = an({}, n, r)).expires &&
          (r.expires = new Date(Date.now() + 864e5 * r.expires)),
          r.expires && (r.expires = r.expires.toUTCString()),
          (t = encodeURIComponent(t)
            .replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent)
            .replace(/[()]/g, escape));
        var o = "";
        for (var l in r)
          r[l] &&
            ((o += "; " + l), !0 !== r[l] && (o += "=" + r[l].split(";")[0]));
        return (document.cookie = t + "=" + e.write(s, t) + o);
      }
    }
    return Object.create(
      {
        set: s,
        get: function (t) {
          if ("undefined" != typeof document && (!arguments.length || t)) {
            for (
              var n = document.cookie ? document.cookie.split("; ") : [],
              s = {},
              r = 0;
              r < n.length;
              r++
            ) {
              var o = n[r].split("="),
                l = o.slice(1).join("=");
              try {
                var i = decodeURIComponent(o[0]);
                if (((s[i] = e.read(l, i)), t === i)) break;
              } catch (t) { }
            }
            return t ? s[t] : s;
          }
        },
        remove: (t, e) => {
          s(t, "", an({}, e, { expires: -1 }));
        },
        withAttributes: function (e) {
          return t(this.converter, an({}, this.attributes, e));
        },
        withConverter: function (e) {
          return t(an({}, this.converter, e), this.attributes);
        },
      },
      {
        attributes: { value: Object.freeze(n) },
        converter: { value: Object.freeze(e) },
      }
    );
  })(
    {
      read: (t) => (
        '"' === t[0] && (t = t.slice(1, -1)),
        t.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent)
      ),
      write: (t) =>
        encodeURIComponent(t).replace(
          /%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g,
          decodeURIComponent
        ),
    },
    { path: "/" }
  );
  function dn(t, e, n) {
    const s = t.slice();
    return (s[45] = e[n]), s;
  }
  function fn(t, e, n) {
    const s = t.slice();
    return (s[56] = e[n][0]), (s[57] = e[n][1]), s;
  }
  function pn(t, e, n) {
    const s = t.slice();
    return (s[60] = e[n]), (s[61] = e), (s[62] = n), s;
  }
  function gn(t, e, n) {
    const s = t.slice();
    return (s[56] = e[n][0]), (s[63] = e[n][1]), (s[64] = e), (s[65] = n), s;
  }
  function hn(t, e, n) {
    const s = t.slice();
    return (s[66] = e[n]), s;
  }
  function mn(t, e, n) {
    const s = t.slice();
    return (s[69] = e[n]), (s[62] = n), s;
  }
  function bn(t, e, n) {
    const s = t.slice();
    return (s[71] = e[n]), s;
  }
  function xn(e) {
    let n, s;
    return (
      (n = new Zt({ props: { title: "Загрузка..." } })),
      {
        c() {
          lt(n.$$.fragment);
        },
        m(t, e) {
          it(n, t, e), (s = !0);
        },
        p: t,
        i(t) {
          s || (st(n.$$.fragment, t), (s = !0));
        },
        o(t) {
          rt(n.$$.fragment, t), (s = !1);
        },
        d(t) {
          ct(n, t);
        },
      }
    );
  }
  function vn(t) {
    let e, n, s, r, o, l, i, c, a, u, d;
    (s = new Kt({
      props: {
        title: "Конфигуратор",
        $$slots: { default: [En] },
        $$scope: { ctx: t },
      },
    })),
      (o = new Kt({
        props: {
          title: "Сценарии",
          $$slots: { default: [Nn] },
          $$scope: { ctx: t },
        },
      })),
      (c = new Kt({
        props: { $$slots: { default: [Dn] }, $$scope: { ctx: t } },
      }));
    let f = t[14] && Hn(t);
    return {
      c() {
        (e = $("div")),
          (n = $("div")),
          lt(s.$$.fragment),
          (r = k()),
          lt(o.$$.fragment),
          (l = k()),
          (i = $("div")),
          lt(c.$$.fragment),
          (a = k()),
          f && f.c(),
          (u = _()),
          L(n, "class", "grd-2col1"),
          L(e, "class", "my-4"),
          L(i, "class", "grd-1col1");
      },
      m(t, p) {
        b(t, e, p),
          m(e, n),
          it(s, n, null),
          m(n, r),
          it(o, n, null),
          b(t, l, p),
          b(t, i, p),
          it(c, i, null),
          b(t, a, p),
          f && f.m(t, p),
          b(t, u, p),
          (d = !0);
      },
      p(t, e) {
        const n = {};
        (7438 & e[0]) | (4096 & e[2]) && (n.$$scope = { dirty: e, ctx: t }),
          s.$set(n);
        const r = {};
        (8193 & e[0]) | (4096 & e[2]) && (r.$$scope = { dirty: e, ctx: t }),
          o.$set(r);
        const l = {};
        (720 & e[0]) | (4096 & e[2]) && (l.$$scope = { dirty: e, ctx: t }),
          c.$set(l),
          t[14]
            ? f
              ? f.p(t, e)
              : ((f = Hn(t)), f.c(), f.m(u.parentNode, u))
            : f && (f.d(1), (f = null));
      },
      i(t) {
        d ||
          (st(s.$$.fragment, t),
            st(o.$$.fragment, t),
            st(c.$$.fragment, t),
            (d = !0));
      },
      o(t) {
        rt(s.$$.fragment, t),
          rt(o.$$.fragment, t),
          rt(c.$$.fragment, t),
          (d = !1);
      },
      d(t) {
        t && x(e),
          ct(s),
          ct(o),
          t && x(l),
          t && x(i),
          ct(c),
          t && x(a),
          f && f.d(t),
          t && x(u);
      },
    };
  }
  function $n(t) {
    let e, n;
    return {
      c() {
        (e = $("optgroup")), L(e, "label", (n = t[71].header));
      },
      m(t, n) {
        b(t, e, n);
      },
      p(t, s) {
        8 & s[0] && n !== (n = t[71].header) && L(e, "label", n);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function wn(t) {
    let e,
      n,
      s,
      r,
      o = t[71].name + "";
    return {
      c() {
        (e = $("option")),
          (n = y(o)),
          (s = k()),
          (e.__value = r = t[71].num),
          (e.value = e.__value);
      },
      m(t, r) {
        b(t, e, r), m(e, n), m(e, s);
      },
      p(t, s) {
        8 & s[0] && o !== (o = t[71].name + "") && M(n, o),
          8 & s[0] &&
          r !== (r = t[71].num) &&
          ((e.__value = r), (e.value = e.__value));
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function yn(t) {
    let e,
      n,
      s = t[71].header && $n(t),
      r = !t[71].header && wn(t);
    return {
      c() {
        s && s.c(), (e = _()), r && r.c(), (n = _());
      },
      m(t, o) {
        s && s.m(t, o), b(t, e, o), r && r.m(t, o), b(t, n, o);
      },
      p(t, o) {
        t[71].header
          ? s
            ? s.p(t, o)
            : ((s = $n(t)), s.c(), s.m(e.parentNode, e))
          : s && (s.d(1), (s = null)),
          t[71].header
            ? r && (r.d(1), (r = null))
            : r
              ? r.p(t, o)
              : ((r = wn(t)), r.c(), r.m(n.parentNode, n));
      },
      d(t) {
        s && s.d(t), t && x(e), r && r.d(t), t && x(n);
      },
    };
  }
  function kn(t) {
    let e,
      n = t[12],
      s = [];
    for (let e = 0; e < n.length; e += 1) s[e] = _n(mn(t, n, e));
    return {
      c() {
        for (let t = 0; t < s.length; t += 1) s[t].c();
        e = _();
      },
      m(t, n) {
        for (let e = 0; e < s.length; e += 1) s[e] && s[e].m(t, n);
        b(t, e, n);
      },
      p(t, r) {
        if (4096 & r[0]) {
          let o;
          for (n = t[12], o = 0; o < n.length; o += 1) {
            const l = mn(t, n, o);
            s[o]
              ? s[o].p(l, r)
              : ((s[o] = _n(l)), s[o].c(), s[o].m(e.parentNode, e));
          }
          for (; o < s.length; o += 1) s[o].d(1);
          s.length = n.length;
        }
      },
      d(t) {
        v(s, t), t && x(e);
      },
    };
  }
  function _n(t) {
    let e,
      n,
      s,
      r = t[69].topic.ru + "";
    return {
      c() {
        (e = $("option")),
          (n = y(r)),
          (s = k()),
          (e.__value = t[62]),
          (e.value = e.__value);
      },
      m(t, r) {
        b(t, e, r), m(e, n), m(e, s);
      },
      p(t, e) {
        4096 & e[0] && r !== (r = t[69].topic.ru + "") && M(n, r);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function jn(t) {
    let e,
      n,
      s,
      r,
      o = t[66].label + "";
    return {
      c() {
        (e = $("option")),
          (n = y(o)),
          (s = k()),
          (e.__value = r = t[66].name),
          (e.value = e.__value);
      },
      m(t, r) {
        b(t, e, r), m(e, n), m(e, s);
      },
      p(t, s) {
        4 & s[0] && o !== (o = t[66].label + "") && M(n, o),
          4 & s[0] &&
          r !== (r = t[66].name) &&
          ((e.__value = r), (e.value = e.__value));
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function Cn(t) {
    let e,
      n = Object.entries(t[60]),
      s = [];
    for (let e = 0; e < n.length; e += 1) s[e] = Jn(gn(t, n, e));
    return {
      c() {
        for (let t = 0; t < s.length; t += 1) s[t].c();
        e = k();
      },
      m(t, n) {
        for (let e = 0; e < s.length; e += 1) s[e] && s[e].m(t, n);
        b(t, e, n);
      },
      p(t, r) {
        if (258 & r[0]) {
          let o;
          for (n = Object.entries(t[60]), o = 0; o < n.length; o += 1) {
            const l = gn(t, n, o);
            s[o]
              ? s[o].p(l, r)
              : ((s[o] = Jn(l)), s[o].c(), s[o].m(e.parentNode, e));
          }
          for (; o < s.length; o += 1) s[o].d(1);
          s.length = n.length;
        }
      },
      d(t) {
        v(s, t), t && x(e);
      },
    };
  }
  function Ln(t) {
    let e, n, s, r, o, l, i, c;
    function a(t, e) {
      return (
        2 & e[0] && (c = null),
        null == c && (c = !!t[56].startsWith("btn")),
        c ? Mn : Sn
      );
    }
    let u = a(t, [-1, -1, -1]),
      d = u(t);
    return {
      c() {
        (e = $("tr")),
          (n = $("td")),
          (s = k()),
          (r = $("td")),
          (o = k()),
          (l = $("td")),
          (i = k()),
          d.c(),
          L(e, "class", "txt-sz txt-pad");
      },
      m(t, c) {
        b(t, e, c),
          m(e, n),
          m(e, s),
          m(e, r),
          m(e, o),
          m(e, l),
          m(e, i),
          d.m(e, null);
      },
      p(t, n) {
        u === (u = a(t, n)) && d
          ? d.p(t, n)
          : (d.d(1), (d = u(t)), d && (d.c(), d.m(e, null)));
      },
      d(t) {
        t && x(e), d.d();
      },
    };
  }
  function Sn(t) {
    let e,
      n,
      s,
      r,
      o,
      l,
      i,
      c,
      a = t[56] + "";
    function u() {
      t[37].call(l, t[56], t[61], t[62]);
    }
    return {
      c() {
        (e = $("td")),
          (n = $("p")),
          (s = y(a)),
          (r = k()),
          (o = $("td")),
          (l = $("input")),
          L(n, "class", "txt-ita"),
          L(e, "class", "tbl-bdy-sm text-right"),
          L(l, "class", "ipt-sm w-full text-sm"),
          L(l, "type", "text"),
          L(o, "class", "tbl-bdy-sm text-center");
      },
      m(a, d) {
        b(a, e, d),
          m(e, n),
          m(n, s),
          b(a, r, d),
          b(a, o, d),
          m(o, l),
          T(l, t[60][t[56]]),
          i || ((c = j(l, "input", u)), (i = !0));
      },
      p(e, n) {
        (t = e),
          2 & n[0] && a !== (a = t[56] + "") && M(s, a),
          6 & n[0] && l.value !== t[60][t[56]] && T(l, t[60][t[56]]);
      },
      d(t) {
        t && x(e), t && x(r), t && x(o), (i = !1), c();
      },
    };
  }
  function Mn(t) {
    let e,
      n,
      s,
      r,
      o,
      l,
      i,
      c = t[56].substring(4) + "";
    function a() {
      return t[35](t[60], t[56]);
    }
    let u = "nil" != t[60][t[56]] && Tn(t);
    return {
      c() {
        (e = $("td")),
          (n = $("button")),
          (s = y(c)),
          (r = k()),
          u && u.c(),
          (o = _()),
          L(
            n,
            "class",
            "h-3 sm:h-6 md:h-6 lg:h-6 xl:h-6 2xl:h-6 w-auto bg-blue-100 inline-flex items-center border border-gray-300 hover:bg-blue-200"
          ),
          L(e, "class", "tbl-bdy-sm text-right");
      },
      m(t, c) {
        b(t, e, c),
          m(e, n),
          m(n, s),
          b(t, r, c),
          u && u.m(t, c),
          b(t, o, c),
          l || ((i = j(n, "click", a)), (l = !0));
      },
      p(e, n) {
        (t = e),
          2 & n[0] && c !== (c = t[56].substring(4) + "") && M(s, c),
          "nil" != t[60][t[56]]
            ? u
              ? u.p(t, n)
              : ((u = Tn(t)), u.c(), u.m(o.parentNode, o))
            : u && (u.d(1), (u = null));
      },
      d(t) {
        t && x(e), t && x(r), u && u.d(t), t && x(o), (l = !1), i();
      },
    };
  }
  function Tn(t) {
    let e, n, s, r;
    function o() {
      t[36].call(n, t[56], t[61], t[62]);
    }
    return {
      c() {
        (e = $("td")),
          (n = $("input")),
          L(n, "class", "ipt-sm w-full text-sm"),
          L(n, "type", "text"),
          L(e, "class", "tbl-bdy-sm text-center");
      },
      m(l, i) {
        b(l, e, i),
          m(e, n),
          T(n, t[60][t[56]]),
          s || ((r = j(n, "input", o)), (s = !0));
      },
      p(e, s) {
        (t = e), 6 & s[0] && n.value !== t[60][t[56]] && T(n, t[60][t[56]]);
      },
      d(t) {
        t && x(e), (s = !1), r();
      },
    };
  }
  function Jn(t) {
    let e,
      n =
        "type" != t[56] &&
        "subtype" != t[56] &&
        "id" != t[56] &&
        "widget" != t[56] &&
        "page" != t[56] &&
        "descr" != t[56] &&
        "show" != t[56] &&
        Ln(t);
    return {
      c() {
        n && n.c(), (e = _());
      },
      m(t, s) {
        n && n.m(t, s), b(t, e, s);
      },
      p(t, s) {
        "type" != t[56] &&
          "subtype" != t[56] &&
          "id" != t[56] &&
          "widget" != t[56] &&
          "page" != t[56] &&
          "descr" != t[56] &&
          "show" != t[56]
          ? n
            ? n.p(t, s)
            : ((n = Ln(t)), n.c(), n.m(e.parentNode, e))
          : n && (n.d(1), (n = null));
      },
      d(t) {
        n && n.d(t), t && x(e);
      },
    };
  }
  function On(t) {
    let e,
      n,
      r,
      o,
      l,
      i,
      c,
      a,
      u,
      d,
      f,
      p,
      g,
      h,
      w,
      C,
      S,
      J,
      E,
      N,
      P,
      D,
      H,
      A,
      I,
      q,
      z,
      B,
      R,
      F = t[60].subtype + "";
    function Z() {
      t[29].call(i, t[61], t[62]);
    }
    let W = t[2],
      Y = [];
    for (let e = 0; e < W.length; e += 1) Y[e] = jn(hn(t, W, e));
    function V() {
      t[30].call(u, t[61], t[62]);
    }
    function X() {
      t[31].call(p, t[61], t[62]);
    }
    function G() {
      t[32].call(w, t[61], t[62]);
    }
    function K() {
      return t[45](t[60], t[61], t[62]);
    }
    function Q() {
      return t[34](t[60]);
    }
    (J = new rn({ props: { click: K } })),
      (P = new qt({
        props: {
          click: function () {
            return t[33](t[62]);
          },
        },
      })),
      (A = new cn({ props: { click: Q } }));
    let tt = t[60].show && Cn(t);
    return {
      c() {
        (e = $("tr")),
          (n = $("td")),
          (r = y(F)),
          (o = k()),
          (l = $("td")),
          (i = $("input")),
          (c = k()),
          (a = $("td")),
          (u = $("select"));
        for (let t = 0; t < Y.length; t += 1) Y[t].c();
        (d = k()),
          (f = $("td")),
          (p = $("input")),
          (g = k()),
          (h = $("td")),
          (w = $("input")),
          (C = k()),
          (S = $("td")),
          lt(J.$$.fragment),
          (E = k()),
          (N = $("td")),
          lt(P.$$.fragment),
          (D = k()),
          (H = $("td")),
          lt(A.$$.fragment),
          (I = k()),
          tt && tt.c(),
          (q = _()),
          L(n, "class", "tbl-bdy-lg"),
          L(i, "class", "ipt-lg w-full"),
          L(i, "type", "text"),
          L(l, "class", "tbl-bdy-lg"),
          L(u, "class", "ipt-lg w-full"),
          void 0 === t[60].widget && U(V),
          L(a, "class", "tbl-bdy-lg"),
          L(p, "class", "ipt-lg w-full"),
          L(p, "type", "text"),
          L(f, "class", "tbl-bdy-lg"),
          L(w, "class", "ipt-lg w-full"),
          L(w, "type", "text"),
          L(h, "class", "tbl-bdy-lg"),
          L(S, "class", "tbl-bdy-lg"),
          L(N, "class", "tbl-bdy-lg"),
          L(H, "class", "tbl-bdy-lg"),
          L(e, "class", "txt-sz txt-pad align-middle");
      },
      m(s, x) {
        b(s, e, x),
          m(e, n),
          m(n, r),
          m(e, o),
          m(e, l),
          m(l, i),
          T(i, t[60].id),
          m(e, c),
          m(e, a),
          m(a, u);
        for (let t = 0; t < Y.length; t += 1) Y[t] && Y[t].m(u, null);
        O(u, t[60].widget, !0),
          m(e, d),
          m(e, f),
          m(f, p),
          T(p, t[60].page),
          m(e, g),
          m(e, h),
          m(h, w),
          T(w, t[60].descr),
          m(e, C),
          m(e, S),
          it(J, S, null),
          m(e, E),
          m(e, N),
          it(P, N, null),
          m(e, D),
          m(e, H),
          it(A, H, null),
          b(s, I, x),
          tt && tt.m(s, x),
          b(s, q, x),
          (z = !0),
          B ||
          ((R = [
            j(i, "input", Z),
            j(u, "change", V),
            j(p, "input", X),
            j(w, "input", G),
          ]),
            (B = !0));
      },
      p(e, n) {
        if (
          ((t = e),
            (!z || 2 & n[0]) && F !== (F = t[60].subtype + "") && M(r, F),
            6 & n[0] && i.value !== t[60].id && T(i, t[60].id),
            4 & n[0])
        ) {
          let e;
          for (W = t[2], e = 0; e < W.length; e += 1) {
            const s = hn(t, W, e);
            Y[e] ? Y[e].p(s, n) : ((Y[e] = jn(s)), Y[e].c(), Y[e].m(u, null));
          }
          for (; e < Y.length; e += 1) Y[e].d(1);
          Y.length = W.length;
        }
        6 & n[0] && O(u, t[60].widget),
          6 & n[0] && p.value !== t[60].page && T(p, t[60].page),
          6 & n[0] && w.value !== t[60].descr && T(w, t[60].descr);
        const s = {};
        2 & n[0] && (s.click = K), J.$set(s);
        const o = {};
        2 & n[0] && (o.click = Q),
          A.$set(o),
          t[60].show
            ? tt
              ? tt.p(t, n)
              : ((tt = Cn(t)), tt.c(), tt.m(q.parentNode, q))
            : tt && (tt.d(1), (tt = null));
      },
      i(t) {
        z ||
          (st(J.$$.fragment, t),
            st(P.$$.fragment, t),
            st(A.$$.fragment, t),
            (z = !0));
      },
      o(t) {
        rt(J.$$.fragment, t),
          rt(P.$$.fragment, t),
          rt(A.$$.fragment, t),
          (z = !1);
      },
      d(t) {
        t && x(e),
          v(Y, t),
          ct(J),
          ct(P),
          ct(A),
          t && x(I),
          tt && tt.d(t),
          t && x(q),
          (B = !1),
          s(R);
      },
    };
  }
  function En(t) {
    let e,
      n,
      r,
      o,
      l,
      i,
      c,
      a,
      u,
      d,
      f,
      p,
      g = t[3],
      h = [];
    for (let e = 0; e < g.length; e += 1) h[e] = yn(bn(t, g, e));
    let w = t[12] && kn(t),
      y = t[1],
      _ = [];
    for (let e = 0; e < y.length; e += 1) _[e] = On(pn(t, y, e));
    const C = (t) =>
      rt(_[t], 1, 1, () => {
        _[t] = null;
      });
    return {
      c() {
        (e = $("div")), (n = $("select"));
        for (let t = 0; t < h.length; t += 1) h[t].c();
        (r = k()),
          (o = $("select")),
          w && w.c(),
          (l = k()),
          (i = $("table")),
          (c = $("thead")),
          (c.innerHTML =
            '<tr class="txt-sz txt-pad"><th class="tbl-hd">Тип</th> \n              <th class="tbl-hd">Id</th> \n              <th class="tbl-hd">Виджет</th> \n              <th class="tbl-hd">Вкладка</th> \n              <th class="tbl-hd">Название</th> \n              <th class="tbl-hd w-7"></th> \n              <th class="tbl-hd w-7"></th> \n              <th class="tbl-hd w-7"></th></tr>'),
          (a = k()),
          (u = $("tbody"));
        for (let t = 0; t < _.length; t += 1) _[t].c();
        L(n, "class", "slct-lg"),
          void 0 === t[10] && U(() => t[25].call(n)),
          L(o, "class", "slct-lg"),
          void 0 === t[11] && U(() => t[27].call(o)),
          L(e, "class", "grd-2col2"),
          L(c, "class", "bg-gray-100"),
          L(u, "class", "bg-white"),
          L(i, "class", "tbl");
      },
      m(s, g) {
        b(s, e, g), m(e, n);
        for (let t = 0; t < h.length; t += 1) h[t] && h[t].m(n, null);
        O(n, t[10], !0),
          m(e, r),
          m(e, o),
          w && w.m(o, null),
          O(o, t[11], !0),
          b(s, l, g),
          b(s, i, g),
          m(i, c),
          m(i, a),
          m(i, u);
        for (let t = 0; t < _.length; t += 1) _[t] && _[t].m(u, null);
        (d = !0),
          f ||
          ((p = [
            j(n, "change", t[25]),
            j(n, "change", t[26]),
            j(o, "change", t[27]),
            j(o, "change", t[28]),
          ]),
            (f = !0));
      },
      p(t, e) {
        if (8 & e[0]) {
          let s;
          for (g = t[3], s = 0; s < g.length; s += 1) {
            const r = bn(t, g, s);
            h[s] ? h[s].p(r, e) : ((h[s] = yn(r)), h[s].c(), h[s].m(n, null));
          }
          for (; s < h.length; s += 1) h[s].d(1);
          h.length = g.length;
        }
        if (
          (1032 & e[0] && O(n, t[10]),
            t[12]
              ? w
                ? w.p(t, e)
                : ((w = kn(t)), w.c(), w.m(o, null))
              : w && (w.d(1), (w = null)),
            2048 & e[0] && O(o, t[11]),
            4325638 & e[0])
        ) {
          let n;
          for (y = t[1], n = 0; n < y.length; n += 1) {
            const s = pn(t, y, n);
            _[n]
              ? (_[n].p(s, e), st(_[n], 1))
              : ((_[n] = On(s)), _[n].c(), st(_[n], 1), _[n].m(u, null));
          }
          for (et(), n = y.length; n < _.length; n += 1) C(n);
          nt();
        }
      },
      i(t) {
        if (!d) {
          for (let t = 0; t < y.length; t += 1) st(_[t]);
          d = !0;
        }
      },
      o(t) {
        _ = _.filter(Boolean);
        for (let t = 0; t < _.length; t += 1) rt(_[t]);
        d = !1;
      },
      d(t) {
        t && x(e),
          v(h, t),
          w && w.d(),
          t && x(l),
          t && x(i),
          v(_, t),
          (f = !1),
          s(p);
      },
    };
  }
  function Nn(t) {
    let e, n, s;
    return {
      c() {
        (e = $("textarea")),
          L(e, "rows", t[13]),
          L(
            e,
            "class",
            "px-2 bg-gray-50 border-2 border-gray-200 rounded text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-indigo-500 w-full"
          );
      },
      m(r, o) {
        b(r, e, o), T(e, t[0]), n || ((s = j(e, "input", t[38])), (n = !0));
      },
      p(t, n) {
        8192 & n[0] && L(e, "rows", t[13]), 1 & n[0] && T(e, t[0]);
      },
      d(t) {
        t && x(e), (n = !1), s();
      },
    };
  }
  function Pn(e) {
    let n, s, r;
    return {
      c() {
        (n = $("button")),
          (n.textContent = "Опубликовать конфигурацию на портале"),
          L(n, "class", "btn-lg mt-4");
      },
      m(t, o) {
        b(t, n, o), s || ((r = j(n, "click", e[44])), (s = !0));
      },
      p: t,
      d(t) {
        t && x(n), (s = !1), r();
      },
    };
  }
  function Dn(t) {
    let e,
      n,
      r,
      o,
      l,
      i,
      c,
      a,
      u,
      d,
      f,
      p,
      g,
      h,
      v,
      w = t[4] && Pn(t);
    return {
      c() {
        (e = $("div")),
          (n = $("button")),
          (n.textContent = "Сохранить на устройстве"),
          (r = k()),
          (o = $("button")),
          (o.textContent = "Перезагрузить устройство"),
          (l = k()),
          (i = $("button")),
          (i.textContent = "Экспорт конфигурации"),
          (c = k()),
          (a = $("label")),
          (u = $("input")),
          (d = k()),
          (f = y("Импорт конфигурации")),
          (p = k()),
          w && w.c(),
          (g = _()),
          L(n, "class", "btn-lg"),
          L(o, "class", "btn-lg"),
          L(i, "class", "btn-lg"),
          L(u, "accept", "application/JSON"),
          L(u, "type", "file"),
          L(u, "id", "formFile"),
          L(a, "class", "btn-lg cursor-pointer select-none"),
          L(e, "class", "grd-2col1");
      },
      m(s, x) {
        b(s, e, x),
          m(e, n),
          m(e, r),
          m(e, o),
          m(e, l),
          m(e, i),
          m(e, c),
          m(e, a),
          m(a, u),
          m(a, d),
          m(a, f),
          b(s, p, x),
          w && w.m(s, x),
          b(s, g, x),
          h ||
          ((v = [
            j(n, "click", t[39]),
            j(o, "click", t[40]),
            j(i, "click", t[41]),
            j(u, "change", t[42]),
            j(a, "click", t[43]),
          ]),
            (h = !0));
      },
      p(t, e) {
        t[4]
          ? w
            ? w.p(t, e)
            : ((w = Pn(t)), w.c(), w.m(g.parentNode, g))
          : w && (w.d(1), (w = null));
      },
      d(t) {
        t && x(e), t && x(p), w && w.d(t), t && x(g), (h = !1), s(v);
      },
    };
  }
  function Hn(t) {
    let e, n, s, r, o, l, i;
    function c(t, e) {
      return t[15] ? In : An;
    }
    let a = c(t),
      u = a(t);
    return {
      c() {
        (e = $("div")),
          (n = $("div")),
          (s = $("div")),
          u.c(),
          (r = k()),
          (o = $("button")),
          (o.textContent = "Закрыть"),
          L(s, "class", "modal-body p-6 overflow-y-auto"),
          J(s, "max-height", "80vh"),
          L(o, "class", "btn-lg"),
          L(n, "class", "modal bg-white rounded-lg overflow-hidden"),
          L(
            e,
            "class",
            "modal-overlay fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center"
          );
      },
      m(c, a) {
        b(c, e, a),
          m(e, n),
          m(n, s),
          u.m(s, null),
          m(n, r),
          m(n, o),
          l || ((i = j(o, "click", t[23])), (l = !0));
      },
      p(t, e) {
        a === (a = c(t)) && u
          ? u.p(t, e)
          : (u.d(1), (u = a(t)), u && (u.c(), u.m(s, null)));
      },
      d(t) {
        t && x(e), u.d(), (l = !1), i();
      },
    };
  }
  function An(e) {
    let n;
    return {
      c() {
        (n = $("p")),
          (n.textContent = "Данные modinfo.json недоступны"),
          L(n, "class", "text-red-500 mt-2");
      },
      m(t, e) {
        b(t, n, e);
      },
      p: t,
      d(t) {
        t && x(n);
      },
    };
  }
  function In(t) {
    let e,
      n,
      s,
      r,
      o,
      l,
      i,
      c,
      a,
      u,
      d,
      f,
      p,
      g,
      h,
      w,
      _,
      j,
      C,
      S,
      T,
      J,
      O,
      E,
      N,
      P,
      D,
      H,
      A,
      I,
      q,
      z,
      B,
      R = t[15].about.moduleName + "",
      F = t[15].about.authorName + "",
      Z = t[15].about.moduleDesc + "",
      W = Object.entries(t[15].about.propInfo),
      U = [];
    for (let e = 0; e < W.length; e += 1) U[e] = qn(fn(t, W, e));
    function Y(t, e) {
      return (
        32768 & e[0] && (B = null),
        null == B &&
        (B = !(
          !t[15]?.about?.funcInfo || !Array.isArray(t[15].about.funcInfo)
        )),
        B ? Bn : zn
      );
    }
    let V = Y(t, [-1, -1, -1]),
      X = V(t);
    return {
      c() {
        (e = $("div")),
          (n = $("div")),
          (s = $("h4")),
          (s.textContent = "Информация:"),
          (r = k()),
          (o = $("p")),
          (l = $("strong")),
          (l.textContent = "Название модуля:"),
          (i = k()),
          (c = y(R)),
          (a = k()),
          (u = $("p")),
          (d = $("strong")),
          (d.textContent = "Автор:"),
          (f = k()),
          (p = y(F)),
          (g = k()),
          (h = $("p")),
          (w = $("strong")),
          (w.textContent = "Описание:"),
          (_ = k()),
          (j = y(Z)),
          (C = k()),
          (S = $("hr")),
          (T = k()),
          (J = $("div")),
          (O = $("h5")),
          (O.textContent = "Параметры конфигурации:"),
          (E = k()),
          (N = $("ul"));
        for (let t = 0; t < U.length; t += 1) U[t].c();
        (P = k()),
          (D = $("hr")),
          (H = k()),
          (A = $("div")),
          (I = $("h5")),
          (I.textContent = "Функции сценария:"),
          (q = k()),
          (z = $("ul")),
          X.c(),
          L(s, "class", "font-bold mb-2"),
          L(o, "class", "mb-2"),
          L(u, "class", "mb-2"),
          L(h, "class", "mb-2"),
          L(S, "class", "divider my-4"),
          L(n, "class", "section mb-6"),
          L(O, "class", "font-bold mb-2"),
          L(N, "class", "spec-list"),
          L(D, "class", "divider my-4"),
          L(J, "class", "section mb-6"),
          L(I, "class", "font-bold mb-2"),
          L(z, "class", "spec-list"),
          L(A, "class", "section mb-6"),
          L(e, "class", "content");
      },
      m(t, x) {
        b(t, e, x),
          m(e, n),
          m(n, s),
          m(n, r),
          m(n, o),
          m(o, l),
          m(o, i),
          m(o, c),
          m(n, a),
          m(n, u),
          m(u, d),
          m(u, f),
          m(u, p),
          m(n, g),
          m(n, h),
          m(h, w),
          m(h, _),
          m(h, j),
          m(n, C),
          m(n, S),
          m(e, T),
          m(e, J),
          m(J, O),
          m(J, E),
          m(J, N);
        for (let t = 0; t < U.length; t += 1) U[t] && U[t].m(N, null);
        m(J, P),
          m(J, D),
          m(e, H),
          m(e, A),
          m(A, I),
          m(A, q),
          m(A, z),
          X.m(z, null);
      },
      p(t, e) {
        if (
          (32768 & e[0] && R !== (R = t[15].about.moduleName + "") && M(c, R),
            32768 & e[0] && F !== (F = t[15].about.authorName + "") && M(p, F),
            32768 & e[0] && Z !== (Z = t[15].about.moduleDesc + "") && M(j, Z),
            32768 & e[0])
        ) {
          let n;
          for (
            W = Object.entries(t[15].about.propInfo), n = 0;
            n < W.length;
            n += 1
          ) {
            const s = fn(t, W, n);
            U[n] ? U[n].p(s, e) : ((U[n] = qn(s)), U[n].c(), U[n].m(N, null));
          }
          for (; n < U.length; n += 1) U[n].d(1);
          U.length = W.length;
        }
        V === (V = Y(t, e)) && X
          ? X.p(t, e)
          : (X.d(1), (X = V(t)), X && (X.c(), X.m(z, null)));
      },
      d(t) {
        t && x(e), v(U, t), X.d();
      },
    };
  }
  function qn(t) {
    let e,
      n,
      s,
      r,
      o,
      l,
      i,
      c = t[56] + "",
      a = t[57] + "";
    return {
      c() {
        (e = $("li")),
          (n = $("strong")),
          (s = y(c)),
          (r = y(":")),
          (o = k()),
          (l = y(a)),
          (i = k()),
          L(e, "class", "mb-1");
      },
      m(t, c) {
        b(t, e, c), m(e, n), m(n, s), m(n, r), m(e, o), m(e, l), m(e, i);
      },
      p(t, e) {
        32768 & e[0] && c !== (c = t[56] + "") && M(s, c),
          32768 & e[0] && a !== (a = t[57] + "") && M(l, a);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function zn(e) {
    let n;
    return {
      c() {
        (n = $("li")),
          (n.textContent = "У данного модуля нет функций"),
          L(n, "class", "mb-1");
      },
      m(t, e) {
        b(t, n, e);
      },
      p: t,
      d(t) {
        t && x(n);
      },
    };
  }
  function Bn(t) {
    let e,
      n = t[15].about.funcInfo,
      s = [];
    for (let e = 0; e < n.length; e += 1) s[e] = Rn(dn(t, n, e));
    return {
      c() {
        for (let t = 0; t < s.length; t += 1) s[t].c();
        e = _();
      },
      m(t, n) {
        for (let e = 0; e < s.length; e += 1) s[e] && s[e].m(t, n);
        b(t, e, n);
      },
      p(t, r) {
        if (32768 & r[0]) {
          let o;
          for (n = t[15].about.funcInfo, o = 0; o < n.length; o += 1) {
            const l = dn(t, n, o);
            s[o]
              ? s[o].p(l, r)
              : ((s[o] = Rn(l)), s[o].c(), s[o].m(e.parentNode, e));
          }
          for (; o < s.length; o += 1) s[o].d(1);
          s.length = n.length;
        }
      },
      d(t) {
        v(s, t), t && x(e);
      },
    };
  }
  function Rn(t) {
    let e,
      n,
      s,
      r,
      o,
      l,
      i,
      c,
      a,
      u,
      d,
      f = t[45].name + "",
      p = (t[45].params?.join(", ") || " ") + "",
      g = t[45].descr.replace(/\n/g, "<br>") + "";
    return {
      c() {
        (e = $("li")),
          (n = $("strong")),
          (s = y(f)),
          (r = y(" (")),
          (o = y(p)),
          (l = y(")")),
          (i = k()),
          (c = $("br")),
          (a = k()),
          (u = y(g)),
          (d = k()),
          L(e, "class", "mb-1");
      },
      m(t, f) {
        b(t, e, f),
          m(e, n),
          m(n, s),
          m(n, r),
          m(n, o),
          m(n, l),
          m(e, i),
          m(e, c),
          m(e, a),
          m(e, u),
          m(e, d);
      },
      p(t, e) {
        32768 & e[0] && f !== (f = t[45].name + "") && M(s, f),
          32768 & e[0] &&
          p !== (p = (t[45].params?.join(", ") || " ") + "") &&
          M(o, p),
          32768 & e[0] &&
          g !== (g = t[45].descr.replace(/\n/g, "<br>") + "") &&
          M(u, g);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function Fn(t) {
    let e, n, s, r;
    const o = [vn, xn],
      l = [];
    function i(t, e) {
      return t[5] ? 0 : 1;
    }
    return (
      (e = i(t)),
      (n = l[e] = o[e](t)),
      {
        c() {
          n.c(), (s = _());
        },
        m(t, n) {
          l[e].m(t, n), b(t, s, n), (r = !0);
        },
        p(t, r) {
          let c = e;
          (e = i(t)),
            e === c
              ? l[e].p(t, r)
              : (et(),
                rt(l[c], 1, 1, () => {
                  l[c] = null;
                }),
                nt(),
                (n = l[e]),
                n ? n.p(t, r) : ((n = l[e] = o[e](t)), n.c()),
                st(n, 1),
                n.m(s.parentNode, s));
        },
        i(t) {
          r || (st(n), (r = !0));
        },
        o(t) {
          rt(n), (r = !1);
        },
        d(t) {
          l[e].d(t), t && x(s);
        },
      }
    );
  }
  const Zn = "Файл не является файлом конфигурации";
  function Wn(t, e) {
    let n = t - 0.5 + Math.random() * (e - t + 1);
    return Math.round(n);
  }
  function Un(t, e, n) {
    let s,
      { configJson: r } = e,
      { widgetsJson: o } = e,
      { itemsJson: l } = e,
      { scenarioTxt: i } = e,
      { userdata: c } = e,
      { show: a } = e,
      u = 0,
      d = 0,
      f = null,
      { saveConfig: p = () => { } } = e,
      { rebootEsp: g = () => { } } = e,
      h = {};
    function m() {
      for (let t = 0; t < l.length; t++) {
        let e = Object.assign({}, l[t]);
        if (u === e.num) {
          delete e.num,
            delete e.name,
            (e.id = e.id + Wn(0, 100)),
            r.push(e),
            n(1, r),
            n(9, $),
            n(24, v),
            n(10, (u = 0));
          break;
        }
      }
    }
    function b(t) {
      for (let e = 0; e < r.length; e++)
        if (t === e) {
          r.splice(e, 1), n(1, r), n(9, $), n(24, v);
          break;
        }
    }
    function x() {
      (h.mark = "iotm"), (h.config = r);
      let t = ((t) => {
        try {
          t = JSON.stringify(JSON.parse(t), null, 4);
        } catch (e) {
          return t;
        }
        return (t = t
          .replace(/&/g, "&amp;")
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;")).replace(
            /("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g,
            (t) => t
          );
      })(JSON.stringify(h));
      (t = t + "\n\nscenario=>" + i),
        (function (t, e, n) {
          var s = new Blob([t], { type: "application/json" });
          if (window.navigator.msSaveOrOpenBlob)
            window.navigator.msSaveOrOpenBlob(s, e);
          else {
            const t = document.createElement("a");
            document.body.appendChild(t);
            const n = window.URL.createObjectURL(s);
            (t.href = n),
              (t.download = e),
              t.click(),
              setTimeout(() => {
                window.URL.revokeObjectURL(n), document.body.removeChild(t);
              }, 0);
          }
        })(t, "export.json");
    }
    H(async () => {
      await _();
    });
    let v = null,
      $ = null;
    function w() {
      n(9, ($ = null)), (document.getElementById("formFile").value = "");
    }
    let { moduleOrder: y = (t, e, n) => { } } = e;
    const k = async () => {
      let t = {
        category: "",
        topic: { ru: "", en: "" },
        text: { ru: "", en: "" },
        config: r,
        scenario: i,
        gallery: [],
        type: "iotmpost",
        username: c.username,
      };
      const e = un.get("token_iotm2");
      try {
        let n = await fetch(
          "http://" + t[0].ip,
          {
            mode: "cors",
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${e}`,
            },
            body: JSON.stringify(t),
          }
        );
        const s = await n.json();
        n.ok
          ? (console.log(s.result),
            s.result.acknowledged &&
            window.open(
              "http://localhost/configs?id=" +
              s.result.insertedId +
              "&token=" +
              un.get("token_iotm2"),
              "_blank"
            ),
            (errors = [{ msg: "ok_success" }]))
          : (errors = s.message);
      } catch (t) {
        console.log(t);
      }
    },
      _ = async () => {
        try {
          const t = un.get("token_iotm2");
          let e = await fetch(
            "https://live-control.com/iotm/configuration.json",
            {
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${t}`,
              },
              mode: "cors",
              method: "GET",
            }
          );
          e.ok
            ? (n(12, (f = await e.json())), console.log("error", f))
            : console.log("error", e.statusText);
        } catch (t) {
          console.log("error", t);
        }
      };
    function j() {
      n(1, (r = f[d].config)), n(0, (i = f[d].scenario));
    }
    let C = !1,
      L = null;
    function S(t) {
      let e = "Не найдено";
      for (const n of l)
        if (n.header) (e = n.header), console.log("Текущая категория:", e);
        else if (n.moduleName === t)
          return console.log(`Найден модуль ${t} в категории ${e}`), e;
      return console.log("Категория не найдена для", t), e;
    }
    function M(t) {
      S(t.moduleName),
        (async function (t) {
          let e = "undefineded";
          const n = S(t.moduleName);
          "virtual_elments" === n
            ? (e = "virtual")
            : "executive_devices" === n
              ? (e = "exec")
              : "screens" === n
                ? (e = "display")
                : "sensors" === n && (e = "sensors");
          try {
            const n = `https://raw.githubusercontent.com/Mit4el/IoTManager/refs/heads/ver4dev/src/modules/${encodeURIComponent(
              e
            )}/${encodeURIComponent(t.moduleName)}/modinfo.json`;
            console.log("Запрос к:", n);
            const s = await fetch(n);
            if (!s.ok) throw new Error(`Ошибка: ${s.status}`);
            const r = await s.json();
            return console.log("Данные из modinfo.json:", r), r;
          } catch (t) {
            return console.error("Ошибка загрузки modinfo.json:", t), null;
          }
        })(t)
          .then((t) => {
            t
              ? (n(15, (L = t)), console.log("moduleInfo:", L))
              : n(15, (L = null)),
              n(14, (C = !0));
          })
          .catch(() => {
            n(15, (L = null)), n(14, (C = !0));
          });
    }
    return (
      (t.$$set = (t) => {
        "configJson" in t && n(1, (r = t.configJson)),
          "widgetsJson" in t && n(2, (o = t.widgetsJson)),
          "itemsJson" in t && n(3, (l = t.itemsJson)),
          "scenarioTxt" in t && n(0, (i = t.scenarioTxt)),
          "userdata" in t && n(4, (c = t.userdata)),
          "show" in t && n(5, (a = t.show)),
          "saveConfig" in t && n(6, (p = t.saveConfig)),
          "rebootEsp" in t && n(7, (g = t.rebootEsp)),
          "moduleOrder" in t && n(8, (y = t.moduleOrder));
      }),
      (t.$$.update = () => {
        16777728 & t.$$.dirty[0] &&
          $ &&
          ($[0].text().then((t) => {
            if ((n(24, (v = t)), !v.includes("scenario=>")))
              return void window.alert(Zn);
            let e = (function (t, e) {
              let n = t.indexOf("scenario=>");
              return t.substring(0, n);
            })(v),
              s = (function (t, e) {
                let n = t.indexOf(e) + e.length;
                return t.substring(n);
              })(v, "scenario=>");
            if (
              !(function (t) {
                try {
                  JSON.parse(t);
                } catch (t) {
                  return !1;
                }
                return !0;
              })(e)
            )
              return void window.alert(Zn);
            let o = JSON.parse(e);
            "iotm" === o.mark
              ? window.confirm(
                "Применить конфигурацию?\nне забудьте нажать кнопку 'сохранить на устройстве'"
              ) &&
              (n(1, (r = [])),
                n(0, (i = "")),
                n(1, (r = o.config)),
                n(0, (i = s)),
                console.log("config updated"))
              : window.alert(Zn);
          }),
            n(9, ($ = null))),
          1 & t.$$.dirty[0] && n(13, (s = i.split("\n").length + 1));
      }),
      [
        i,
        r,
        o,
        l,
        c,
        a,
        p,
        g,
        y,
        $,
        u,
        d,
        f,
        s,
        C,
        L,
        m,
        b,
        x,
        w,
        k,
        j,
        M,
        function () {
          n(14, (C = !1));
        },
        v,
        function () {
          (u = E(this)), n(10, u), n(3, l);
        },
        () => m(),
        function () {
          (d = E(this)), n(11, d);
        },
        () => j(),
        function (t, e) {
          (t[e].id = this.value), n(1, r), n(9, $), n(24, v), n(2, o);
        },
        function (t, e) {
          (t[e].widget = E(this)), n(1, r), n(9, $), n(24, v), n(2, o);
        },
        function (t, e) {
          (t[e].page = this.value), n(1, r), n(9, $), n(24, v), n(2, o);
        },
        function (t, e) {
          (t[e].descr = this.value), n(1, r), n(9, $), n(24, v), n(2, o);
        },
        (t) => b(t),
        (t) => M(t),
        (t, e) => y(t.id, e.substring(4), t[e]),
        function (t, e, s) {
          (e[s][t] = this.value), n(1, r), n(9, $), n(24, v), n(2, o);
        },
        function (t, e, s) {
          (e[s][t] = this.value), n(1, r), n(9, $), n(24, v), n(2, o);
        },
        function () {
          (i = this.value), n(0, i), n(9, $), n(24, v);
        },
        () => p(),
        () => g(),
        () => x(),
        function () {
          ($ = this.files), n(9, $), n(24, v);
        },
        () => w(),
        () => k(),
        (t, e, s) => n(1, (e[s].show = !t.show), r),
      ]
    );
  }
  class Yn extends ut {
    constructor(t) {
      super(),
        at(
          this,
          t,
          Un,
          Fn,
          o,
          {
            configJson: 1,
            widgetsJson: 2,
            itemsJson: 3,
            scenarioTxt: 0,
            userdata: 4,
            show: 5,
            saveConfig: 6,
            rebootEsp: 7,
            moduleOrder: 8,
          },
          null,
          [-1, -1, -1]
        );
    }
  }
  function Vn(t, e, n) {
    const s = t.slice();
    return (s[23] = e[n][0]), (s[24] = e[n][1]), s;
  }
  function Xn(e) {
    let n, s;
    return (
      (n = new Zt({ props: { title: "Загрузка..." } })),
      {
        c() {
          lt(n.$$.fragment);
        },
        m(t, e) {
          it(n, t, e), (s = !0);
        },
        p: t,
        i(t) {
          s || (st(n.$$.fragment, t), (s = !0));
        },
        o(t) {
          rt(n.$$.fragment, t), (s = !1);
        },
        d(t) {
          ct(n, t);
        },
      }
    );
  }
  function Gn(t) {
    let e, n, s, r, o, l, i, c, a;
    return (
      (s = new Kt({
        props: {
          title: "Подключение к WiFi",
          $$slots: { default: [ts] },
          $$scope: { ctx: t },
        },
      })),
      (o = new Kt({
        props: {
          title: "Подключение к MQTT",
          $$slots: { default: [os] },
          $$scope: { ctx: t },
        },
      })),
      (c = new Kt({
        props: { $$slots: { default: [ls] }, $$scope: { ctx: t } },
      })),
      {
        c() {
          (e = $("div")),
            (n = $("div")),
            lt(s.$$.fragment),
            (r = k()),
            lt(o.$$.fragment),
            (l = k()),
            (i = $("div")),
            lt(c.$$.fragment),
            L(n, "class", "grd-2col1"),
            L(e, "class", "my-4"),
            L(i, "class", "grd-1col1");
        },
        m(t, u) {
          b(t, e, u),
            m(e, n),
            it(s, n, null),
            m(n, r),
            it(o, n, null),
            b(t, l, u),
            b(t, i, u),
            it(c, i, null),
            (a = !0);
        },
        p(t, e) {
          const n = {};
          134217783 & e && (n.$$scope = { dirty: e, ctx: t }), s.$set(n);
          const r = {};
          134217795 & e && (r.$$scope = { dirty: e, ctx: t }), o.$set(r);
          const l = {};
          134217856 & e && (l.$$scope = { dirty: e, ctx: t }), c.$set(l);
        },
        i(t) {
          a ||
            (st(s.$$.fragment, t),
              st(o.$$.fragment, t),
              st(c.$$.fragment, t),
              (a = !0));
        },
        o(t) {
          rt(s.$$.fragment, t),
            rt(o.$$.fragment, t),
            rt(c.$$.fragment, t),
            (a = !1);
        },
        d(t) {
          t && x(e), ct(s), ct(o), t && x(l), t && x(i), ct(c);
        },
      }
    );
  }
  function Kn(t) {
    let e,
      n,
      s,
      r,
      o = t[24] + "";
    return {
      c() {
        (e = $("option")),
          (n = y(o)),
          (s = k()),
          (e.__value = r = t[24]),
          (e.value = e.__value);
      },
      m(t, r) {
        b(t, e, r), m(e, n), m(e, s);
      },
      p(t, s) {
        4 & s && o !== (o = t[24] + "") && M(n, o),
          4 & s &&
          r !== (r = t[24]) &&
          ((e.__value = r), (e.value = e.__value));
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function Qn(t) {
    let e, n, s;
    return (
      (n = new Zt({ props: { title: "Введен неправильный пароль" } })),
      {
        c() {
          (e = $("div")), lt(n.$$.fragment), L(e, "class", "grd-1col1");
        },
        m(t, r) {
          b(t, e, r), it(n, e, null), (s = !0);
        },
        i(t) {
          s || (st(n.$$.fragment, t), (s = !0));
        },
        o(t) {
          rt(n.$$.fragment, t), (s = !1);
        },
        d(t) {
          t && x(e), ct(n);
        },
      }
    );
  }
  function ts(t) {
    let e,
      n,
      r,
      o,
      l,
      i,
      c,
      a,
      u,
      d,
      f,
      p,
      g,
      h,
      w,
      y,
      _,
      C,
      S,
      M,
      J,
      E,
      N,
      P,
      D,
      H,
      A,
      I,
      q,
      z,
      B,
      R,
      F,
      Z,
      W,
      Y,
      V = Object.entries(t[2]),
      X = [];
    for (let e = 0; e < V.length; e += 1) X[e] = Kn(Vn(t, V, e));
    let G = 1 === t[1].passer && Qn();
    return {
      c() {
        (e = $("div")),
          (n = $("div")),
          (n.innerHTML =
            '<p class="wgt-dscr-stl truncate">Название устройства</p>'),
          (r = k()),
          (o = $("div")),
          (l = $("input")),
          (i = k()),
          (c = $("div")),
          (c.innerHTML = '<p class="wgt-dscr-stl truncate">Точка доступа</p>'),
          (a = k()),
          (u = $("div")),
          (d = $("input")),
          (f = k()),
          (p = $("div")),
          (p.innerHTML =
            '<p class="wgt-dscr-stl truncate">Пароль точки доступа</p>'),
          (g = k()),
          (h = $("div")),
          (w = $("input")),
          (y = k()),
          (_ = $("div")),
          (_.innerHTML =
            '<p class="wgt-dscr-stl truncate">Название wifi сети</p>'),
          (C = k()),
          (S = $("div")),
          (M = $("select"));
        for (let t = 0; t < X.length; t += 1) X[t].c();
        (J = k()),
          (E = $("div")),
          (E.innerHTML = '<p class="wgt-dscr-stl truncate">Пароль</p>'),
          (N = k()),
          (P = $("div")),
          (D = $("input")),
          (H = k()),
          (A = $("div")),
          (A.innerHTML =
            '<p class="wgt-dscr-stl truncate">Сервер обновления</p>'),
          (I = k()),
          (q = $("div")),
          (z = $("input")),
          (B = k()),
          G && G.c(),
          (R = k()),
          (F = $("button")),
          (F.textContent = "Сохранить"),
          L(n, "class", "w-full"),
          L(
            l,
            "class",
            "content-center px-2 h-8 bg-gray-50 border-2 border-gray-200 rounded w-full text-gray-700 leading-tight focus:outline-none focus:bg-white text-left focus:border-indigo-500"
          ),
          L(l, "type", "text"),
          L(o, "class", "flex justify-end w-full"),
          L(c, "class", "w-full"),
          L(
            d,
            "class",
            "content-center px-2 h-8 bg-gray-50 border-2 border-gray-200 rounded w-full text-gray-700 leading-tight focus:outline-none focus:bg-white text-left focus:border-indigo-500"
          ),
          L(d, "type", "text"),
          L(u, "class", "flex justify-end w-full"),
          L(p, "class", "w-full"),
          L(
            w,
            "class",
            "content-center px-2 h-8 bg-gray-50 border-2 border-gray-200 rounded w-full text-gray-700 leading-tight focus:outline-none focus:bg-white text-left focus:border-indigo-500"
          ),
          L(h, "class", "flex justify-end w-full"),
          L(_, "class", "w-full"),
          L(
            M,
            "class",
            "content-center px-2 h-8 bg-gray-50 border-2 border-gray-200 rounded w-full text-gray-700 leading-tight focus:outline-none focus:bg-white text-left focus:border-indigo-500"
          ),
          void 0 === t[0].routerssid && U(() => t[11].call(M)),
          L(S, "class", "flex justify-end w-full"),
          L(E, "class", "w-full"),
          L(
            D,
            "class",
            "content-center px-2 h-8 bg-gray-50 border-2 border-gray-200 rounded w-full text-gray-700 leading-tight focus:outline-none focus:bg-white text-left focus:border-indigo-500"
          ),
          L(D, "type", "text"),
          L(P, "class", "flex justify-end w-full"),
          L(A, "class", "w-full"),
          L(
            z,
            "class",
            "content-center px-2 h-8 mb-4 bg-gray-50 border-2 border-gray-200 rounded w-full text-gray-700 leading-tight focus:outline-none focus:bg-white text-left focus:border-indigo-500"
          ),
          L(z, "type", "text"),
          L(q, "class", "flex justify-end w-full"),
          L(e, "class", "grid grid-cols-2 gap-2"),
          L(F, "class", "btn-lg");
      },
      m(s, x) {
        b(s, e, x),
          m(e, n),
          m(e, r),
          m(e, o),
          m(o, l),
          T(l, t[0].name),
          m(e, i),
          m(e, c),
          m(e, a),
          m(e, u),
          m(u, d),
          T(d, t[0].apssid),
          m(e, f),
          m(e, p),
          m(e, g),
          m(e, h),
          m(h, w),
          T(w, t[0].appass),
          m(e, y),
          m(e, _),
          m(e, C),
          m(e, S),
          m(S, M);
        for (let t = 0; t < X.length; t += 1) X[t] && X[t].m(M, null);
        O(M, t[0].routerssid, !0),
          m(e, J),
          m(e, E),
          m(e, N),
          m(e, P),
          m(P, D),
          T(D, t[0].routerpass),
          m(e, H),
          m(e, A),
          m(e, I),
          m(e, q),
          m(q, z),
          T(z, t[0].serverip),
          b(s, B, x),
          G && G.m(s, x),
          b(s, R, x),
          b(s, F, x),
          (Z = !0),
          W ||
          ((Y = [
            j(l, "input", t[8]),
            j(d, "input", t[9]),
            j(w, "input", t[10]),
            j(M, "change", t[11]),
            j(M, "click", t[12]),
            j(D, "input", t[13]),
            j(z, "input", t[14]),
            j(F, "click", t[15]),
          ]),
            (W = !0));
      },
      p(t, e) {
        if (
          (5 & e && l.value !== t[0].name && T(l, t[0].name),
            5 & e && d.value !== t[0].apssid && T(d, t[0].apssid),
            5 & e && w.value !== t[0].appass && T(w, t[0].appass),
            4 & e)
        ) {
          let n;
          for (V = Object.entries(t[2]), n = 0; n < V.length; n += 1) {
            const s = Vn(t, V, n);
            X[n] ? X[n].p(s, e) : ((X[n] = Kn(s)), X[n].c(), X[n].m(M, null));
          }
          for (; n < X.length; n += 1) X[n].d(1);
          X.length = V.length;
        }
        5 & e && O(M, t[0].routerssid),
          5 & e && D.value !== t[0].routerpass && T(D, t[0].routerpass),
          5 & e && z.value !== t[0].serverip && T(z, t[0].serverip),
          1 === t[1].passer
            ? G
              ? 2 & e && st(G, 1)
              : ((G = Qn()), G.c(), st(G, 1), G.m(R.parentNode, R))
            : G &&
            (et(),
              rt(G, 1, 1, () => {
                G = null;
              }),
              nt());
      },
      i(t) {
        Z || (st(G), (Z = !0));
      },
      o(t) {
        rt(G), (Z = !1);
      },
      d(t) {
        t && x(e),
          v(X, t),
          t && x(B),
          G && G.d(t),
          t && x(R),
          t && x(F),
          (W = !1),
          s(Y);
      },
    };
  }
  function es(t) {
    let e;
    return {
      c() {
        (e = $("p")),
          (e.textContent = "Ошибка"),
          L(
            e,
            "class",
            "text-red-500 font-bold h-8 bg-red-50 border-2 border-gray-200 rounded w-full text-center"
          );
      },
      m(t, n) {
        b(t, e, n);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function ns(t) {
    let e;
    return {
      c() {
        (e = $("p")),
          (e.textContent = "Ожидание"),
          L(
            e,
            "class",
            "text-blue-500 font-bold h-8 bg-blue-50 border-2 border-gray-200 rounded w-full text-center"
          );
      },
      m(t, n) {
        b(t, e, n);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function ss(t) {
    let e;
    return {
      c() {
        (e = $("p")),
          (e.textContent = "Подключение"),
          L(
            e,
            "class",
            "text-yellow-500 font-bold h-8 bg-yellow-50 border-2 border-gray-200 rounded w-full text-center"
          );
      },
      m(t, n) {
        b(t, e, n);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function rs(t) {
    let e;
    return {
      c() {
        (e = $("p")),
          (e.textContent = "Подключено"),
          L(
            e,
            "class",
            "text-green-500 font-bold m-0 p-0 h-8 bg-green-50 border-2 border-gray-200 rounded w-full text-center"
          );
      },
      m(t, n) {
        b(t, e, n);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function os(t) {
    let e,
      n,
      r,
      o,
      l,
      i,
      c,
      a,
      u,
      d,
      f,
      p,
      g,
      h,
      v,
      w,
      y,
      _,
      C,
      S,
      M,
      J,
      O,
      E,
      N,
      P,
      D,
      H,
      A,
      I,
      q,
      z,
      B;
    function R(t, e) {
      return "e5" === t[1].mqtt
        ? rs
        : "e13" === t[1].mqtt
          ? ss
          : void 0 === t[1].mqtt
            ? ns
            : es;
    }
    let F = R(t),
      Z = F(t);
    return {
      c() {
        (e = $("div")),
          (n = $("div")),
          (n.innerHTML =
            '<p class="wgt-dscr-stl text-gray-500 truncate">Состояние подключения</p>'),
          (r = k()),
          (o = $("div")),
          Z.c(),
          (l = k()),
          (i = $("div")),
          (i.innerHTML =
            '<p class="wgt-dscr-stl truncate">Название сервера</p>'),
          (c = k()),
          (a = $("div")),
          (u = $("input")),
          (d = k()),
          (f = $("div")),
          (f.innerHTML = '<p class="wgt-dscr-stl truncate">Порт</p>'),
          (p = k()),
          (g = $("div")),
          (h = $("input")),
          (v = k()),
          (w = $("div")),
          (w.innerHTML = '<p class="wgt-dscr-stl truncate">Префикс</p>'),
          (y = k()),
          (_ = $("div")),
          (C = $("input")),
          (S = k()),
          (M = $("div")),
          (M.innerHTML =
            '<p class="wgt-dscr-stl truncate">Имя пользователя</p>'),
          (J = k()),
          (O = $("div")),
          (E = $("input")),
          (N = k()),
          (P = $("div")),
          (P.innerHTML = '<p class="wgt-dscr-stl truncate">Пароль</p>'),
          (D = k()),
          (H = $("div")),
          (A = $("input")),
          (I = k()),
          (q = $("button")),
          (q.textContent = "Сохранить"),
          L(n, "class", "w-full"),
          L(
            o,
            "class",
            "flex justify-center w-full align-baseline text-sm sm:text-sm md:text-base lg:text-base xl:text-base 2xl:text-base truncate align-text-middle"
          ),
          L(i, "class", "w-full"),
          L(
            u,
            "class",
            "content-center px-2 h-8 bg-gray-50 border-2 border-gray-200 rounded w-full text-gray-700 leading-tight focus:outline-none focus:bg-white text-left focus:border-indigo-500"
          ),
          L(u, "type", "text"),
          L(a, "class", "flex justify-end w-full"),
          L(f, "class", "w-full"),
          L(
            h,
            "class",
            "content-center px-2 h-8 bg-gray-50 border-2 border-gray-200 rounded w-full text-gray-700 leading-tight focus:outline-none focus:bg-white text-left focus:border-indigo-500"
          ),
          L(h, "type", "text"),
          L(g, "class", "flex justify-end w-full"),
          L(w, "class", "w-full"),
          L(
            C,
            "class",
            "content-center px-2 h-8 bg-gray-50 border-2 border-gray-200 rounded w-full text-gray-700 leading-tight focus:outline-none focus:bg-white text-left focus:border-indigo-500"
          ),
          L(C, "type", "text"),
          L(_, "class", "flex justify-end w-full"),
          L(M, "class", "w-full"),
          L(
            E,
            "class",
            "content-center px-2 h-8 bg-gray-50 border-2 border-gray-200 rounded w-full text-gray-700 leading-tight focus:outline-none focus:bg-white text-left focus:border-indigo-500"
          ),
          L(E, "type", "text"),
          L(O, "class", "flex justify-end w-full"),
          L(P, "class", "w-full"),
          L(
            A,
            "class",
            "content-center px-2 h-8 mb-4 bg-gray-50 border-2 border-gray-200 rounded w-full text-gray-700 leading-tight focus:outline-none focus:bg-white text-left focus:border-indigo-500"
          ),
          L(A, "type", "text"),
          L(H, "class", "flex justify-end w-full"),
          L(e, "class", "grid grid-cols-2 gap-2"),
          L(q, "class", "btn-lg");
      },
      m(s, x) {
        b(s, e, x),
          m(e, n),
          m(e, r),
          m(e, o),
          Z.m(o, null),
          m(e, l),
          m(e, i),
          m(e, c),
          m(e, a),
          m(a, u),
          T(u, t[0].mqttServer),
          m(e, d),
          m(e, f),
          m(e, p),
          m(e, g),
          m(g, h),
          T(h, t[0].mqttPort),
          m(e, v),
          m(e, w),
          m(e, y),
          m(e, _),
          m(_, C),
          T(C, t[0].mqttPrefix),
          m(e, S),
          m(e, M),
          m(e, J),
          m(e, O),
          m(O, E),
          T(E, t[0].mqttUser),
          m(e, N),
          m(e, P),
          m(e, D),
          m(e, H),
          m(H, A),
          T(A, t[0].mqttPass),
          b(s, I, x),
          b(s, q, x),
          z ||
          ((B = [
            j(u, "input", t[16]),
            j(h, "input", t[17]),
            j(C, "input", t[18]),
            j(E, "input", t[19]),
            j(A, "input", t[20]),
            j(q, "click", t[21]),
          ]),
            (z = !0));
      },
      p(t, e) {
        F !== (F = R(t)) && (Z.d(1), (Z = F(t)), Z && (Z.c(), Z.m(o, null))),
          5 & e && u.value !== t[0].mqttServer && T(u, t[0].mqttServer),
          5 & e && h.value !== t[0].mqttPort && T(h, t[0].mqttPort),
          5 & e && C.value !== t[0].mqttPrefix && T(C, t[0].mqttPrefix),
          5 & e && E.value !== t[0].mqttUser && T(E, t[0].mqttUser),
          5 & e && A.value !== t[0].mqttPass && T(A, t[0].mqttPass);
      },
      d(t) {
        t && x(e), Z.d(), t && x(I), t && x(q), (z = !1), s(B);
      },
    };
  }
  function ls(e) {
    let n, s, r;
    return {
      c() {
        (n = $("button")),
          (n.textContent = "Перезагрузить устройство"),
          L(n, "class", "btn-lg");
      },
      m(t, o) {
        b(t, n, o), s || ((r = j(n, "click", e[22])), (s = !0));
      },
      p: t,
      d(t) {
        t && x(n), (s = !1), r();
      },
    };
  }
  function is(t) {
    let e, n, s, r;
    const o = [Gn, Xn],
      l = [];
    function i(t, e) {
      return t[3] ? 0 : 1;
    }
    return (
      (e = i(t)),
      (n = l[e] = o[e](t)),
      {
        c() {
          n.c(), (s = _());
        },
        m(t, n) {
          l[e].m(t, n), b(t, s, n), (r = !0);
        },
        p(t, [r]) {
          let c = e;
          (e = i(t)),
            e === c
              ? l[e].p(t, r)
              : (et(),
                rt(l[c], 1, 1, () => {
                  l[c] = null;
                }),
                nt(),
                (n = l[e]),
                n ? n.p(t, r) : ((n = l[e] = o[e](t)), n.c()),
                st(n, 1),
                n.m(s.parentNode, s));
        },
        i(t) {
          r || (st(n), (r = !0));
        },
        o(t) {
          rt(n), (r = !1);
        },
        d(t) {
          l[e].d(t), t && x(s);
        },
      }
    );
  }
  function cs(t, e, n) {
    let { settingsJson: s } = e,
      { errorsJson: r } = e,
      { ssidJson: o } = e,
      { show: l } = e,
      { ssidClick: i = () => { } } = e,
      { saveSett: c = () => { } } = e,
      { saveMqtt: a = () => { } } = e,
      { rebootEsp: u = () => { } } = e;
    return (
      (t.$$set = (t) => {
        "settingsJson" in t && n(0, (s = t.settingsJson)),
          "errorsJson" in t && n(1, (r = t.errorsJson)),
          "ssidJson" in t && n(2, (o = t.ssidJson)),
          "show" in t && n(3, (l = t.show)),
          "ssidClick" in t && n(4, (i = t.ssidClick)),
          "saveSett" in t && n(5, (c = t.saveSett)),
          "saveMqtt" in t && n(6, (a = t.saveMqtt)),
          "rebootEsp" in t && n(7, (u = t.rebootEsp));
      }),
      [
        s,
        r,
        o,
        l,
        i,
        c,
        a,
        u,
        function () {
          (s.name = this.value), n(0, s), n(2, o);
        },
        function () {
          (s.apssid = this.value), n(0, s), n(2, o);
        },
        function () {
          (s.appass = this.value), n(0, s), n(2, o);
        },
        function () {
          (s.routerssid = E(this)), n(0, s), n(2, o);
        },
        () => i(),
        function () {
          (s.routerpass = this.value), n(0, s), n(2, o);
        },
        function () {
          (s.serverip = this.value), n(0, s), n(2, o);
        },
        () => c(),
        function () {
          (s.mqttServer = this.value), n(0, s), n(2, o);
        },
        function () {
          (s.mqttPort = this.value), n(0, s), n(2, o);
        },
        function () {
          (s.mqttPrefix = this.value), n(0, s), n(2, o);
        },
        function () {
          (s.mqttUser = this.value), n(0, s), n(2, o);
        },
        function () {
          (s.mqttPass = this.value), n(0, s), n(2, o);
        },
        () => a(),
        () => u(),
      ]
    );
  }
  class as extends ut {
    constructor(t) {
      super(),
        at(this, t, cs, is, o, {
          settingsJson: 0,
          errorsJson: 1,
          ssidJson: 2,
          show: 3,
          ssidClick: 4,
          saveSett: 5,
          saveMqtt: 6,
          rebootEsp: 7,
        });
    }
  }
  function us(t, e, n) {
    const s = t.slice();
    return (s[23] = e[n]), (s[25] = n), s;
  }
  function ds(e) {
    let n, s;
    return (
      (n = new Zt({ props: { title: "Загрузка..." } })),
      {
        c() {
          lt(n.$$.fragment);
        },
        m(t, e) {
          it(n, t, e), (s = !0);
        },
        p: t,
        i(t) {
          s || (st(n.$$.fragment, t), (s = !0));
        },
        o(t) {
          rt(n.$$.fragment, t), (s = !1);
        },
        d(t) {
          ct(n, t);
        },
      }
    );
  }
  function fs(t) {
    let e, n, s, r, o, l;
    return (
      (s = new Kt({
        props: {
          title: t[4].udps
            ? "Список устройств (авто режим)"
            : "Список устройств (ручной режим)",
          $$slots: { default: [ms] },
          $$scope: { ctx: t },
        },
      })),
      (o = new Zt({
        props: { $$slots: { default: [bs] }, $$scope: { ctx: t } },
      })),
      {
        c() {
          (e = $("div")),
            (n = $("div")),
            lt(s.$$.fragment),
            (r = k()),
            lt(o.$$.fragment),
            L(n, "class", "grd-1col1"),
            L(e, "class", "my-4");
        },
        m(t, i) {
          b(t, e, i),
            m(e, n),
            it(s, n, null),
            m(e, r),
            it(o, e, null),
            (l = !0);
        },
        p(t, e) {
          const n = {};
          16 & e &&
            (n.title = t[4].udps
              ? "Список устройств (авто режим)"
              : "Список устройств (ручной режим)"),
            67108990 & e && (n.$$scope = { dirty: e, ctx: t }),
            s.$set(n);
          const r = {};
          67108864 & e && (r.$$scope = { dirty: e, ctx: t }), o.$set(r);
        },
        i(t) {
          l || (st(s.$$.fragment, t), st(o.$$.fragment, t), (l = !0));
        },
        o(t) {
          rt(s.$$.fragment, t), rt(o.$$.fragment, t), (l = !1);
        },
        d(t) {
          t && x(e), ct(s), ct(o);
        },
      }
    );
  }
  function ps(t) {
    let e,
      n,
      s,
      r,
      o,
      l,
      i,
      c,
      a,
      u,
      d,
      f,
      p,
      g,
      h,
      v,
      w,
      _,
      j,
      C,
      S,
      T,
      J,
      O,
      E,
      N,
      P = t[23].ws + 1 + "",
      D = t[23].name + "",
      H = t[0].ip + "",
      A = t[23].id + "",
      I = (t[23].fv ? t[23].fv : "-") + "",
      q = t[23].status ? "online" : "offline",
      z = (t[23].ping ? t[23].ping : "-") + "",
      B =
        t[25] > 0 &&
        (function (t) {
          let e, n, s;
          return (
            (n = new qt({ props: { click: () => t[14](t[25]) } })),
            {
              c() {
                (e = $("td")), lt(n.$$.fragment), L(e, "class", "tbl-bdy-lg");
              },
              m(t, r) {
                b(t, e, r), it(n, e, null), (s = !0);
              },
              p(e, n) {
                t = e;
              },
              i(t) {
                s || (st(n.$$.fragment, t), (s = !0));
              },
              o(t) {
                rt(n.$$.fragment, t), (s = !1);
              },
              d(t) {
                t && x(e), ct(n);
              },
            }
          );
        })(t);
    return {
      c() {
        (e = $("tr")),
          (n = $("td")),
          (s = y(P)),
          (r = k()),
          (o = $("td")),
          (l = y(D)),
          (i = k()),
          (c = $("td")),
          (a = $("a")),
          (u = y(H)),
          (f = k()),
          (p = $("td")),
          (g = y(A)),
          (h = k()),
          (v = $("td")),
          (w = y(I)),
          (_ = k()),
          (j = $("td")),
          (C = y(q)),
          (T = k()),
          (J = $("td")),
          (O = y(z)),
          (E = k()),
          B && B.c(),
          L(n, "class", "tbl-bdy-lg ipt-lg w-full"),
          L(o, "class", "tbl-bdy-lg ipt-lg w-full"),
          L(a, "href", (d = "http://" + t[0].ip)),
          L(c, "class", "tbl-bdy-lg ipt-lg w-full"),
          L(p, "class", "tbl-bdy-lg ipt-lg w-full"),
          L(v, "class", "tbl-bdy-lg ipt-lg w-full"),
          L(
            j,
            "class",
            (S =
              "tbl-bdy-lg ipt-lg w-full " +
              (t[23].status ? "bg-green-50" : "bg-red-50"))
          ),
          L(J, "class", "tbl-bdy-lg ipt-lg w-full"),
          L(e, "class", "txt-sz txt-pad");
      },
      m(t, d) {
        b(t, e, d),
          m(e, n),
          m(n, s),
          m(e, r),
          m(e, o),
          m(o, l),
          m(e, i),
          m(e, c),
          m(c, a),
          m(a, u),
          m(e, f),
          m(e, p),
          m(p, g),
          m(e, h),
          m(e, v),
          m(v, w),
          m(e, _),
          m(e, j),
          m(j, C),
          m(e, T),
          m(e, J),
          m(J, O),
          m(e, E),
          B && B.m(e, null),
          (N = !0);
      },
      p(t, e) {
        (!N || 2 & e) && P !== (P = t[23].ws + 1 + "") && M(s, P),
          (!N || 2 & e) && D !== (D = t[23].name + "") && M(l, D),
          (!N || 2 & e) && H !== (H = t[0].ip + "") && M(u, H),
          (!N || (2 & e && d !== (d = "http://" + t[0].ip))) &&
          L(a, "href", d),
          (!N || 2 & e) && A !== (A = t[23].id + "") && M(g, A),
          (!N || 2 & e) &&
          I !== (I = (t[23].fv ? t[23].fv : "-") + "") &&
          M(w, I),
          (!N || 2 & e) &&
          q !== (q = t[23].status ? "online" : "offline") &&
          M(C, q),
          (!N ||
            (2 & e &&
              S !==
              (S =
                "tbl-bdy-lg ipt-lg w-full " +
                (t[23].status ? "bg-green-50" : "bg-red-50")))) &&
          L(j, "class", S),
          (!N || 2 & e) &&
          z !== (z = (t[23].ping ? t[23].ping : "-") + "") &&
          M(O, z),
          t[25] > 0 && B.p(t, e);
      },
      i(t) {
        N || (st(B), (N = !0));
      },
      o(t) {
        rt(B), (N = !1);
      },
      d(t) {
        t && x(e), B && B.d();
      },
    };
  }
  function gs(t) {
    let e, n, r, o, l, i, c, a, u, d, f, p, g, h, v;
    return {
      c() {
        (e = $("tr")),
          (n = $("td")),
          (r = k()),
          (o = $("td")),
          (l = $("input")),
          (i = k()),
          (c = $("td")),
          (a = $("input")),
          (u = k()),
          (d = $("td")),
          (f = $("input")),
          (p = k()),
          (g = $("td")),
          L(n, "class", "tbl-bdy-lg"),
          L(l, "class", "ipt-lg w-full m-0"),
          L(l, "type", "text"),
          L(o, "class", "tbl-bdy-lg"),
          L(a, "class", "ipt-lg w-full m-0"),
          L(a, "type", "text"),
          L(c, "class", "tbl-bdy-lg"),
          L(f, "class", "ipt-lg w-full m-0"),
          L(f, "type", "text"),
          L(d, "class", "tbl-bdy-lg"),
          L(g, "class", "tbl-bdy-lg"),
          L(e, "class", "txt-sz txt-pad");
      },
      m(s, x) {
        b(s, e, x),
          m(e, n),
          m(e, r),
          m(e, o),
          m(o, l),
          T(l, t[3].name),
          m(e, i),
          m(e, c),
          m(c, a),
          T(a, t[3].ip),
          m(e, u),
          m(e, d),
          m(d, f),
          T(f, t[3].id),
          m(e, p),
          m(e, g),
          h ||
          ((v = [
            j(l, "input", t[15]),
            j(a, "input", t[16]),
            j(f, "input", t[17]),
          ]),
            (h = !0));
      },
      p(t, e) {
        8 & e && l.value !== t[3].name && T(l, t[3].name),
          8 & e && a.value !== t[3].ip && T(a, t[3].ip),
          8 & e && f.value !== t[3].id && T(f, t[3].id);
      },
      d(t) {
        t && x(e), (h = !1), s(v);
      },
    };
  }
  function hs(e) {
    let n, s, r;
    return {
      c() {
        (n = $("button")),
          (n.textContent = "Добавить устройство"),
          L(n, "class", "btn-lg");
      },
      m(t, o) {
        b(t, n, o), s || ((r = j(n, "click", e[18])), (s = !0));
      },
      p: t,
      d(t) {
        t && x(n), (s = !1), r();
      },
    };
  }
  function ms(t) {
    let e,
      n,
      r,
      o,
      l,
      i,
      c,
      a,
      u,
      d,
      f,
      p,
      g,
      h,
      w,
      y,
      _,
      C,
      S,
      M,
      T,
      O,
      E,
      N,
      P,
      D,
      H,
      A,
      I,
      q,
      z,
      B,
      R,
      F = t[1],
      Z = [];
    for (let e = 0; e < F.length; e += 1) Z[e] = ps(us(t, F, e));
    const W = (t) =>
      rt(Z[t], 1, 1, () => {
        Z[t] = null;
      });
    let U = t[2] && gs(t),
      Y = !t[4].udps && !t[2] && hs(t);
    return {
      c() {
        (e = $("table")),
          (n = $("thead")),
          (n.innerHTML =
            '<tr class="txt-sz txt-pad"><th class="tbl-hd w-7">№</th> \n              <th class="tbl-hd">Название устройства</th> \n              <th class="tbl-hd">IP адрес</th> \n              <th class="tbl-hd">Идентификатор</th> \n              <th class="tbl-hd">Версия</th> \n              <th class="tbl-hd">Состояние</th> \n              <th class="tbl-hd">Пинг</th> \n              <th class="tbl-hd w-7"></th></tr>'),
          (r = k()),
          (o = $("tbody"));
        for (let t = 0; t < Z.length; t += 1) Z[t].c();
        (l = k()),
          U && U.c(),
          (i = k()),
          (c = $("div")),
          (a = $("div")),
          (u = $("div")),
          (d = k()),
          (f = $("div")),
          Y && Y.c(),
          (p = k()),
          (g = $("button")),
          (g.textContent = "Сохранить"),
          (h = k()),
          (w = $("button")),
          (w.textContent = "Перезагрузить все устройства"),
          (_ = k()),
          (C = $("div")),
          (S = $("div")),
          (M = $("div")),
          (M.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">Автоматический поиск устройств по UDP</p>'),
          (T = k()),
          (O = $("div")),
          (E = $("label")),
          (N = $("div")),
          (P = $("input")),
          (D = k()),
          (H = $("div")),
          (I = k()),
          (q = $("div")),
          L(n, "class", "bg-gray-100"),
          L(o, "class", "bg-white"),
          L(e, "class", "tbl mb-0"),
          L(u, "class", "bg-green-300 h-0.5 rounded-full"),
          J(u, "width", t[5] + "%"),
          L(
            a,
            "class",
            "w-full bg-gray-200 rounded-full h-0.5 dark:bg-gray-700"
          ),
          L(c, "class", "mb-4"),
          L(g, "class", "btn-lg"),
          L(w, "class", "btn-lg"),
          L(f, "class", (y = t[4].udps ? "grd-2col1" : "grd-3col1")),
          L(M, "class", "w-3/4"),
          L(P, "id", "udps"),
          L(P, "type", "checkbox"),
          L(P, "class", "sr-only"),
          L(
            H,
            "class",
            (A =
              "block " +
              (t[4].udps ? "bg-blue-600" : "bg-gray-600") +
              " w-10 h-6 rounded-full shadow-lg")
          ),
          L(
            q,
            "class",
            "dot bg-gray-100 absolute left-1 top-1 w-4 h-4 rounded-full transition shadow-lg"
          ),
          L(N, "class", "relative"),
          L(E, "for", "udps"),
          L(E, "class", "items-center cursor-pointer"),
          L(O, "class", "flex justify-end w-1/4"),
          L(S, "class", "flex mb-2 h-6 items-center"),
          L(C, "class", "mt-4");
      },
      m(s, x) {
        b(s, e, x), m(e, n), m(e, r), m(e, o);
        for (let t = 0; t < Z.length; t += 1) Z[t] && Z[t].m(o, null);
        m(o, l),
          U && U.m(o, null),
          b(s, i, x),
          b(s, c, x),
          m(c, a),
          m(a, u),
          b(s, d, x),
          b(s, f, x),
          Y && Y.m(f, null),
          m(f, p),
          m(f, g),
          m(f, h),
          m(f, w),
          b(s, _, x),
          b(s, C, x),
          m(C, S),
          m(S, M),
          m(S, T),
          m(S, O),
          m(O, E),
          m(E, N),
          m(N, P),
          (P.checked = t[4].udps),
          m(N, D),
          m(N, H),
          m(N, I),
          m(N, q),
          (z = !0),
          B ||
          ((R = [
            j(g, "click", t[19]),
            j(w, "click", t[20]),
            j(P, "change", t[21]),
            j(P, "change", t[22]),
          ]),
            (B = !0));
      },
      p(t, e) {
        if (130 & e) {
          let n;
          for (F = t[1], n = 0; n < F.length; n += 1) {
            const s = us(t, F, n);
            Z[n]
              ? (Z[n].p(s, e), st(Z[n], 1))
              : ((Z[n] = ps(s)), Z[n].c(), st(Z[n], 1), Z[n].m(o, l));
          }
          for (et(), n = F.length; n < Z.length; n += 1) W(n);
          nt();
        }
        t[2]
          ? U
            ? U.p(t, e)
            : ((U = gs(t)), U.c(), U.m(o, null))
          : U && (U.d(1), (U = null)),
          (!z || 32 & e) && J(u, "width", t[5] + "%"),
          t[4].udps || t[2]
            ? Y && (Y.d(1), (Y = null))
            : Y
              ? Y.p(t, e)
              : ((Y = hs(t)), Y.c(), Y.m(f, p)),
          (!z ||
            (16 & e && y !== (y = t[4].udps ? "grd-2col1" : "grd-3col1"))) &&
          L(f, "class", y),
          16 & e && (P.checked = t[4].udps),
          (!z ||
            (16 & e &&
              A !==
              (A =
                "block " +
                (t[4].udps ? "bg-blue-600" : "bg-gray-600") +
                " w-10 h-6 rounded-full shadow-lg"))) &&
          L(H, "class", A);
      },
      i(t) {
        if (!z) {
          for (let t = 0; t < F.length; t += 1) st(Z[t]);
          z = !0;
        }
      },
      o(t) {
        Z = Z.filter(Boolean);
        for (let t = 0; t < Z.length; t += 1) rt(Z[t]);
        z = !1;
      },
      d(t) {
        t && x(e),
          v(Z, t),
          U && U.d(),
          t && x(i),
          t && x(c),
          t && x(d),
          t && x(f),
          Y && Y.d(),
          t && x(_),
          t && x(C),
          (B = !1),
          s(R);
      },
    };
  }
  function bs(e) {
    let n;
    return {
      c() {
        (n = $("p")),
          (n.textContent =
            'Авто режим - список создается автоматически, можно нажать кнопку "сохранить список" что бы использовать его потом в ручном режиме. Ручной режим - используется сохраненный список, возможно ручное добавление удаление устройств.');
      },
      m(t, e) {
        b(t, n, e);
      },
      p: t,
      d(t) {
        t && x(n);
      },
    };
  }
  function xs(t) {
    let e, n, s, r;
    const o = [fs, ds],
      l = [];
    function i(t, e) {
      return t[0] ? 0 : 1;
    }
    return (
      (e = i(t)),
      (n = l[e] = o[e](t)),
      {
        c() {
          n.c(), (s = _());
        },
        m(t, n) {
          l[e].m(t, n), b(t, s, n), (r = !0);
        },
        p(t, [r]) {
          let c = e;
          (e = i(t)),
            e === c
              ? l[e].p(t, r)
              : (et(),
                rt(l[c], 1, 1, () => {
                  l[c] = null;
                }),
                nt(),
                (n = l[e]),
                n ? n.p(t, r) : ((n = l[e] = o[e](t)), n.c()),
                st(n, 1),
                n.m(s.parentNode, s));
        },
        i(t) {
          r || (st(n), (r = !0));
        },
        o(t) {
          rt(n), (r = !1);
        },
        d(t) {
          l[e].d(t), t && x(s);
        },
      }
    );
  }
  function vs(t, e, n) {
    let { show: s } = e,
      { deviceList: r } = e,
      { showInput: o } = e,
      { newDevice: l = {} } = e,
      { settingsJson: i } = e,
      { percent: c } = e,
      { addDevInList: a = () => { } } = e,
      { saveList: u = () => { } } = e,
      { saveSett: d = () => { } } = e,
      { sendToAllDevices: f = (t) => { } } = e,
      { applicationReboot: p = () => { } } = e;
    function g(t) {
      for (let e = 0; e < r.length; e++)
        if (t === e) {
          r.splice(e, 1),
            n(1, r),
            console.log("[i]", "item " + t + " deleted from dev list");
          break;
        }
    }
    function h() {
      n(0, (s = !1)), d(), p();
    }
    function m() {
      i.udps
        ? (u(),
          window.alert(
            "Список устройств сохранен в память ESP. Перейдите в ручной режим для использования сохраненного списка"
          ),
          p())
        : o
          ? a()
            ? (u(), n(2, (o = !1)), p())
            : n(2, (o = !1))
          : (u(), p());
    }
    return (
      (t.$$set = (t) => {
        "show" in t && n(0, (s = t.show)),
          "deviceList" in t && n(1, (r = t.deviceList)),
          "showInput" in t && n(2, (o = t.showInput)),
          "newDevice" in t && n(3, (l = t.newDevice)),
          "settingsJson" in t && n(4, (i = t.settingsJson)),
          "percent" in t && n(5, (c = t.percent)),
          "addDevInList" in t && n(10, (a = t.addDevInList)),
          "saveList" in t && n(11, (u = t.saveList)),
          "saveSett" in t && n(12, (d = t.saveSett)),
          "sendToAllDevices" in t && n(6, (f = t.sendToAllDevices)),
          "applicationReboot" in t && n(13, (p = t.applicationReboot));
      }),
      [
        s,
        r,
        o,
        l,
        i,
        c,
        f,
        g,
        h,
        m,
        a,
        u,
        d,
        p,
        (t) => g(t),
        function () {
          (l.name = this.value), n(3, l);
        },
        function () {
          (l.ip = this.value), n(3, l);
        },
        function () {
          (l.id = this.value), n(3, l);
        },
        () => n(2, (o = !o)),
        () => m(),
        (t) => (
          f("/reboot|"), window.alert("Все устройства будут перезагружены")
        ),
        function () {
          (i.udps = this.checked), n(4, i);
        },
        () => h(),
      ]
    );
  }
  class $s extends ut {
    constructor(t) {
      super(),
        at(this, t, vs, xs, o, {
          show: 0,
          deviceList: 1,
          showInput: 2,
          newDevice: 3,
          settingsJson: 4,
          percent: 5,
          addDevInList: 10,
          saveList: 11,
          saveSett: 12,
          sendToAllDevices: 6,
          applicationReboot: 13,
        });
    }
  }
  function ws(t, e, n) {
    const s = t.slice();
    return (s[43] = e[n]), (s[45] = n), s;
  }
  function ys(e) {
    let n, s;
    return (
      (n = new Zt({ props: { title: "Загрузка..." } })),
      {
        c() {
          lt(n.$$.fragment);
        },
        m(t, e) {
          it(n, t, e), (s = !0);
        },
        p: t,
        i(t) {
          s || (st(n.$$.fragment, t), (s = !0));
        },
        o(t) {
          rt(n.$$.fragment, t), (s = !1);
        },
        d(t) {
          ct(n, t);
        },
      }
    );
  }
  function ks(t) {
    let e, n, s, r, o, l, i, c, a, u;
    return (
      (s = new Kt({
        props: {
          title: "Системная информация",
          $$slots: { default: [Js] },
          $$scope: { ctx: t },
        },
      })),
      (o = new Kt({
        props: {
          title: "Системные настройки",
          $$slots: { default: [Ps] },
          $$scope: { ctx: t },
        },
      })),
      (i = new Kt({
        props: {
          title: "Лог",
          $$slots: { default: [Hs] },
          $$scope: { ctx: t },
        },
      })),
      (a = new Kt({
        props: {
          title: "Обновление прошивки",
          $$slots: { default: [qs] },
          $$scope: { ctx: t },
        },
      })),
      {
        c() {
          (e = $("div")),
            (n = $("div")),
            lt(s.$$.fragment),
            (r = k()),
            lt(o.$$.fragment),
            (l = k()),
            lt(i.$$.fragment),
            (c = k()),
            lt(a.$$.fragment),
            L(n, "class", "grd-3col1"),
            L(e, "class", "my-4");
        },
        m(t, d) {
          b(t, e, d),
            m(e, n),
            it(s, n, null),
            m(n, r),
            it(o, n, null),
            m(n, l),
            it(i, n, null),
            m(n, c),
            it(a, n, null),
            (u = !0);
        },
        p(t, e) {
          const n = {};
          (68 & e[0]) | (32768 & e[1]) && (n.$$scope = { dirty: e, ctx: t }),
            s.$set(n);
          const r = {};
          (1267 & e[0]) | (32768 & e[1]) && (r.$$scope = { dirty: e, ctx: t }),
            o.$set(r);
          const l = {};
          (8 & e[0]) | (32768 & e[1]) && (l.$$scope = { dirty: e, ctx: t }),
            i.$set(l);
          const c = {};
          (6400 & e[0]) | (32768 & e[1]) && (c.$$scope = { dirty: e, ctx: t }),
            a.$set(c);
        },
        i(t) {
          u ||
            (st(s.$$.fragment, t),
              st(o.$$.fragment, t),
              st(i.$$.fragment, t),
              st(a.$$.fragment, t),
              (u = !0));
        },
        o(t) {
          rt(s.$$.fragment, t),
            rt(o.$$.fragment, t),
            rt(i.$$.fragment, t),
            rt(a.$$.fragment, t),
            (u = !1);
        },
        d(t) {
          t && x(e), ct(s), ct(o), ct(i), ct(a);
        },
      }
    );
  }
  function _s(t) {
    let e;
    return {
      c() {
        (e = $("p")),
          (e.textContent = "не подключено"),
          L(e, "class", "text-red-500 font-bold text-sm text-center truncate");
      },
      m(t, n) {
        b(t, e, n);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function js(t) {
    let e;
    return {
      c() {
        (e = $("p")),
          (e.textContent = "нет сигнала"),
          L(e, "class", "text-red-500 font-bold text-sm text-center truncate");
      },
      m(t, n) {
        b(t, e, n);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function Cs(t) {
    let e;
    return {
      c() {
        (e = $("p")),
          (e.textContent = "очень низкий"),
          L(e, "class", "text-red-500 font-bold text-sm text-center truncate");
      },
      m(t, n) {
        b(t, e, n);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function Ls(t) {
    let e;
    return {
      c() {
        (e = $("p")),
          (e.textContent = "низкий"),
          L(
            e,
            "class",
            "text-yellow-500 font-bold text-sm text-center truncate"
          );
      },
      m(t, n) {
        b(t, e, n);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function Ss(t) {
    let e;
    return {
      c() {
        (e = $("p")),
          (e.textContent = "хороший"),
          L(
            e,
            "class",
            "text-yellow-500 font-bold text-sm text-center truncate"
          );
      },
      m(t, n) {
        b(t, e, n);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function Ms(t) {
    let e;
    return {
      c() {
        (e = $("p")),
          (e.textContent = "очень хороший"),
          L(
            e,
            "class",
            "text-green-500 font-bold text-sm text-center truncate"
          );
      },
      m(t, n) {
        b(t, e, n);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function Ts(t) {
    let e;
    return {
      c() {
        (e = $("p")),
          (e.textContent = "отличный"),
          L(
            e,
            "class",
            "text-green-500 font-bold text-sm text-center truncate"
          );
      },
      m(t, n) {
        b(t, e, n);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function Js(t) {
    let e,
      n,
      s,
      r,
      o,
      l,
      i,
      c,
      a,
      u,
      d,
      f,
      p,
      g,
      h,
      v,
      w,
      _,
      C,
      S,
      T,
      J,
      O,
      E,
      N,
      P,
      D,
      H,
      A,
      I,
      q,
      z,
      B,
      R,
      F,
      Z,
      W,
      U,
      Y,
      V,
      X,
      G,
      K,
      Q,
      tt,
      et,
      nt,
      st,
      rt,
      ot,
      lt,
      it,
      ct,
      at,
      ut,
      dt,
      ft,
      pt,
      gt,
      ht,
      mt,
      bt,
      xt,
      vt,
      $t,
      wt,
      yt,
      kt,
      _t,
      jt,
      Ct,
      Lt,
      St,
      Mt,
      Tt,
      Jt,
      Ot,
      Et,
      Nt,
      Pt,
      Dt,
      Ht,
      At,
      It,
      qt,
      zt,
      Bt,
      Rt,
      Ft,
      Zt,
      Wt,
      Ut,
      Yt,
      Vt,
      Xt,
      Gt,
      Kt,
      Qt,
      te,
      ee = t[2].bn + "",
      ne = (t[2].bt ? t[2].bt : "-") + "",
      se = t[2].bver + "",
      re = t[2].wver + "",
      oe = t[2].timenow + "",
      le = t[2].upt + "",
      ie = t[2].uptm + "",
      ce = t[2].uptw + "",
      ae = t[2].heap + "",
      ue = t[2].freeBytes + "",
      de = t[2].fl + "",
      fe = t[2].rst + "",
      pe = 0 === t[2].rssi && _s(),
      ge = 1 === t[2].rssi && js(),
      he = 2 === t[2].rssi && Cs(),
      me = 3 === t[2].rssi && Ls(),
      be = 4 === t[2].rssi && Ss(),
      xe = 5 === t[2].rssi && Ms(),
      ve = 6 === t[2].rssi && Ts();
    return {
      c() {
        (e = $("div")),
          (n = $("div")),
          (n.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">Название прошивки</p>'),
          (s = k()),
          (r = $("div")),
          (o = $("p")),
          (l = y(ee)),
          (i = k()),
          (c = $("div")),
          (a = $("div")),
          (a.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">Время компиляции</p>'),
          (u = k()),
          (d = $("div")),
          (f = $("p")),
          (p = y(ne)),
          (g = k()),
          (h = $("div")),
          (v = $("div")),
          (v.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">Версия прошивки</p>'),
          (w = k()),
          (_ = $("div")),
          (C = $("p")),
          (S = y(se)),
          (T = k()),
          (J = $("div")),
          (O = $("div")),
          (O.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">Версия веб интерфейса</p>'),
          (E = k()),
          (N = $("div")),
          (P = $("p")),
          (D = y(re)),
          (H = k()),
          (A = $("div")),
          (I = $("div")),
          (I.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">Время на устройстве</p>'),
          (q = k()),
          (z = $("div")),
          (B = $("p")),
          (R = y(oe)),
          (F = k()),
          (Z = $("div")),
          (W = $("div")),
          (W.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">Uptime устройства</p>'),
          (U = k()),
          (Y = $("div")),
          (V = $("p")),
          (X = y(le)),
          (G = k()),
          (K = $("div")),
          (Q = $("div")),
          (Q.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">Uptime сессии mqtt</p>'),
          (tt = k()),
          (et = $("div")),
          (nt = $("p")),
          (st = y(ie)),
          (rt = k()),
          (ot = $("div")),
          (lt = $("div")),
          (lt.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">Uptime сессии wifi</p>'),
          (it = k()),
          (ct = $("div")),
          (at = $("p")),
          (ut = y(ce)),
          (dt = k()),
          (ft = $("div")),
          (pt = $("div")),
          (pt.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">Качество WiFi сигнала</p>'),
          (gt = k()),
          (ht = $("div")),
          pe && pe.c(),
          (mt = k()),
          ge && ge.c(),
          (bt = k()),
          he && he.c(),
          (xt = k()),
          me && me.c(),
          (vt = k()),
          be && be.c(),
          ($t = k()),
          xe && xe.c(),
          (wt = k()),
          ve && ve.c(),
          (yt = k()),
          (kt = $("div")),
          (_t = $("div")),
          (_t.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">Остаток RAM</p>'),
          (jt = k()),
          (Ct = $("div")),
          (Lt = $("p")),
          (St = y(ae)),
          (Mt = k()),
          (Tt = $("div")),
          (Jt = $("div")),
          (Jt.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">Остаток flash</p>'),
          (Ot = k()),
          (Et = $("div")),
          (Nt = $("p")),
          (Pt = y(ue)),
          (Dt = k()),
          (Ht = $("div")),
          (At = $("div")),
          (At.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">Кол-во записей на flash</p>'),
          (It = k()),
          (qt = $("div")),
          (zt = $("p")),
          (Bt = y(de)),
          (Rt = k()),
          (Ft = $("div")),
          (Zt = $("div")),
          (Zt.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">Причина перезагрузки</p>'),
          (Wt = k()),
          (Ut = $("div")),
          (Yt = $("p")),
          (Vt = y(fe)),
          (Gt = k()),
          (Kt = $("button")),
          (Kt.textContent = "Перезагрузить устройство"),
          L(n, "class", "w-2/3"),
          L(o, "class", "text-gray-500 font-bold text-sm text-center truncate"),
          L(r, "class", "flex justify-center w-1/3"),
          L(e, "class", "flex mb-2 h-6 items-center"),
          L(a, "class", "w-2/3"),
          L(f, "class", "text-gray-500 font-bold text-sm text-center truncate"),
          L(d, "class", "flex justify-center w-1/3"),
          L(c, "class", "flex mb-2 h-6 items-center"),
          L(v, "class", "w-2/3"),
          L(C, "class", "text-gray-500 font-bold text-sm text-center truncate"),
          L(_, "class", "flex justify-center w-1/3"),
          L(h, "class", "flex mb-2 h-6 items-center"),
          L(O, "class", "w-2/3"),
          L(P, "class", "text-gray-500 font-bold text-sm text-center truncate"),
          L(N, "class", "flex justify-center w-1/3"),
          L(J, "class", "flex mb-2 h-6 items-center"),
          L(I, "class", "w-2/3"),
          L(B, "class", "text-gray-500 font-bold text-sm text-center truncate"),
          L(z, "class", "flex justify-center w-1/3"),
          L(A, "class", "flex mb-2 h-6 items-center"),
          L(W, "class", "w-2/3"),
          L(V, "class", "text-gray-500 font-bold text-sm text-center truncate"),
          L(Y, "class", "flex justify-center w-1/3"),
          L(Z, "class", "flex mb-2 h-6 items-center"),
          L(Q, "class", "w-2/3"),
          L(
            nt,
            "class",
            "text-gray-500 font-bold text-sm text-center truncate"
          ),
          L(et, "class", "flex justify-center w-1/3"),
          L(K, "class", "flex mb-2 h-6 items-center"),
          L(lt, "class", "w-2/3"),
          L(
            at,
            "class",
            "text-gray-500 font-bold text-sm text-center truncate"
          ),
          L(ct, "class", "flex justify-center w-1/3"),
          L(ot, "class", "flex mb-2 h-6 items-center"),
          L(pt, "class", "w-2/3"),
          L(
            ht,
            "class",
            "flex justify-center w-1/3 text-xs sm:text-sm md:text-base lg:text-base xl:text-base 2xl:text-base break-words"
          ),
          L(ft, "class", "flex mb-2 h-6 items-center"),
          L(_t, "class", "w-2/3"),
          L(Lt, "class", "text-green-500 font-bold text-center truncate"),
          L(Ct, "class", "flex justify-center w-1/3 text-sm text-center"),
          L(kt, "class", "flex mb-2 h-6 items-center"),
          L(Jt, "class", "w-2/3"),
          L(Nt, "class", "text-green-500 font-bold text-center truncate"),
          L(Et, "class", "flex justify-center w-1/3 text-sm text-center"),
          L(Tt, "class", "flex mb-2 h-6 items-center"),
          L(At, "class", "w-2/3"),
          L(zt, "class", "text-green-500 font-bold text-center truncate"),
          L(qt, "class", "flex justify-center w-1/3 text-sm"),
          L(Ht, "class", "flex mb-2 h-6 items-center"),
          L(Zt, "class", "w-2/3"),
          L(
            Yt,
            "class",
            (Xt =
              (t[2].rst.toString().includes("Watchdog") ||
                t[2].rst.toString().includes("Exception")
                ? "text-red-500"
                : "text-green-500") + " font-bold text-center truncate")
          ),
          L(Ut, "class", "flex justify-center w-1/3 text-sm"),
          L(Ft, "class", "flex mb-2 h-6 items-center"),
          L(Kt, "class", "btn-lg");
      },
      m(x, $) {
        b(x, e, $),
          m(e, n),
          m(e, s),
          m(e, r),
          m(r, o),
          m(o, l),
          b(x, i, $),
          b(x, c, $),
          m(c, a),
          m(c, u),
          m(c, d),
          m(d, f),
          m(f, p),
          b(x, g, $),
          b(x, h, $),
          m(h, v),
          m(h, w),
          m(h, _),
          m(_, C),
          m(C, S),
          b(x, T, $),
          b(x, J, $),
          m(J, O),
          m(J, E),
          m(J, N),
          m(N, P),
          m(P, D),
          b(x, H, $),
          b(x, A, $),
          m(A, I),
          m(A, q),
          m(A, z),
          m(z, B),
          m(B, R),
          b(x, F, $),
          b(x, Z, $),
          m(Z, W),
          m(Z, U),
          m(Z, Y),
          m(Y, V),
          m(V, X),
          b(x, G, $),
          b(x, K, $),
          m(K, Q),
          m(K, tt),
          m(K, et),
          m(et, nt),
          m(nt, st),
          b(x, rt, $),
          b(x, ot, $),
          m(ot, lt),
          m(ot, it),
          m(ot, ct),
          m(ct, at),
          m(at, ut),
          b(x, dt, $),
          b(x, ft, $),
          m(ft, pt),
          m(ft, gt),
          m(ft, ht),
          pe && pe.m(ht, null),
          m(ht, mt),
          ge && ge.m(ht, null),
          m(ht, bt),
          he && he.m(ht, null),
          m(ht, xt),
          me && me.m(ht, null),
          m(ht, vt),
          be && be.m(ht, null),
          m(ht, $t),
          xe && xe.m(ht, null),
          m(ht, wt),
          ve && ve.m(ht, null),
          b(x, yt, $),
          b(x, kt, $),
          m(kt, _t),
          m(kt, jt),
          m(kt, Ct),
          m(Ct, Lt),
          m(Lt, St),
          b(x, Mt, $),
          b(x, Tt, $),
          m(Tt, Jt),
          m(Tt, Ot),
          m(Tt, Et),
          m(Et, Nt),
          m(Nt, Pt),
          b(x, Dt, $),
          b(x, Ht, $),
          m(Ht, At),
          m(Ht, It),
          m(Ht, qt),
          m(qt, zt),
          m(zt, Bt),
          b(x, Rt, $),
          b(x, Ft, $),
          m(Ft, Zt),
          m(Ft, Wt),
          m(Ft, Ut),
          m(Ut, Yt),
          m(Yt, Vt),
          b(x, Gt, $),
          b(x, Kt, $),
          Qt || ((te = j(Kt, "click", t[20])), (Qt = !0));
      },
      p(t, e) {
        4 & e[0] && ee !== (ee = t[2].bn + "") && M(l, ee),
          4 & e[0] && ne !== (ne = (t[2].bt ? t[2].bt : "-") + "") && M(p, ne),
          4 & e[0] && se !== (se = t[2].bver + "") && M(S, se),
          4 & e[0] && re !== (re = t[2].wver + "") && M(D, re),
          4 & e[0] && oe !== (oe = t[2].timenow + "") && M(R, oe),
          4 & e[0] && le !== (le = t[2].upt + "") && M(X, le),
          4 & e[0] && ie !== (ie = t[2].uptm + "") && M(st, ie),
          4 & e[0] && ce !== (ce = t[2].uptw + "") && M(ut, ce),
          0 === t[2].rssi
            ? pe || ((pe = _s()), pe.c(), pe.m(ht, mt))
            : pe && (pe.d(1), (pe = null)),
          1 === t[2].rssi
            ? ge || ((ge = js()), ge.c(), ge.m(ht, bt))
            : ge && (ge.d(1), (ge = null)),
          2 === t[2].rssi
            ? he || ((he = Cs()), he.c(), he.m(ht, xt))
            : he && (he.d(1), (he = null)),
          3 === t[2].rssi
            ? me || ((me = Ls()), me.c(), me.m(ht, vt))
            : me && (me.d(1), (me = null)),
          4 === t[2].rssi
            ? be || ((be = Ss()), be.c(), be.m(ht, $t))
            : be && (be.d(1), (be = null)),
          5 === t[2].rssi
            ? xe || ((xe = Ms()), xe.c(), xe.m(ht, wt))
            : xe && (xe.d(1), (xe = null)),
          6 === t[2].rssi
            ? ve || ((ve = Ts()), ve.c(), ve.m(ht, null))
            : ve && (ve.d(1), (ve = null)),
          4 & e[0] && ae !== (ae = t[2].heap + "") && M(St, ae),
          4 & e[0] && ue !== (ue = t[2].freeBytes + "") && M(Pt, ue),
          4 & e[0] && de !== (de = t[2].fl + "") && M(Bt, de),
          4 & e[0] && fe !== (fe = t[2].rst + "") && M(Vt, fe),
          4 & e[0] &&
          Xt !==
          (Xt =
            (t[2].rst.toString().includes("Watchdog") ||
              t[2].rst.toString().includes("Exception")
              ? "text-red-500"
              : "text-green-500") + " font-bold text-center truncate") &&
          L(Yt, "class", Xt);
      },
      d(t) {
        t && x(e),
          t && x(i),
          t && x(c),
          t && x(g),
          t && x(h),
          t && x(T),
          t && x(J),
          t && x(H),
          t && x(A),
          t && x(F),
          t && x(Z),
          t && x(G),
          t && x(K),
          t && x(rt),
          t && x(ot),
          t && x(dt),
          t && x(ft),
          pe && pe.d(),
          ge && ge.d(),
          he && he.d(),
          me && me.d(),
          be && be.d(),
          xe && xe.d(),
          ve && ve.d(),
          t && x(yt),
          t && x(kt),
          t && x(Mt),
          t && x(Tt),
          t && x(Dt),
          t && x(Ht),
          t && x(Rt),
          t && x(Ft),
          t && x(Gt),
          t && x(Kt),
          (Qt = !1),
          te();
      },
    };
  }
  function Os(t) {
    let e, n, r, o, l, i, c, a, u, d, f, p, g, h, v, w, y, _, C;
    return {
      c() {
        (e = $("div")),
          (n = $("div")),
          (n.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">i2c SCL gpio</p>'),
          (r = k()),
          (o = $("div")),
          (l = $("input")),
          (i = k()),
          (c = $("div")),
          (a = $("div")),
          (a.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">i2c SDA gpio</p>'),
          (u = k()),
          (d = $("div")),
          (f = $("input")),
          (p = k()),
          (g = $("div")),
          (h = $("div")),
          (h.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">i2c частота</p>'),
          (v = k()),
          (w = $("div")),
          (y = $("input")),
          L(n, "class", "w-2/3"),
          L(l, "class", "ipt-rnd h-7 text-center focus:border-indigo-500"),
          L(l, "type", "number"),
          L(o, "class", "flex justify-center w-1/3"),
          L(e, "class", "flex mb-2 h-6 items-center"),
          L(a, "class", "w-2/3"),
          L(f, "class", "ipt-rnd h-7 text-center focus:border-indigo-500"),
          L(f, "type", "number"),
          L(d, "class", "flex justify-center w-1/3"),
          L(c, "class", "flex mb-2 h-6 items-center"),
          L(h, "class", "w-2/3"),
          L(y, "class", "ipt-rnd h-7 text-center focus:border-indigo-500"),
          L(y, "type", "number"),
          L(w, "class", "flex justify-center w-1/3"),
          L(g, "class", "flex mb-2 h-6 items-center");
      },
      m(s, x) {
        b(s, e, x),
          m(e, n),
          m(e, r),
          m(e, o),
          m(o, l),
          T(l, t[0].pinSCL),
          b(s, i, x),
          b(s, c, x),
          m(c, a),
          m(c, u),
          m(c, d),
          m(d, f),
          T(f, t[0].pinSDA),
          b(s, p, x),
          b(s, g, x),
          m(g, h),
          m(g, v),
          m(g, w),
          m(w, y),
          T(y, t[0].i2cFreq),
          _ ||
          ((C = [
            j(l, "input", t[33]),
            j(l, "change", t[34]),
            j(f, "input", t[35]),
            j(f, "change", t[36]),
            j(y, "input", t[37]),
            j(y, "change", t[38]),
          ]),
            (_ = !0));
      },
      p(t, e) {
        1 & e[0] && S(l.value) !== t[0].pinSCL && T(l, t[0].pinSCL),
          1 & e[0] && S(f.value) !== t[0].pinSDA && T(f, t[0].pinSDA),
          1 & e[0] && S(y.value) !== t[0].i2cFreq && T(y, t[0].i2cFreq);
      },
      d(t) {
        t && x(e), t && x(i), t && x(c), t && x(p), t && x(g), (_ = !1), s(C);
      },
    };
  }
  function Es(e) {
    let n, s, r;
    return {
      c() {
        (n = $("button")),
          (n.textContent = "Сохранить"),
          L(n, "class", "btn-lg animate-pulse");
      },
      m(t, o) {
        b(t, n, o), s || ((r = j(n, "click", e[39])), (s = !0));
      },
      p: t,
      d(t) {
        t && x(n), (s = !1), r();
      },
    };
  }
  function Ns(e) {
    let n, s, r;
    return {
      c() {
        (n = $("button")),
          (n.textContent = "Сохранить и перезагрузить"),
          L(n, "class", "btn-lg animate-pulse");
      },
      m(t, o) {
        b(t, n, o), s || ((r = j(n, "click", e[40])), (s = !0));
      },
      p: t,
      d(t) {
        t && x(n), (s = !1), r();
      },
    };
  }
  function Ps(t) {
    let e,
      n,
      r,
      o,
      l,
      i,
      c,
      a,
      u,
      d,
      f,
      p,
      g,
      h,
      v,
      w,
      y,
      C,
      M,
      J,
      O,
      E,
      N,
      P,
      D,
      H,
      A,
      I,
      q,
      z,
      B,
      R,
      F,
      Z,
      W,
      U,
      Y,
      V,
      X,
      G,
      K,
      Q,
      tt,
      et,
      nt,
      st,
      rt,
      ot,
      lt,
      it,
      ct,
      at,
      ut,
      dt,
      ft,
      pt,
      gt,
      ht,
      mt,
      bt,
      xt,
      vt,
      $t,
      wt,
      yt,
      kt,
      _t,
      jt,
      Ct = !0 === t[0].i2c && Os(t),
      Lt = t[1] && Es(t),
      St = t[10] && Ns(t);
    return {
      c() {
        (e = $("div")),
          (n = $("div")),
          (n.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">Часовой пояс</p>'),
          (r = k()),
          (o = $("div")),
          (l = $("input")),
          (i = k()),
          (c = $("div")),
          (a = $("div")),
          (a.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">Данные графиков</p>'),
          (u = k()),
          (d = $("div")),
          (f = $("button")),
          (f.textContent = "Очистить"),
          (p = k()),
          (g = $("div")),
          (h = $("div")),
          (h.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">Время из браузера</p>'),
          (v = k()),
          (w = $("div")),
          (y = $("button")),
          (y.textContent = "Установить"),
          (C = k()),
          (M = $("div")),
          (J = $("div")),
          (J.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">Группа устройств</p>'),
          (O = k()),
          (E = $("div")),
          (N = $("input")),
          (P = k()),
          (D = $("div")),
          (H = $("div")),
          (H.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">Включить лог</p>'),
          (A = k()),
          (I = $("div")),
          (q = $("label")),
          (z = $("div")),
          (B = $("input")),
          (R = k()),
          (F = $("div")),
          (W = k()),
          (U = $("div")),
          (Y = k()),
          (V = $("div")),
          (X = $("div")),
          (X.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">Прием событий с других устройств</p>'),
          (G = k()),
          (K = $("div")),
          (Q = $("label")),
          (tt = $("div")),
          (et = $("input")),
          (nt = k()),
          (st = $("div")),
          (ot = k()),
          (lt = $("div")),
          (it = k()),
          (ct = $("div")),
          (at = $("div")),
          (at.innerHTML =
            '<p class="pr-4 text-gray-500 font-bold text-sm truncate">Перенаправление i2c</p>'),
          (ut = k()),
          (dt = $("div")),
          (ft = $("label")),
          (pt = $("div")),
          (gt = $("input")),
          (ht = k()),
          (mt = $("div")),
          (xt = k()),
          (vt = $("div")),
          ($t = k()),
          Ct && Ct.c(),
          (wt = k()),
          Lt && Lt.c(),
          (yt = k()),
          St && St.c(),
          (kt = _()),
          L(n, "class", "w-2/3"),
          L(l, "class", "ipt-rnd h-7 text-center focus:border-indigo-500"),
          L(l, "type", "number"),
          L(o, "class", "flex justify-center w-1/3"),
          L(e, "class", "flex mb-2 h-6 items-center"),
          L(a, "class", "w-2/3"),
          L(f, "class", "btn-lg h-7"),
          L(d, "class", "flex justify-center w-1/3"),
          L(c, "class", "flex mb-2 h-6 items-center"),
          L(h, "class", "w-2/3"),
          L(y, "class", "btn-lg"),
          L(w, "class", "flex justify-center w-1/3"),
          L(g, "class", "flex mb-2 h-6 items-center"),
          L(J, "class", "w-2/3"),
          L(N, "class", "ipt-rnd h-7 text-center focus:border-indigo-500"),
          L(E, "class", "flex justify-center w-1/3"),
          L(M, "class", "flex mb-2 h-6 items-center"),
          L(H, "class", "w-2/3"),
          L(B, "id", "log"),
          L(B, "type", "checkbox"),
          L(B, "class", "sr-only"),
          L(
            F,
            "class",
            (Z =
              "block " +
              (t[0].log ? "bg-blue-600" : "bg-gray-600") +
              " w-10 h-6 rounded-full shadow-lg")
          ),
          L(
            U,
            "class",
            "dot bg-gray-100 absolute left-1 top-1 w-4 h-4 rounded-full transition shadow-lg"
          ),
          L(z, "class", "relative"),
          L(q, "for", "log"),
          L(q, "class", "items-center cursor-pointer"),
          L(I, "class", "flex justify-center w-1/3"),
          L(D, "class", "flex mb-2 h-6 items-center"),
          L(X, "class", "w-2/3"),
          L(et, "id", "mqtt"),
          L(et, "type", "checkbox"),
          L(et, "class", "sr-only"),
          L(
            st,
            "class",
            (rt =
              "block " +
              (t[0].mqttin ? "bg-blue-600" : "bg-gray-600") +
              " w-10 h-6 rounded-full shadow-lg")
          ),
          L(
            lt,
            "class",
            "dot bg-gray-100 absolute left-1 top-1 w-4 h-4 rounded-full transition shadow-lg"
          ),
          L(tt, "class", "relative"),
          L(Q, "for", "mqtt"),
          L(Q, "class", "items-center cursor-pointer"),
          L(K, "class", "flex justify-center w-1/3"),
          L(V, "class", "flex mb-2 h-6 items-center"),
          L(at, "class", "w-2/3"),
          L(gt, "id", "i2c"),
          L(gt, "type", "checkbox"),
          L(gt, "class", "sr-only"),
          L(
            mt,
            "class",
            (bt =
              "block " +
              (t[0].i2c ? "bg-blue-600" : "bg-gray-600") +
              " w-10 h-6 rounded-full shadow-lg")
          ),
          L(
            vt,
            "class",
            "dot bg-gray-100 absolute left-1 top-1 w-4 h-4 rounded-full transition shadow-lg"
          ),
          L(pt, "class", "relative"),
          L(ft, "for", "i2c"),
          L(ft, "class", "items-center cursor-pointer"),
          L(dt, "class", "flex justify-center w-1/3"),
          L(ct, "class", "flex mb-2 h-6 items-center");
      },
      m(s, x) {
        b(s, e, x),
          m(e, n),
          m(e, r),
          m(e, o),
          m(o, l),
          T(l, t[0].timezone),
          b(s, i, x),
          b(s, c, x),
          m(c, a),
          m(c, u),
          m(c, d),
          m(d, f),
          b(s, p, x),
          b(s, g, x),
          m(g, h),
          m(g, v),
          m(g, w),
          m(w, y),
          b(s, C, x),
          b(s, M, x),
          m(M, J),
          m(M, O),
          m(M, E),
          m(E, N),
          T(N, t[0].wg),
          b(s, P, x),
          b(s, D, x),
          m(D, H),
          m(D, A),
          m(D, I),
          m(I, q),
          m(q, z),
          m(z, B),
          (B.checked = t[0].log),
          m(z, R),
          m(z, F),
          m(z, W),
          m(z, U),
          b(s, Y, x),
          b(s, V, x),
          m(V, X),
          m(V, G),
          m(V, K),
          m(K, Q),
          m(Q, tt),
          m(tt, et),
          (et.checked = t[0].mqttin),
          m(tt, nt),
          m(tt, st),
          m(tt, ot),
          m(tt, lt),
          b(s, it, x),
          b(s, ct, x),
          m(ct, at),
          m(ct, ut),
          m(ct, dt),
          m(dt, ft),
          m(ft, pt),
          m(pt, gt),
          (gt.checked = t[0].i2c),
          m(pt, ht),
          m(pt, mt),
          m(pt, xt),
          m(pt, vt),
          b(s, $t, x),
          Ct && Ct.m(s, x),
          b(s, wt, x),
          Lt && Lt.m(s, x),
          b(s, yt, x),
          St && St.m(s, x),
          b(s, kt, x),
          _t ||
          ((jt = [
            j(l, "input", t[21]),
            j(l, "change", t[22]),
            j(f, "click", t[23]),
            j(y, "click", t[24]),
            j(N, "input", t[25]),
            j(N, "change", t[26]),
            j(B, "change", t[27]),
            j(B, "change", t[28]),
            j(et, "change", t[29]),
            j(et, "change", t[30]),
            j(gt, "change", t[31]),
            j(gt, "change", t[32]),
          ]),
            (_t = !0));
      },
      p(t, e) {
        1 & e[0] && S(l.value) !== t[0].timezone && T(l, t[0].timezone),
          1 & e[0] && N.value !== t[0].wg && T(N, t[0].wg),
          1 & e[0] && (B.checked = t[0].log),
          1 & e[0] &&
          Z !==
          (Z =
            "block " +
            (t[0].log ? "bg-blue-600" : "bg-gray-600") +
            " w-10 h-6 rounded-full shadow-lg") &&
          L(F, "class", Z),
          1 & e[0] && (et.checked = t[0].mqttin),
          1 & e[0] &&
          rt !==
          (rt =
            "block " +
            (t[0].mqttin ? "bg-blue-600" : "bg-gray-600") +
            " w-10 h-6 rounded-full shadow-lg") &&
          L(st, "class", rt),
          1 & e[0] && (gt.checked = t[0].i2c),
          1 & e[0] &&
          bt !==
          (bt =
            "block " +
            (t[0].i2c ? "bg-blue-600" : "bg-gray-600") +
            " w-10 h-6 rounded-full shadow-lg") &&
          L(mt, "class", bt),
          !0 === t[0].i2c
            ? Ct
              ? Ct.p(t, e)
              : ((Ct = Os(t)), Ct.c(), Ct.m(wt.parentNode, wt))
            : Ct && (Ct.d(1), (Ct = null)),
          t[1]
            ? Lt
              ? Lt.p(t, e)
              : ((Lt = Es(t)), Lt.c(), Lt.m(yt.parentNode, yt))
            : Lt && (Lt.d(1), (Lt = null)),
          t[10]
            ? St
              ? St.p(t, e)
              : ((St = Ns(t)), St.c(), St.m(kt.parentNode, kt))
            : St && (St.d(1), (St = null));
      },
      d(t) {
        t && x(e),
          t && x(i),
          t && x(c),
          t && x(p),
          t && x(g),
          t && x(C),
          t && x(M),
          t && x(P),
          t && x(D),
          t && x(Y),
          t && x(V),
          t && x(it),
          t && x(ct),
          t && x($t),
          Ct && Ct.d(t),
          t && x(wt),
          Lt && Lt.d(t),
          t && x(yt),
          St && St.d(t),
          t && x(kt),
          (_t = !1),
          s(jt);
      },
    };
  }
  function Ds(t) {
    let e,
      n,
      s,
      r = t[43].msg + "";
    return {
      c() {
        (e = $("div")),
          (n = y(r)),
          L(
            e,
            "class",
            (s =
              t[43].msg.toString().includes("[E]") ||
                t[43].msg.toString().includes("[!]")
                ? "text-xs text-red-500"
                : "text-xs text-black")
          );
      },
      m(t, s) {
        b(t, e, s), m(e, n);
      },
      p(t, o) {
        8 & o[0] && r !== (r = t[43].msg + "") && M(n, r),
          8 & o[0] &&
          s !==
          (s =
            t[43].msg.toString().includes("[E]") ||
              t[43].msg.toString().includes("[!]")
              ? "text-xs text-red-500"
              : "text-xs text-black") &&
          L(e, "class", s);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function Hs(t) {
    let e,
      n = t[3],
      s = [];
    for (let e = 0; e < n.length; e += 1) s[e] = Ds(ws(t, n, e));
    return {
      c() {
        e = $("div");
        for (let t = 0; t < s.length; t += 1) s[t].c();
        L(e, "class", "h-96 overflow-y-auto");
      },
      m(t, n) {
        b(t, e, n);
        for (let t = 0; t < s.length; t += 1) s[t] && s[t].m(e, null);
      },
      p(t, r) {
        if (8 & r[0]) {
          let o;
          for (n = t[3], o = 0; o < n.length; o += 1) {
            const l = ws(t, n, o);
            s[o] ? s[o].p(l, r) : ((s[o] = Ds(l)), s[o].c(), s[o].m(e, null));
          }
          for (; o < s.length; o += 1) s[o].d(1);
          s.length = n.length;
        }
      },
      d(t) {
        t && x(e), v(s, t);
      },
    };
  }
  function As(e) {
    let n;
    return {
      c() {
        (n = $("p")),
          (n.textContent = "Файл не выбран"),
          L(n, "class", "text-gray-500 text-sm mb-2");
      },
      m(t, e) {
        b(t, n, e);
      },
      p: t,
      d(t) {
        t && x(n);
      },
    };
  }
  function Is(t) {
    let e, n, s, r;
    return {
      c() {
        (e = $("p")),
          (n = y("Выбранный файл: ")),
          (s = $("strong")),
          (r = y(t[12])),
          L(e, "class", "text-gray-500 text-sm mb-2");
      },
      m(t, o) {
        b(t, e, o), m(e, n), m(e, s), m(s, r);
      },
      p(t, e) {
        4096 & e[0] && M(r, t[12]);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function qs(t) {
    let e, n, r, o, l, i, c, a, u, d;
    function f(t, e) {
      return t[12] ? Is : As;
    }
    let p = f(t),
      g = p(t);
    return {
      c() {
        (e = $("div")),
          (e.textContent =
            "Перетащите файл firmawre.bin или littlefs.bin сюда или нажмите кнопку Открыть файл"),
          (n = k()),
          g.c(),
          (r = k()),
          (o = $("input")),
          (l = k()),
          (i = $("button")),
          (i.textContent = "Открыть файл"),
          (c = k()),
          (a = $("button")),
          (a.textContent = "Обновить прошивку"),
          L(e, "class", "drop-zone mb-2"),
          L(o, "type", "file"),
          L(o, "accept", ".bin"),
          L(o, "class", "hidden"),
          L(i, "class", "btn-lg mb-2"),
          L(a, "class", "btn-lg");
      },
      m(s, f) {
        var p;
        b(s, e, f),
          b(s, n, f),
          g.m(s, f),
          b(s, r, f),
          b(s, o, f),
          t[41](o),
          b(s, l, f),
          b(s, i, f),
          b(s, c, f),
          b(s, a, f),
          u ||
          ((d = [
            j(e, "dragover", C(t[17])),
            j(
              e,
              "dragover",
              ((p = t[18]),
                function (t) {
                  return t.stopPropagation(), p.call(this, t);
                })
            ),
            j(e, "drop", C(t[19])),
            j(e, "drop", t[13]),
            j(o, "change", t[14]),
            j(i, "click", t[15]),
            j(a, "click", t[42]),
          ]),
            (u = !0));
      },
      p(t, e) {
        p === (p = f(t)) && g
          ? g.p(t, e)
          : (g.d(1), (g = p(t)), g && (g.c(), g.m(r.parentNode, r)));
      },
      d(f) {
        f && x(e),
          f && x(n),
          g.d(f),
          f && x(r),
          f && x(o),
          t[41](null),
          f && x(l),
          f && x(i),
          f && x(c),
          f && x(a),
          (u = !1),
          s(d);
      },
    };
  }
  function zs(t) {
    let e, n, s, r;
    const o = [ks, ys],
      l = [];
    function i(t, e) {
      return t[9] ? 0 : 1;
    }
    return (
      (e = i(t)),
      (n = l[e] = o[e](t)),
      {
        c() {
          n.c(), (s = _());
        },
        m(t, n) {
          l[e].m(t, n), b(t, s, n), (r = !0);
        },
        p(t, r) {
          let c = e;
          (e = i(t)),
            e === c
              ? l[e].p(t, r)
              : (et(),
                rt(l[c], 1, 1, () => {
                  l[c] = null;
                }),
                nt(),
                (n = l[e]),
                n ? n.p(t, r) : ((n = l[e] = o[e](t)), n.c()),
                st(n, 1),
                n.m(s.parentNode, s));
        },
        i(t) {
          r || (st(n), (r = !0));
        },
        o(t) {
          rt(n), (r = !1);
        },
        d(t) {
          l[e].d(t), t && x(s);
        },
      }
    );
  }
  function Bs(t, e, n) {
    let { errorsJson: s } = e,
      { coreMessages: r } = e,
      { settingsJson: o } = e,
      { saveSett: l = () => { } } = e,
      { cleanLogs: i = () => { } } = e,
      { rebootEsp: c = () => { } } = e,
      { setBrowserTime: a = () => { } } = e,
      { uploadFirmware: u = () => { } } = e,
      { onFileSelected: d } = e,
      { show: f } = e,
      { paramsBeenChanged: p = !1 } = e,
      g = !1,
      h = null,
      m = "";
    return (
      (t.$$set = (t) => {
        "errorsJson" in t && n(2, (s = t.errorsJson)),
          "coreMessages" in t && n(3, (r = t.coreMessages)),
          "settingsJson" in t && n(0, (o = t.settingsJson)),
          "saveSett" in t && n(4, (l = t.saveSett)),
          "cleanLogs" in t && n(5, (i = t.cleanLogs)),
          "rebootEsp" in t && n(6, (c = t.rebootEsp)),
          "setBrowserTime" in t && n(7, (a = t.setBrowserTime)),
          "uploadFirmware" in t && n(8, (u = t.uploadFirmware)),
          "onFileSelected" in t && n(16, (d = t.onFileSelected)),
          "show" in t && n(9, (f = t.show)),
          "paramsBeenChanged" in t && n(1, (p = t.paramsBeenChanged));
      }),
      [
        o,
        p,
        s,
        r,
        l,
        i,
        c,
        a,
        u,
        f,
        g,
        h,
        m,
        function (t) {
          const e = t.dataTransfer.files[0];
          e && (n(12, (m = e.name)), d(e));
        },
        function () {
          const t = h.files[0];
          t && (n(12, (m = t.name)), d(t));
        },
        function () {
          h.click();
        },
        d,
        function (e) {
          I.call(this, t, e);
        },
        function (e) {
          I.call(this, t, e);
        },
        function (e) {
          I.call(this, t, e);
        },
        () => c(),
        function () {
          (o.timezone = S(this.value)), n(0, o);
        },
        () => n(1, (p = !0)),
        () => i(),
        () => a(),
        function () {
          (o.wg = this.value), n(0, o);
        },
        () => n(10, (g = !0)),
        function () {
          (o.log = this.checked), n(0, o);
        },
        () => n(1, (p = !0)),
        function () {
          (o.mqttin = this.checked), n(0, o);
        },
        () => n(10, (g = !0)),
        function () {
          (o.i2c = this.checked), n(0, o);
        },
        () => n(10, (g = !0)),
        function () {
          (o.pinSCL = S(this.value)), n(0, o);
        },
        () => n(10, (g = !0)),
        function () {
          (o.pinSDA = S(this.value)), n(0, o);
        },
        () => n(10, (g = !0)),
        function () {
          (o.i2cFreq = S(this.value)), n(0, o);
        },
        () => n(10, (g = !0)),
        () => (l(), n(1, (p = !1))),
        () => (l(), c(), n(10, (g = !1))),
        function (t) {
          z[t ? "unshift" : "push"](() => {
            (h = t), n(11, h);
          });
        },
        () => u(),
      ]
    );
  }
  class Rs extends ut {
    constructor(t) {
      super(),
        at(
          this,
          t,
          Bs,
          zs,
          o,
          {
            errorsJson: 2,
            coreMessages: 3,
            settingsJson: 0,
            saveSett: 4,
            cleanLogs: 5,
            rebootEsp: 6,
            setBrowserTime: 7,
            uploadFirmware: 8,
            onFileSelected: 16,
            show: 9,
            paramsBeenChanged: 1,
          },
          null,
          [-1, -1]
        );
    }
  }
  function Fs(e) {
    let n, s;
    return (
      (n = new Zt({ props: { title: "Загрузка..." } })),
      {
        c() {
          lt(n.$$.fragment);
        },
        m(t, e) {
          it(n, t, e), (s = !0);
        },
        p: t,
        i(t) {
          s || (st(n.$$.fragment, t), (s = !0));
        },
        o(t) {
          rt(n.$$.fragment, t), (s = !1);
        },
        d(t) {
          ct(n, t);
        },
      }
    );
  }
  function Zs(e) {
    let n, s, r;
    return {
      c() {
        (n = $("div")),
          (s = $("iframe")),
          i(s.src, (r = `http://${e[1]}/edit`)) || L(s, "src", r),
          L(s, "title", "Файловой менеджер IoTManager"),
          L(s, "width", "100%"),
          L(s, "height", "100vh"),
          L(s, "frameborder", "0"),
          L(s, "class", "fullscreen-iframe"),
          L(n, "class", "edit-page");
      },
      m(t, e) {
        b(t, n, e), m(n, s);
      },
      p(t, e) {
        2 & e && !i(s.src, (r = `http://${t[1]}/edit`)) && L(s, "src", r);
      },
      i: t,
      o: t,
      d(t) {
        t && x(n);
      },
    };
  }
  function Ws(t) {
    let e, n, s, r;
    const o = [Zs, Fs],
      l = [];
    function i(t, e) {
      return t[0] ? 0 : 1;
    }
    return (
      (e = i(t)),
      (n = l[e] = o[e](t)),
      {
        c() {
          n.c(), (s = _());
        },
        m(t, n) {
          l[e].m(t, n), b(t, s, n), (r = !0);
        },
        p(t, [r]) {
          let c = e;
          (e = i(t)),
            e === c
              ? l[e].p(t, r)
              : (et(),
                rt(l[c], 1, 1, () => {
                  l[c] = null;
                }),
                nt(),
                (n = l[e]),
                n ? n.p(t, r) : ((n = l[e] = o[e](t)), n.c()),
                st(n, 1),
                n.m(s.parentNode, s));
        },
        i(t) {
          r || (st(n), (r = !0));
        },
        o(t) {
          rt(n), (r = !1);
        },
        d(t) {
          l[e].d(t), t && x(s);
        },
      }
    );
  }
  function Us(t, e, n) {
    let { show: s = !1 } = e,
      { espIP: r = "" } = e;
    return (
      console.log("Received serverIP:", r),
      (t.$$set = (t) => {
        "show" in t && n(0, (s = t.show)), "espIP" in t && n(1, (r = t.espIP));
      }),
      [s, r]
    );
  }
  class Ys extends ut {
    constructor(t) {
      super(), at(this, t, Us, Ws, o, { show: 0, espIP: 1 });
    }
  }
  var Vs = {
    ru: {
      "login.email": "Email",
      "login.pass": "Пароль",
      "login.login": "Вход",
      "profile.update": "Собрать прошивку",
      ok_success: "Задача добавлена",
      err_order_exist:
        "Ваша задача выполняется! Cледующию задачу можно будет запустить после завершения",
      err_add_order: "Ошибка отправки задачи",
      err_of_login: "Ошибка входа в систему",
      err_user_not_exist: "Такой пользователь не был зарегестрирован",
      err_pass: "Неправильный пароль",
      err_empty_fullname: "Пустое поле имени",
      err_empty_user: "Пустое поле Email адреса",
      err_not_email: "Неправильно введен Email",
      err_pass_lenth: "Пароль должен быть от 4 до 10 символов",
      ok_success_login: "Вы вошли в систему",
      "profile.exit": "Выйти",
    },
    en: {
      "login.email": "Email",
      "login.pass": "Password",
      "login.login": "Login",
      "profile.update": "Собрать прошивку",
      ok_success: "Задача добавлена",
      err_order_exist:
        "Ваша задача выполняется! Cледующию задачу можно будет запустить после завершения",
      err_add_order: "Ошибка отправки задачи",
      err_of_login: "Ошибка входа в систему",
      err_user_not_exist: "Такой пользователь не был зарегестрирован",
      err_pass: "Неправильный пароль",
      err_empty_fullname: "Пустое поле имени",
      err_empty_user: "Пустое поле Email адреса",
      err_not_email: "Неправильно введен Email",
      err_pass_lenth: "Пароль должен быть от 4 до 10 символов",
      ok_success_login: "Вы вошли в систему",
      "profile.exit": "Выйти",
    },
  };
  const Xs = (function (e, n, o) {
    const l = !Array.isArray(e),
      i = l ? [e] : e,
      a = n.length < 2;
    return (
      (u = (e) => {
        let o = !1;
        const u = [];
        let d = 0,
          f = t;
        const p = () => {
          if (d) return;
          f();
          const s = n(l ? u[0] : u);
          a ? e(s) : (f = r(s) ? s : t);
        },
          g = i.map((t, e) =>
            c(
              t,
              (t) => {
                (u[e] = t), (d &= ~(1 << e)), o && p();
              },
              () => {
                d |= 1 << e;
              }
            )
          );
        return (
          (o = !0),
          p(),
          () => {
            s(g), f(), (o = !1);
          }
        );
      }),
      { subscribe: ft(void 0, u).subscribe }
    );
    var u;
  })(
    ft("ru"),
    (t) =>
      (e, n = {}) =>
        (function (t, e, n) {
          if (!e) throw new Error("no key provided to $t()");
          if (!t) throw new Error(`no translation for key "${e}"`);
          let s = Vs[t][e];
          if (!s) throw new Error(`no translation found for ${t}.${e}`);
          return (
            Object.keys(n).map((t) => {
              const e = new RegExp(`{{${t}}}`, "g");
              s = s.replace(e, n[t]);
            }),
            s
          );
        })(t, e, n)
  );
  function Gs(t, e, n) {
    const s = t.slice();
    return (s[10] = e[n]), (s[12] = n), s;
  }
  function Ks(e) {
    let n, s;
    return (
      (n = new Zt({ props: { title: "Загрузка..." } })),
      {
        c() {
          lt(n.$$.fragment);
        },
        m(t, e) {
          it(n, t, e), (s = !0);
        },
        p: t,
        i(t) {
          s || (st(n.$$.fragment, t), (s = !0));
        },
        o(t) {
          rt(n.$$.fragment, t), (s = !1);
        },
        d(t) {
          ct(n, t);
        },
      }
    );
  }
  function Qs(t) {
    let e, n, s, r;
    const o = [er, tr],
      l = [];
    function i(t, e) {
      return t[1] ? 0 : 1;
    }
    return (
      (e = i(t)),
      (n = l[e] = o[e](t)),
      {
        c() {
          n.c(), (s = _());
        },
        m(t, n) {
          l[e].m(t, n), b(t, s, n), (r = !0);
        },
        p(t, r) {
          let c = e;
          (e = i(t)),
            e === c
              ? l[e].p(t, r)
              : (et(),
                rt(l[c], 1, 1, () => {
                  l[c] = null;
                }),
                nt(),
                (n = l[e]),
                n ? n.p(t, r) : ((n = l[e] = o[e](t)), n.c()),
                st(n, 1),
                n.m(s.parentNode, s));
        },
        i(t) {
          r || (st(n), (r = !0));
        },
        o(t) {
          rt(n), (r = !1);
        },
        d(t) {
          l[e].d(t), t && x(s);
        },
      }
    );
  }
  function tr(e) {
    let n, s, r, o;
    return (
      (r = new Kt({ props: { title: "Сервер недоступен" } })),
      {
        c() {
          (n = $("div")),
            (s = $("div")),
            lt(r.$$.fragment),
            L(s, "class", "grd-1col1"),
            L(n, "class", "my-4");
        },
        m(t, e) {
          b(t, n, e), m(n, s), it(r, s, null), (o = !0);
        },
        p: t,
        i(t) {
          o || (st(r.$$.fragment, t), (o = !0));
        },
        o(t) {
          rt(r.$$.fragment, t), (o = !1);
        },
        d(t) {
          t && x(n), ct(r);
        },
      }
    );
  }
  function er(e) {
    let n,
      r,
      o,
      l,
      i,
      c,
      a,
      u,
      d,
      f,
      p,
      g,
      h,
      w,
      _,
      C,
      S,
      J,
      O,
      E,
      N = e[4]("login.email") + "",
      P = e[4]("login.pass") + "",
      D = e[4]("login.login") + "",
      H = e[3],
      A = [];
    for (let t = 0; t < H.length; t += 1) A[t] = nr(Gs(e, H, t));
    return {
      c() {
        (n = $("div")),
          (r = $("div")),
          (o = $("form")),
          (l = $("div")),
          (i = $("label")),
          (c = y(N)),
          (a = k()),
          (u = $("input")),
          (d = k()),
          (f = $("div")),
          (p = $("label")),
          (g = y(P)),
          (h = k()),
          (w = $("input")),
          (_ = k());
        for (let t = 0; t < A.length; t += 1) A[t].c();
        (C = k()),
          (S = $("button")),
          (J = y(D)),
          L(i, "class", "block text-gray-700 text-sm font-bold mb-2"),
          L(i, "for", "username"),
          L(
            u,
            "class",
            "shadow appearance-none border rounded w-full h-10 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          ),
          L(u, "id", "username"),
          L(u, "type", "text"),
          L(u, "placeholder", "someone@example.com"),
          L(l, "class", "mb-4"),
          L(p, "class", "block text-gray-700 text-sm font-bold mb-2"),
          L(p, "for", "password"),
          L(
            w,
            "class",
            "shadow appearance-none border rounded w-full h-10 px-3 text-gray-700 mb-0 leading-tight focus:outline-none focus:shadow-outline"
          ),
          L(w, "id", "password"),
          L(w, "type", "password"),
          L(w, "placeholder", "**********"),
          L(f, "class", "mb-6"),
          L(S, "class", "btn-lg mt-6"),
          L(o, "class", "bg-white shadow-2xl rounded-xl px-8 pt-6 pb-8 mb-4"),
          L(r, "class", "w-full max-w-lg"),
          L(
            n,
            "class",
            "flex h-screen m-2 md:m-4 lg:m-8 items-start justify-center"
          );
      },
      m(t, s) {
        b(t, n, s),
          m(n, r),
          m(r, o),
          m(o, l),
          m(l, i),
          m(i, c),
          m(l, a),
          m(l, u),
          T(u, e[2].username),
          m(o, d),
          m(o, f),
          m(f, p),
          m(p, g),
          m(f, h),
          m(f, w),
          T(w, e[2].password),
          m(o, _);
        for (let t = 0; t < A.length; t += 1) A[t] && A[t].m(o, null);
        m(o, C),
          m(o, S),
          m(S, J),
          O ||
          ((E = [
            j(u, "input", e[6]),
            j(w, "input", e[7]),
            j(S, "click", e[8]),
          ]),
            (O = !0));
      },
      p(t, e) {
        if (
          (16 & e && N !== (N = t[4]("login.email") + "") && M(c, N),
            4 & e && u.value !== t[2].username && T(u, t[2].username),
            16 & e && P !== (P = t[4]("login.pass") + "") && M(g, P),
            4 & e && w.value !== t[2].password && T(w, t[2].password),
            24 & e)
        ) {
          let n;
          for (H = t[3], n = 0; n < H.length; n += 1) {
            const s = Gs(t, H, n);
            A[n] ? A[n].p(s, e) : ((A[n] = nr(s)), A[n].c(), A[n].m(o, C));
          }
          for (; n < A.length; n += 1) A[n].d(1);
          A.length = H.length;
        }
        16 & e && D !== (D = t[4]("login.login") + "") && M(J, D);
      },
      i: t,
      o: t,
      d(t) {
        t && x(n), v(A, t), (O = !1), s(E);
      },
    };
  }
  function nr(t) {
    let e,
      n,
      s = t[4](t[10].msg) + "";
    return {
      c() {
        (e = $("p")),
          (n = y(s)),
          L(e, "class", "text-red-500 p-0 m-0 font-bold text-xs italic");
      },
      m(t, s) {
        b(t, e, s), m(e, n);
      },
      p(t, e) {
        24 & e && s !== (s = t[4](t[10].msg) + "") && M(n, s);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function sr(t) {
    let e, n, s, r;
    const o = [Qs, Ks],
      l = [];
    function i(t, e) {
      return t[0] ? 0 : 1;
    }
    return (
      (e = i(t)),
      (n = l[e] = o[e](t)),
      {
        c() {
          n.c(), (s = _());
        },
        m(t, n) {
          l[e].m(t, n), b(t, s, n), (r = !0);
        },
        p(t, [r]) {
          let c = e;
          (e = i(t)),
            e === c
              ? l[e].p(t, r)
              : (et(),
                rt(l[c], 1, 1, () => {
                  l[c] = null;
                }),
                nt(),
                (n = l[e]),
                n ? n.p(t, r) : ((n = l[e] = o[e](t)), n.c()),
                st(n, 1),
                n.m(s.parentNode, s));
        },
        i(t) {
          r || (st(n), (r = !0));
        },
        o(t) {
          rt(n), (r = !1);
        },
        d(t) {
          l[e].d(t), t && x(s);
        },
      }
    );
  }
  function rr(t, e, n) {
    let s;
    a(t, Xs, (t) => n(4, (s = t)));
    let { show: r = !0 } = e,
      { serverOnline: o } = e,
      l = {},
      i = [];
    const c = async (t) => {
      n(3, (i = []));
      try {
        let e = await fetch("http://" + t[0].ip, {
          mode: "cors",
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
          body: JSON.stringify(t),
        });
        const s = await e.json();
        e.ok
          ? (n(3, (i = [{ msg: "ok_success_login" }])), u(s.message))
          : n(3, (i = s.message));
      } catch (t) {
        console.log(t);
      }
    },
      u = async (t) => {
        un.set("token_iotm2", t),
          console.log("token to be saved: ", t),
          Ct.goto("/profile"),
          location.reload();
      };
    return (
      (t.$$set = (t) => {
        "show" in t && n(0, (r = t.show)),
          "serverOnline" in t && n(1, (o = t.serverOnline));
      }),
      [
        r,
        o,
        l,
        i,
        s,
        c,
        function () {
          (l.username = this.value), n(2, l);
        },
        function () {
          (l.password = this.value), n(2, l);
        },
        () => c(l),
      ]
    );
  }
  class or extends ut {
    constructor(t) {
      super(), at(this, t, rr, sr, o, { show: 0, serverOnline: 1 });
    }
  }
  function lr(t, e, n) {
    const s = t.slice();
    return (s[31] = e[n]), (s[33] = n), s;
  }
  function ir(t, e, n) {
    const s = t.slice();
    return (s[34] = e[n]), (s[33] = n), s;
  }
  function cr(t, e, n) {
    const s = t.slice();
    return (s[36] = e[n]), (s[37] = e), (s[33] = n), s;
  }
  function ar(t, e, n) {
    const s = t.slice();
    return (s[36] = e[n]), (s[38] = e), (s[33] = n), s;
  }
  function ur(t, e, n) {
    const s = t.slice();
    return (s[36] = e[n]), (s[39] = e), (s[33] = n), s;
  }
  function dr(t, e, n) {
    const s = t.slice();
    return (s[36] = e[n]), (s[40] = e), (s[33] = n), s;
  }
  function fr(e) {
    let n, s;
    return (
      (n = new Zt({ props: { title: "Загрузка..." } })),
      {
        c() {
          lt(n.$$.fragment);
        },
        m(t, e) {
          it(n, t, e), (s = !0);
        },
        p: t,
        i(t) {
          s || (st(n.$$.fragment, t), (s = !0));
        },
        o(t) {
          rt(n.$$.fragment, t), (s = !1);
        },
        d(t) {
          ct(n, t);
        },
      }
    );
  }
  function pr(t) {
    let e, n, s, r;
    const o = [hr, gr],
      l = [];
    function i(t, e) {
      return t[5] ? 0 : 1;
    }
    return (
      (e = i(t)),
      (n = l[e] = o[e](t)),
      {
        c() {
          n.c(), (s = _());
        },
        m(t, n) {
          l[e].m(t, n), b(t, s, n), (r = !0);
        },
        p(t, r) {
          let c = e;
          (e = i(t)),
            e === c
              ? l[e].p(t, r)
              : (et(),
                rt(l[c], 1, 1, () => {
                  l[c] = null;
                }),
                nt(),
                (n = l[e]),
                n ? n.p(t, r) : ((n = l[e] = o[e](t)), n.c()),
                st(n, 1),
                n.m(s.parentNode, s));
        },
        i(t) {
          r || (st(n), (r = !0));
        },
        o(t) {
          rt(n), (r = !1);
        },
        d(t) {
          l[e].d(t), t && x(s);
        },
      }
    );
  }
  function gr(e) {
    let n, s, r, o;
    return (
      (r = new Kt({ props: { title: "Сервер недоступен" } })),
      {
        c() {
          (n = $("div")),
            (s = $("div")),
            lt(r.$$.fragment),
            L(s, "class", "grd-1col1"),
            L(n, "class", "my-4");
        },
        m(t, e) {
          b(t, n, e), m(n, s), it(r, s, null), (o = !0);
        },
        p: t,
        i(t) {
          o || (st(r.$$.fragment, t), (o = !0));
        },
        o(t) {
          rt(r.$$.fragment, t), (o = !1);
        },
        d(t) {
          t && x(n), ct(r);
        },
      }
    );
  }
  function hr(t) {
    let e,
      n,
      s = t[4] && t[2] && t[0] && mr(t);
    return {
      c() {
        s && s.c(), (e = _());
      },
      m(t, r) {
        s && s.m(t, r), b(t, e, r), (n = !0);
      },
      p(t, n) {
        t[4] && t[2] && t[0]
          ? s
            ? (s.p(t, n), 21 & n[0] && st(s, 1))
            : ((s = mr(t)), s.c(), st(s, 1), s.m(e.parentNode, e))
          : s &&
          (et(),
            rt(s, 1, 1, () => {
              s = null;
            }),
            nt());
      },
      i(t) {
        n || (st(s), (n = !0));
      },
      o(t) {
        rt(s), (n = !1);
      },
      d(t) {
        s && s.d(t), t && x(e);
      },
    };
  }
  function mr(t) {
    let e, n, s, r;
    return (
      (s = new Kt({
        props: { title: "", $$slots: { default: [Dr] }, $$scope: { ctx: t } },
      })),
      {
        c() {
          (e = $("div")),
            (n = $("div")),
            lt(s.$$.fragment),
            L(n, "class", "grd-1col1"),
            L(e, "class", "my-4");
        },
        m(t, o) {
          b(t, e, o), m(e, n), it(s, n, null), (r = !0);
        },
        p(t, e) {
          const n = {};
          (2013 & e[0]) | (1024 & e[1]) && (n.$$scope = { dirty: e, ctx: t }),
            s.$set(n);
        },
        i(t) {
          r || (st(s.$$.fragment, t), (r = !0));
        },
        o(t) {
          rt(s.$$.fragment, t), (r = !1);
        },
        d(t) {
          t && x(e), ct(s);
        },
      }
    );
  }
  function br(t) {
    let e,
      n,
      s,
      r,
      o,
      l,
      i =
        t[36].path.substring(
          t[36].path.lastIndexOf("/") + 1,
          t[36].path.length
        ) + "";
    function c() {
      return t[16](t[36], t[40], t[33]);
    }
    return {
      c() {
        (e = $("div")),
          (n = $("p")),
          (s = y(i)),
          L(
            n,
            "class",
            (r =
              (t[36].active ? "bg-green-100" : "") +
              " cursor-pointer select-none text-black text-xs font-medium mr-2 px-0.5 py-0.5 rounded text-center")
          );
      },
      m(t, r) {
        b(t, e, r), m(e, n), m(n, s), o || ((l = j(n, "click", c)), (o = !0));
      },
      p(e, o) {
        (t = e),
          1 & o[0] &&
          i !==
          (i =
            t[36].path.substring(
              t[36].path.lastIndexOf("/") + 1,
              t[36].path.length
            ) + "") &&
          M(s, i),
          1 & o[0] &&
          r !==
          (r =
            (t[36].active ? "bg-green-100" : "") +
            " cursor-pointer select-none text-black text-xs font-medium mr-2 px-0.5 py-0.5 rounded text-center") &&
          L(n, "class", r);
      },
      d(t) {
        t && x(e), (o = !1), l();
      },
    };
  }
  function xr(t) {
    let e,
      n =
        t[4][t[36].path]?.usedLibs[t[0].projectProp.platformio.default_envs] &&
        br(t);
    return {
      c() {
        n && n.c(), (e = _());
      },
      m(t, s) {
        n && n.m(t, s), b(t, e, s);
      },
      p(t, s) {
        t[4][t[36].path]?.usedLibs[t[0].projectProp.platformio.default_envs]
          ? n
            ? n.p(t, s)
            : ((n = br(t)), n.c(), n.m(e.parentNode, e))
          : n && (n.d(1), (n = null));
      },
      d(t) {
        n && n.d(t), t && x(e);
      },
    };
  }
  function vr(t) {
    let e,
      n,
      s,
      r,
      o,
      l,
      i =
        t[36].path.substring(
          t[36].path.lastIndexOf("/") + 1,
          t[36].path.length
        ) + "";
    function c() {
      return t[17](t[36], t[39], t[33]);
    }
    return {
      c() {
        (e = $("div")),
          (n = $("p")),
          (s = y(i)),
          L(
            n,
            "class",
            (r =
              (t[36].active ? "bg-green-100" : "") +
              " cursor-pointer select-none text-black text-xs font-medium mr-2 px-0.5 py-0.5 rounded text-center")
          );
      },
      m(t, r) {
        b(t, e, r), m(e, n), m(n, s), o || ((l = j(n, "click", c)), (o = !0));
      },
      p(e, o) {
        (t = e),
          1 & o[0] &&
          i !==
          (i =
            t[36].path.substring(
              t[36].path.lastIndexOf("/") + 1,
              t[36].path.length
            ) + "") &&
          M(s, i),
          1 & o[0] &&
          r !==
          (r =
            (t[36].active ? "bg-green-100" : "") +
            " cursor-pointer select-none text-black text-xs font-medium mr-2 px-0.5 py-0.5 rounded text-center") &&
          L(n, "class", r);
      },
      d(t) {
        t && x(e), (o = !1), l();
      },
    };
  }
  function $r(t) {
    let e,
      n =
        t[4][t[36].path]?.usedLibs[t[0].projectProp.platformio.default_envs] &&
        vr(t);
    return {
      c() {
        n && n.c(), (e = _());
      },
      m(t, s) {
        n && n.m(t, s), b(t, e, s);
      },
      p(t, s) {
        t[4][t[36].path]?.usedLibs[t[0].projectProp.platformio.default_envs]
          ? n
            ? n.p(t, s)
            : ((n = vr(t)), n.c(), n.m(e.parentNode, e))
          : n && (n.d(1), (n = null));
      },
      d(t) {
        n && n.d(t), t && x(e);
      },
    };
  }
  function wr(t) {
    let e,
      n,
      s,
      r,
      o,
      l,
      i =
        t[36].path.substring(
          t[36].path.lastIndexOf("/") + 1,
          t[36].path.length
        ) + "";
    function c() {
      return t[18](t[36], t[38], t[33]);
    }
    return {
      c() {
        (e = $("div")),
          (n = $("p")),
          (s = y(i)),
          L(
            n,
            "class",
            (r =
              (t[36].active ? "bg-green-100" : "") +
              " cursor-pointer select-none text-black text-xs font-medium mr-2 px-0.5 py-0.5 rounded text-center")
          );
      },
      m(t, r) {
        b(t, e, r), m(e, n), m(n, s), o || ((l = j(n, "click", c)), (o = !0));
      },
      p(e, o) {
        (t = e),
          1 & o[0] &&
          i !==
          (i =
            t[36].path.substring(
              t[36].path.lastIndexOf("/") + 1,
              t[36].path.length
            ) + "") &&
          M(s, i),
          1 & o[0] &&
          r !==
          (r =
            (t[36].active ? "bg-green-100" : "") +
            " cursor-pointer select-none text-black text-xs font-medium mr-2 px-0.5 py-0.5 rounded text-center") &&
          L(n, "class", r);
      },
      d(t) {
        t && x(e), (o = !1), l();
      },
    };
  }
  function yr(t) {
    let e,
      n =
        t[4][t[36].path]?.usedLibs[t[0].projectProp.platformio.default_envs] &&
        wr(t);
    return {
      c() {
        n && n.c(), (e = _());
      },
      m(t, s) {
        n && n.m(t, s), b(t, e, s);
      },
      p(t, s) {
        t[4][t[36].path]?.usedLibs[t[0].projectProp.platformio.default_envs]
          ? n
            ? n.p(t, s)
            : ((n = wr(t)), n.c(), n.m(e.parentNode, e))
          : n && (n.d(1), (n = null));
      },
      d(t) {
        n && n.d(t), t && x(e);
      },
    };
  }
  function kr(t) {
    let e,
      n,
      s,
      r,
      o,
      l,
      i,
      c =
        t[36].path.substring(
          t[36].path.lastIndexOf("/") + 1,
          t[36].path.length
        ) + "";
    function a() {
      return t[19](t[36], t[37], t[33]);
    }
    return {
      c() {
        (e = $("div")),
          (n = $("p")),
          (s = y(c)),
          (o = k()),
          L(
            n,
            "class",
            (r =
              (t[36].active ? "bg-green-100" : "") +
              " cursor-pointer select-none text-black text-xs font-medium mr-2 px-0.5 py-0.5 rounded text-center")
          );
      },
      m(t, r) {
        b(t, e, r),
          m(e, n),
          m(n, s),
          m(e, o),
          l || ((i = j(n, "click", a)), (l = !0));
      },
      p(e, o) {
        (t = e),
          1 & o[0] &&
          c !==
          (c =
            t[36].path.substring(
              t[36].path.lastIndexOf("/") + 1,
              t[36].path.length
            ) + "") &&
          M(s, c),
          1 & o[0] &&
          r !==
          (r =
            (t[36].active ? "bg-green-100" : "") +
            " cursor-pointer select-none text-black text-xs font-medium mr-2 px-0.5 py-0.5 rounded text-center") &&
          L(n, "class", r);
      },
      d(t) {
        t && x(e), (l = !1), i();
      },
    };
  }
  function _r(t) {
    let e,
      n =
        t[4][t[36].path]?.usedLibs[t[0].projectProp.platformio.default_envs] &&
        kr(t);
    return {
      c() {
        n && n.c(), (e = _());
      },
      m(t, s) {
        n && n.m(t, s), b(t, e, s);
      },
      p(t, s) {
        t[4][t[36].path]?.usedLibs[t[0].projectProp.platformio.default_envs]
          ? n
            ? n.p(t, s)
            : ((n = kr(t)), n.c(), n.m(e.parentNode, e))
          : n && (n.d(1), (n = null));
      },
      d(t) {
        n && n.d(t), t && x(e);
      },
    };
  }
  function jr(t) {
    let e,
      n,
      s = t[10](t[34].msg) + "";
    return {
      c() {
        (e = $("p")),
          (n = y(s)),
          L(e, "class", "text-red-500 p-0 m-0 font-bold text-xs italic");
      },
      m(t, s) {
        b(t, e, s), m(e, n);
      },
      p(t, e) {
        1280 & e[0] && s !== (s = t[10](t[34].msg) + "") && M(n, s);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function Cr(t) {
    let e,
      n,
      s,
      r,
      o,
      l,
      i = 0 === t[3].build && 0 === t[3].fs ? "успешно" : "ошибка";
    return {
      c() {
        (e = $("div")),
          (n = $("p")),
          (n.textContent = "Статус последнего обновления:"),
          (s = k()),
          (r = $("p")),
          (o = y(i)),
          L(n, "class", "text-center text-gray-500 font-bold truncate"),
          L(
            r,
            "class",
            (l =
              (0 === t[3].build && 0 === t[3].fs
                ? "text-green-500"
                : "text-red-500") + " text-center font-bold truncate")
          ),
          L(e, "class", "grid grid-cols-2 mb-4");
      },
      m(t, l) {
        b(t, e, l), m(e, n), m(e, s), m(e, r), m(r, o);
      },
      p(t, e) {
        8 & e[0] &&
          i !==
          (i = 0 === t[3].build && 0 === t[3].fs ? "успешно" : "ошибка") &&
          M(o, i),
          8 & e[0] &&
          l !==
          (l =
            (0 === t[3].build && 0 === t[3].fs
              ? "text-green-500"
              : "text-red-500") + " text-center font-bold truncate") &&
          L(r, "class", l);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function Lr(t) {
    let e,
      n,
      s,
      r,
      o,
      l = t[9],
      i = [];
    for (let e = 0; e < l.length; e += 1) i[e] = Pr(lr(t, l, e));
    const c = (t) =>
      rt(i[t], 1, 1, () => {
        i[t] = null;
      });
    return {
      c() {
        (e = $("table")),
          (n = $("thead")),
          (n.innerHTML =
            '<tr class="txt-sz txt-pad"><th class="tbl-hd">Название</th> \n                    <th class="tbl-hd">Версия</th> \n                    <th class="tbl-hd">Время</th> \n\n                    <th class="tbl-hd">Подготовка</th> \n                    <th class="tbl-hd">Сборка build</th> \n                    <th class="tbl-hd">Сборка fs</th> \n                    <th class="tbl-hd"></th> \n                    <th class="tbl-hd w-7"></th></tr>'),
          (s = k()),
          (r = $("tbody"));
        for (let t = 0; t < i.length; t += 1) i[t].c();
        L(n, "class", "bg-gray-100"),
          L(r, "class", "bg-white"),
          L(e, "class", "tbl mb-0");
      },
      m(t, l) {
        b(t, e, l), m(e, n), m(e, s), m(e, r);
        for (let t = 0; t < i.length; t += 1) i[t] && i[t].m(r, null);
        o = !0;
      },
      p(t, e) {
        if (39556 & e[0]) {
          let n;
          for (l = t[9], n = 0; n < l.length; n += 1) {
            const s = lr(t, l, n);
            i[n]
              ? (i[n].p(s, e), st(i[n], 1))
              : ((i[n] = Pr(s)), i[n].c(), st(i[n], 1), i[n].m(r, null));
          }
          for (et(), n = l.length; n < i.length; n += 1) c(n);
          nt();
        }
      },
      i(t) {
        if (!o) {
          for (let t = 0; t < l.length; t += 1) st(i[t]);
          o = !0;
        }
      },
      o(t) {
        i = i.filter(Boolean);
        for (let t = 0; t < i.length; t += 1) rt(i[t]);
        o = !1;
      },
      d(t) {
        t && x(e), v(i, t);
      },
    };
  }
  function Sr(t) {
    let e,
      n,
      s,
      r,
      o,
      l,
      i,
      c,
      a,
      u,
      d,
      f,
      p,
      g,
      h = t[31].projectProp.platformio.default_envs + "",
      v = t[31].ver + "",
      w =
        new Date(t[31].dateAdded).toLocaleString("ru", {
          timeZone: "Europe/Vienna",
        }) + "";
    const _ = [Tr, Mr],
      j = [];
    function C(t, e) {
      return 0 === t[31].status.preparation &&
        0 === t[31].status.build &&
        0 === t[31].status.fs
        ? 0
        : 1;
    }
    return (
      (d = C(t)),
      (f = j[d] = _[d](t)),
      {
        c() {
          (e = $("tr")),
            (n = $("td")),
            (s = y(h)),
            (r = k()),
            (o = $("td")),
            (l = y(v)),
            (i = k()),
            (c = $("td")),
            (a = y(w)),
            (u = k()),
            f.c(),
            (p = k()),
            L(n, "class", "tbl-bdy-lg ipt-lg w-full"),
            L(o, "class", "tbl-bdy-lg ipt-lg w-full"),
            L(c, "class", "tbl-bdy-lg ipt-lg w-full"),
            L(e, "class", "txt-sz txt-pad");
        },
        m(t, f) {
          b(t, e, f),
            m(e, n),
            m(n, s),
            m(e, r),
            m(e, o),
            m(o, l),
            m(e, i),
            m(e, c),
            m(c, a),
            m(e, u),
            j[d].m(e, null),
            m(e, p),
            (g = !0);
        },
        p(t, n) {
          (!g || 512 & n[0]) &&
            h !== (h = t[31].projectProp.platformio.default_envs + "") &&
            M(s, h),
            (!g || 512 & n[0]) && v !== (v = t[31].ver + "") && M(l, v),
            (!g || 512 & n[0]) &&
            w !==
            (w =
              new Date(t[31].dateAdded).toLocaleString("ru", {
                timeZone: "Europe/Vienna",
              }) + "") &&
            M(a, w);
          let r = d;
          (d = C(t)),
            d === r
              ? j[d].p(t, n)
              : (et(),
                rt(j[r], 1, 1, () => {
                  j[r] = null;
                }),
                nt(),
                (f = j[d]),
                f ? f.p(t, n) : ((f = j[d] = _[d](t)), f.c()),
                st(f, 1),
                f.m(e, p));
        },
        i(t) {
          g || (st(f), (g = !0));
        },
        o(t) {
          rt(f), (g = !1);
        },
        d(t) {
          t && x(e), j[d].d();
        },
      }
    );
  }
  function Mr(t) {
    let e,
      n,
      s,
      r,
      o,
      l,
      i,
      c,
      a,
      u,
      d,
      f,
      p,
      g,
      h,
      v,
      w,
      j,
      C,
      S,
      T = t[11][t[31].status.preparation] + "",
      J = t[11][t[31].status.build] + "",
      O = t[11][t[31].status.fs] + "";
    function E() {
      return t[21](t[31]);
    }
    function N() {
      return t[22](t[31]);
    }
    function P() {
      return t[23](t[31]);
    }
    function D(t, e) {
      return 2 === t[31].status.build &&
        2 === t[31].status.preparation &&
        2 === t[31].status.fs
        ? Or
        : Jr;
    }
    let H = D(t),
      A = H(t);
    const I = [Nr, Er],
      q = [];
    function z(t, e) {
      return t[31].processed ? 0 : 1;
    }
    return (
      (w = z(t)),
      (j = q[w] = I[w](t)),
      {
        c() {
          (e = $("td")),
            (n = $("div")),
            (s = y(T)),
            (o = k()),
            (l = $("td")),
            (i = $("div")),
            (c = y(J)),
            (u = k()),
            (d = $("td")),
            (f = $("div")),
            (p = y(O)),
            (h = k()),
            A.c(),
            (v = k()),
            j.c(),
            (C = _()),
            L(n, "onclick", (r = E)),
            L(e, "class", "tbl-bdy-lg ipt-lg w-full"),
            L(i, "onclick", (a = N)),
            L(l, "class", "tbl-bdy-lg ipt-lg w-full"),
            L(f, "onclick", (g = P)),
            L(d, "class", "tbl-bdy-lg ipt-lg w-full");
        },
        m(t, r) {
          b(t, e, r),
            m(e, n),
            m(n, s),
            b(t, o, r),
            b(t, l, r),
            m(l, i),
            m(i, c),
            b(t, u, r),
            b(t, d, r),
            m(d, f),
            m(f, p),
            b(t, h, r),
            A.m(t, r),
            b(t, v, r),
            q[w].m(t, r),
            b(t, C, r),
            (S = !0);
        },
        p(e, o) {
          (t = e),
            (!S || 512 & o[0]) &&
            T !== (T = t[11][t[31].status.preparation] + "") &&
            M(s, T),
            (!S || (512 & o[0] && r !== (r = E))) && L(n, "onclick", r),
            (!S || 512 & o[0]) &&
            J !== (J = t[11][t[31].status.build] + "") &&
            M(c, J),
            (!S || (512 & o[0] && a !== (a = N))) && L(i, "onclick", a),
            (!S || 512 & o[0]) &&
            O !== (O = t[11][t[31].status.fs] + "") &&
            M(p, O),
            (!S || (512 & o[0] && g !== (g = P))) && L(f, "onclick", g),
            H === (H = D(t)) && A
              ? A.p(t, o)
              : (A.d(1), (A = H(t)), A && (A.c(), A.m(v.parentNode, v)));
          let l = w;
          (w = z(t)),
            w === l
              ? q[w].p(t, o)
              : (et(),
                rt(q[l], 1, 1, () => {
                  q[l] = null;
                }),
                nt(),
                (j = q[w]),
                j ? j.p(t, o) : ((j = q[w] = I[w](t)), j.c()),
                st(j, 1),
                j.m(C.parentNode, C));
        },
        i(t) {
          S || (st(j), (S = !0));
        },
        o(t) {
          rt(j), (S = !1);
        },
        d(t) {
          t && x(e),
            t && x(o),
            t && x(l),
            t && x(u),
            t && x(d),
            t && x(h),
            A.d(t),
            t && x(v),
            q[w].d(t),
            t && x(C);
        },
      }
    );
  }
  function Tr(e) {
    let n, s, r, o, l, i, c, a;
    return {
      c() {
        (n = $("td")),
          (s = $("p")),
          (s.textContent = "Ожидание очереди..."),
          (r = k()),
          (o = $("td")),
          (l = k()),
          (i = $("td")),
          (c = k()),
          (a = $("td")),
          L(s, "class", "text-green-500 font-bold truncate"),
          L(n, "class", "tbl-bdy-lg ipt-lg w-full"),
          L(o, "class", "tbl-bdy-lg ipt-lg w-full"),
          L(i, "class", "tbl-bdy-lg ipt-lg w-full"),
          L(a, "class", "tbl-bdy-lg ipt-lg w-full");
      },
      m(t, e) {
        b(t, n, e),
          m(n, s),
          b(t, r, e),
          b(t, o, e),
          b(t, l, e),
          b(t, i, e),
          b(t, c, e),
          b(t, a, e);
      },
      p: t,
      i: t,
      o: t,
      d(t) {
        t && x(n),
          t && x(r),
          t && x(o),
          t && x(l),
          t && x(i),
          t && x(c),
          t && x(a);
      },
    };
  }
  function Jr(e) {
    let n;
    return {
      c() {
        (n = $("td")), L(n, "class", "tbl-bdy-lg ipt-lg w-full");
      },
      m(t, e) {
        b(t, n, e);
      },
      p: t,
      d(t) {
        t && x(n);
      },
    };
  }
  function Or(t) {
    let e, n, s;
    function r() {
      return t[24](t[31]);
    }
    return {
      c() {
        (e = $("td")),
          (e.innerHTML = '<p class="w-fill">Установить</p>'),
          L(
            e,
            "class",
            "tbl-bdy-lg ipt-lg w-full cursor-pointer select-none bg-green-100 hover:bg-green-200"
          );
      },
      m(t, o) {
        b(t, e, o), n || ((s = j(e, "click", r)), (n = !0));
      },
      p(e, n) {
        t = e;
      },
      d(t) {
        t && x(e), (n = !1), s();
      },
    };
  }
  function Er(e) {
    let n;
    return {
      c() {
        (n = $("td")), L(n, "class", "tbl-bdy-lg ipt-lg w-full");
      },
      m(t, e) {
        b(t, n, e);
      },
      p: t,
      i: t,
      o: t,
      d(t) {
        t && x(n);
      },
    };
  }
  function Nr(t) {
    let e, n, s;
    function r() {
      return t[25](t[31]);
    }
    return (
      (n = new qt({ props: { click: r } })),
      {
        c() {
          (e = $("td")),
            lt(n.$$.fragment),
            L(e, "class", "tbl-bdy-lg ipt-lg w-full");
        },
        m(t, r) {
          b(t, e, r), it(n, e, null), (s = !0);
        },
        p(e, s) {
          t = e;
          const o = {};
          512 & s[0] && (o.click = r), n.$set(o);
        },
        i(t) {
          s || (st(n.$$.fragment, t), (s = !0));
        },
        o(t) {
          rt(n.$$.fragment, t), (s = !1);
        },
        d(t) {
          t && x(e), ct(n);
        },
      }
    );
  }
  function Pr(t) {
    let e,
      n,
      s =
        t[31].projectProp.platformio.default_envs ===
        t[2].projectProp.platformio.default_envs && Sr(t);
    return {
      c() {
        s && s.c(), (e = _());
      },
      m(t, r) {
        s && s.m(t, r), b(t, e, r), (n = !0);
      },
      p(t, n) {
        t[31].projectProp.platformio.default_envs ===
          t[2].projectProp.platformio.default_envs
          ? s
            ? (s.p(t, n), 516 & n[0] && st(s, 1))
            : ((s = Sr(t)), s.c(), st(s, 1), s.m(e.parentNode, e))
          : s &&
          (et(),
            rt(s, 1, 1, () => {
              s = null;
            }),
            nt());
      },
      i(t) {
        n || (st(s), (n = !0));
      },
      o(t) {
        rt(s), (n = !1);
      },
      d(t) {
        s && s.d(t), t && x(e);
      },
    };
  }
  function Dr(t) {
    let e,
      n,
      r,
      o,
      l,
      i,
      c,
      a,
      u,
      d,
      f,
      p,
      g,
      h,
      w,
      _,
      C,
      S,
      T,
      J,
      O,
      E,
      N,
      P = t[2].projectProp.platformio.default_envs + "",
      D = t[6].username + "",
      H = t[10]("profile.update") + "",
      A = 0 !== Object.keys(t[3]).length,
      I = t[10]("profile.exit") + "",
      q = t[0].modules.virtual_elments,
      z = [];
    for (let e = 0; e < q.length; e += 1) z[e] = xr(dr(t, q, e));
    let B = t[0].modules.sensors,
      R = [];
    for (let e = 0; e < B.length; e += 1) R[e] = $r(ur(t, B, e));
    let F = t[0].modules.executive_devices,
      Z = [];
    for (let e = 0; e < F.length; e += 1) Z[e] = yr(ar(t, F, e));
    let W = t[0].modules.screens,
      U = [];
    for (let e = 0; e < W.length; e += 1) U[e] = _r(cr(t, W, e));
    let Y = t[8],
      V = [];
    for (let e = 0; e < Y.length; e += 1) V[e] = jr(ir(t, Y, e));
    let X = A && Cr(t),
      G = t[9] && Lr(t);
    return {
      c() {
        (e = $("div")),
          (n = $("p")),
          (r = y(P)),
          (o = k()),
          (l = $("p")),
          (i = y(D)),
          (c = k()),
          (a = $("div"));
        for (let t = 0; t < z.length; t += 1) z[t].c();
        u = k();
        for (let t = 0; t < R.length; t += 1) R[t].c();
        d = k();
        for (let t = 0; t < Z.length; t += 1) Z[t].c();
        f = k();
        for (let t = 0; t < U.length; t += 1) U[t].c();
        p = k();
        for (let t = 0; t < V.length; t += 1) V[t].c();
        (g = k()),
          (h = $("button")),
          (w = y(H)),
          (_ = k()),
          X && X.c(),
          (C = k()),
          G && G.c(),
          (S = k()),
          (T = $("button")),
          (J = y(I)),
          L(n, "class", "text-center text-gray-500 font-bold"),
          L(l, "class", "text-center text-gray-500 font-bold"),
          L(e, "class", "grid grid-cols-2"),
          L(
            a,
            "class",
            "grid my-4 grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 xl:grid-cols-12 2xl:grid-cols-12 gap-4"
          ),
          L(h, "class", "btn-lg mt-4 mb-4"),
          L(T, "class", "btn-lg mt-4");
      },
      m(s, x) {
        b(s, e, x),
          m(e, n),
          m(n, r),
          m(e, o),
          m(e, l),
          m(l, i),
          b(s, c, x),
          b(s, a, x);
        for (let t = 0; t < z.length; t += 1) z[t] && z[t].m(a, null);
        m(a, u);
        for (let t = 0; t < R.length; t += 1) R[t] && R[t].m(a, null);
        m(a, d);
        for (let t = 0; t < Z.length; t += 1) Z[t] && Z[t].m(a, null);
        m(a, f);
        for (let t = 0; t < U.length; t += 1) U[t] && U[t].m(a, null);
        b(s, p, x);
        for (let t = 0; t < V.length; t += 1) V[t] && V[t].m(s, x);
        b(s, g, x),
          b(s, h, x),
          m(h, w),
          b(s, _, x),
          X && X.m(s, x),
          b(s, C, x),
          G && G.m(s, x),
          b(s, S, x),
          b(s, T, x),
          m(T, J),
          (O = !0),
          E || ((N = [j(h, "click", t[20]), j(T, "click", t[26])]), (E = !0));
      },
      p(t, e) {
        if (
          ((!O || 4 & e[0]) &&
            P !== (P = t[2].projectProp.platformio.default_envs + "") &&
            M(r, P),
            (!O || 64 & e[0]) && D !== (D = t[6].username + "") && M(i, D),
            17 & e[0])
        ) {
          let n;
          for (q = t[0].modules.virtual_elments, n = 0; n < q.length; n += 1) {
            const s = dr(t, q, n);
            z[n] ? z[n].p(s, e) : ((z[n] = xr(s)), z[n].c(), z[n].m(a, u));
          }
          for (; n < z.length; n += 1) z[n].d(1);
          z.length = q.length;
        }
        if (17 & e[0]) {
          let n;
          for (B = t[0].modules.sensors, n = 0; n < B.length; n += 1) {
            const s = ur(t, B, n);
            R[n] ? R[n].p(s, e) : ((R[n] = $r(s)), R[n].c(), R[n].m(a, d));
          }
          for (; n < R.length; n += 1) R[n].d(1);
          R.length = B.length;
        }
        if (17 & e[0]) {
          let n;
          for (
            F = t[0].modules.executive_devices, n = 0;
            n < F.length;
            n += 1
          ) {
            const s = ar(t, F, n);
            Z[n] ? Z[n].p(s, e) : ((Z[n] = yr(s)), Z[n].c(), Z[n].m(a, f));
          }
          for (; n < Z.length; n += 1) Z[n].d(1);
          Z.length = F.length;
        }
        if (17 & e[0]) {
          let n;
          for (W = t[0].modules.screens, n = 0; n < W.length; n += 1) {
            const s = cr(t, W, n);
            U[n] ? U[n].p(s, e) : ((U[n] = _r(s)), U[n].c(), U[n].m(a, null));
          }
          for (; n < U.length; n += 1) U[n].d(1);
          U.length = W.length;
        }
        if (1280 & e[0]) {
          let n;
          for (Y = t[8], n = 0; n < Y.length; n += 1) {
            const s = ir(t, Y, n);
            V[n]
              ? V[n].p(s, e)
              : ((V[n] = jr(s)), V[n].c(), V[n].m(g.parentNode, g));
          }
          for (; n < V.length; n += 1) V[n].d(1);
          V.length = Y.length;
        }
        (!O || 1024 & e[0]) &&
          H !== (H = t[10]("profile.update") + "") &&
          M(w, H),
          8 & e[0] && (A = 0 !== Object.keys(t[3]).length),
          A
            ? X
              ? X.p(t, e)
              : ((X = Cr(t)), X.c(), X.m(C.parentNode, C))
            : X && (X.d(1), (X = null)),
          t[9]
            ? G
              ? (G.p(t, e), 512 & e[0] && st(G, 1))
              : ((G = Lr(t)), G.c(), st(G, 1), G.m(S.parentNode, S))
            : G &&
            (et(),
              rt(G, 1, 1, () => {
                G = null;
              }),
              nt()),
          (!O || 1024 & e[0]) &&
          I !== (I = t[10]("profile.exit") + "") &&
          M(J, I);
      },
      i(t) {
        O || (st(G), (O = !0));
      },
      o(t) {
        rt(G), (O = !1);
      },
      d(t) {
        t && x(e),
          t && x(c),
          t && x(a),
          v(z, t),
          v(R, t),
          v(Z, t),
          v(U, t),
          t && x(p),
          v(V, t),
          t && x(g),
          t && x(h),
          t && x(_),
          X && X.d(t),
          t && x(C),
          G && G.d(t),
          t && x(S),
          t && x(T),
          (E = !1),
          s(N);
      },
    };
  }
  function Hr(t) {
    let e, n, s, r;
    const o = [pr, fr],
      l = [];
    function i(t, e) {
      return t[1] ? 0 : 1;
    }
    return (
      (e = i(t)),
      (n = l[e] = o[e](t)),
      {
        c() {
          n.c(), (s = _());
        },
        m(t, n) {
          l[e].m(t, n), b(t, s, n), (r = !0);
        },
        p(t, r) {
          let c = e;
          (e = i(t)),
            e === c
              ? l[e].p(t, r)
              : (et(),
                rt(l[c], 1, 1, () => {
                  l[c] = null;
                }),
                nt(),
                (n = l[e]),
                n ? n.p(t, r) : ((n = l[e] = o[e](t)), n.c()),
                st(n, 1),
                n.m(s.parentNode, s));
        },
        i(t) {
          r || (st(n), (r = !0));
        },
        o(t) {
          rt(n), (r = !1);
        },
        d(t) {
          l[e].d(t), t && x(s);
        },
      }
    );
  }
  function Ar(t, e, n) {
    let s;
    a(t, Xs, (t) => n(10, (s = t)));
    let { show: r } = e,
      { flashProfileJson: o } = e,
      { otaJson: l } = e,
      { allmodeinfo: i } = e,
      { profile: c } = e,
      { serverOnline: u } = e,
      { userdata: d } = e,
      { updateBuild: f = (t) => { } } = e,
      p = [],
      g = null;
    var h;
    H(async () => {
      await b();
    });
    const m = async () => {
      await b();
    },
      b = async () => {
        try {
          const t = un.get("token_iotm2");
          let e = await fetch(
            "http://" + t[0].ip,
            {
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${t}`,
              },
              mode: "cors",
              method: "GET",
            }
          );
          e.ok
            ? (n(9, (g = await e.json())),
              (function (t) {
                t.length &&
                  (t[0].processed
                    ? (clearInterval(h),
                      console.log("no interval - all task done"))
                    : (console.log("non completed task exist!"),
                      h ||
                      (console.log("interval checking started"),
                        (h = setInterval(m, 1e4)))));
              })(g))
            : console.log("error", e.statusText);
        } catch (t) {
          console.log("error", t);
        }
      },
      x = async (t) => {
        try {
          const e = un.get("token_iotm2");
          let n = await fetch(
            "http://" + t[0].ip + t.orderId,
            {
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${e}`,
              },
              mode: "cors",
              method: "GET",
            }
          );
          n.ok ? await b() : console.log("error", n.statusText);
        } catch (t) {
          console.log("error", t);
        }
      },
      v = async () => {
        delete c._id, n(0, (c.username = d.username), c);
        const t = un.get("token_iotm2");
        try {
          let e = await fetch("http://" + t[0].ip, {
            mode: "cors",
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${t}`,
            },
            body: JSON.stringify(c),
          });
          const s = await e.json();
          e.ok
            ? (n(8, (p = [{ msg: "ok_success" }])),
              await b(),
              console.log(s.message))
            : n(8, (p = s.message));
        } catch (t) {
          console.log(t);
        }
      },
      $ = async () => {
        un.remove("token_iotm2"), Ct.goto("/login"), location.reload();
      },
      w = async (t, e) => { };
    return (
      (t.$$set = (t) => {
        "show" in t && n(1, (r = t.show)),
          "flashProfileJson" in t && n(2, (o = t.flashProfileJson)),
          "otaJson" in t && n(3, (l = t.otaJson)),
          "allmodeinfo" in t && n(4, (i = t.allmodeinfo)),
          "profile" in t && n(0, (c = t.profile)),
          "serverOnline" in t && n(5, (u = t.serverOnline)),
          "userdata" in t && n(6, (d = t.userdata)),
          "updateBuild" in t && n(7, (f = t.updateBuild));
      }),
      [
        c,
        r,
        o,
        l,
        i,
        u,
        d,
        f,
        p,
        g,
        s,
        { 0: "", 1: "В процессе", 2: "Ок", 3: "Ошибка" },
        x,
        v,
        $,
        w,
        (t, e, s) => n(0, (e[s].active = !t.active), c),
        (t, e, s) => n(0, (e[s].active = !t.active), c),
        (t, e, s) => n(0, (e[s].active = !t.active), c),
        (t, e, s) => n(0, (e[s].active = !t.active), c),
        () => v(),
        (t) => w(),
        (t) => w(),
        (t) => w(),
        (t) =>
          f(
            "http://" + t[0].ip + t.orderId
          ),
        (t) => x(t),
        () => $(),
      ]
    );
  }
  class Ir extends ut {
    constructor(t) {
      super(),
        at(
          this,
          t,
          Ar,
          Hr,
          o,
          {
            show: 1,
            flashProfileJson: 2,
            otaJson: 3,
            allmodeinfo: 4,
            profile: 0,
            serverOnline: 5,
            userdata: 6,
            updateBuild: 7,
          },
          null,
          [-1, -1]
        );
    }
  }
  function qr(e) {
    let n, s, r, o;
    return {
      c() {
        (n = w("svg")),
          (s = w("path")),
          L(
            s,
            "d",
            "M7 18a4.6 4.4 0 0 1 0 -9h0a5 4.5 0 0 1 11 2h1a3.5 3.5 0 0 1 0 7h-12"
          ),
          L(n, "class", (r = "h-8 w-8 " + e[0])),
          L(n, "width", "8"),
          L(n, "height", "8"),
          L(n, "viewBox", (o = e[1] + " " + e[2] + " 24 24")),
          L(n, "stroke-width", "2"),
          L(n, "stroke", "currentColor"),
          L(n, "fill", "none"),
          L(n, "stroke-linecap", "round"),
          L(n, "stroke-linejoin", "round");
      },
      m(t, e) {
        b(t, n, e), m(n, s);
      },
      p(t, [e]) {
        1 & e && r !== (r = "h-8 w-8 " + t[0]) && L(n, "class", r),
          6 & e &&
          o !== (o = t[1] + " " + t[2] + " 24 24") &&
          L(n, "viewBox", o);
      },
      i: t,
      o: t,
      d(t) {
        t && x(n);
      },
    };
  }
  function zr(t, e, n) {
    let { color: s } = e,
      { x: r = 0 } = e,
      { y: o = 0 } = e;
    return (
      (t.$$set = (t) => {
        "color" in t && n(0, (s = t.color)),
          "x" in t && n(1, (r = t.x)),
          "y" in t && n(2, (o = t.y));
      }),
      [s, r, o]
    );
  }
  class Br extends ut {
    constructor(t) {
      super(), at(this, t, zr, qr, o, { color: 0, x: 1, y: 2 });
    }
  }
  const { window: Rr } = h;
  function Fr(t, e, n) {
    const s = t.slice();
    return (s[135] = e[n]), s;
  }
  function Zr(t) {
    let e, n;
    return (
      (e = new Ut({})),
      {
        c() {
          lt(e.$$.fragment);
        },
        m(t, s) {
          it(e, t, s), (n = !0);
        },
        i(t) {
          n || (st(e.$$.fragment, t), (n = !0));
        },
        o(t) {
          rt(e.$$.fragment, t), (n = !1);
        },
        d(t) {
          ct(e, t);
        },
      }
    );
  }
  function Wr(t) {
    let e,
      n,
      r,
      o,
      l = t[20],
      i = [];
    for (let e = 0; e < l.length; e += 1) i[e] = Ur(Fr(t, l, e));
    return {
      c() {
        (e = $("div")), (n = $("select"));
        for (let t = 0; t < i.length; t += 1) i[t].c();
        L(n, "class", "border border-indigo-500 border-1"),
          void 0 === t[28] && U(() => t[53].call(n)),
          L(e, "class", "px-15 py-1");
      },
      m(s, l) {
        b(s, e, l), m(e, n);
        for (let t = 0; t < i.length; t += 1) i[t] && i[t].m(n, null);
        O(n, t[28], !0),
          r || ((o = [j(n, "change", t[53]), j(n, "change", t[54])]), (r = !0));
      },
      p(t, e) {
        if (1048576 & e[0]) {
          let s;
          for (l = t[20], s = 0; s < l.length; s += 1) {
            const r = Fr(t, l, s);
            i[s] ? i[s].p(r, e) : ((i[s] = Ur(r)), i[s].c(), i[s].m(n, null));
          }
          for (; s < i.length; s += 1) i[s].d(1);
          i.length = l.length;
        }
        269484032 & e[0] && O(n, t[28]);
      },
      d(t) {
        t && x(e), v(i, t), (r = !1), s(o);
      },
    };
  }
  function Ur(t) {
    let e,
      n,
      s,
      r,
      o = t[135].name + "";
    return {
      c() {
        (e = $("option")),
          (n = y(o)),
          (s = k()),
          (e.__value = r = t[135].ws),
          (e.value = e.__value);
      },
      m(t, r) {
        b(t, e, r), m(e, n), m(e, s);
      },
      p(t, s) {
        1048576 & s[0] && o !== (o = t[135].name + "") && M(n, o),
          1048576 & s[0] &&
          r !== (r = t[135].ws) &&
          ((e.__value = r), (e.value = e.__value));
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function Yr(t) {
    let e, n;
    return {
      c() {
        (e = $("li")),
          (n = $("a")),
          (n.textContent = ""),
          L(n, "class", "menu__item"),
          L(n, "href", "/");
      },
      m(t, s) {
        b(t, e, s), m(e, n);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function Vr(t) {
    let e, n;
    return {
      c() {
        (e = $("li")),
          (n = $("a")),
          (n.textContent = "Модули"),
          L(n, "class", "menu__item"),
          L(n, "href", "/");
      },
      m(t, s) {
        b(t, e, s), m(e, n);
      },
      d(t) {
        t && x(e);
      },
    };
  }
  function Xr(t) {
    let e, n, s, r, o, l, i, c, a, u, d, f, p, g, h, m;
    return (
      (e = new Ht({
        props: { path: "/", $$slots: { default: [Kr] }, $$scope: { ctx: t } },
      })),
      (s = new Ht({
        props: {
          path: "/config",
          $$slots: { default: [Qr] },
          $$scope: { ctx: t },
        },
      })),
      (o = new Ht({
        props: {
          path: "/connection",
          $$slots: { default: [to] },
          $$scope: { ctx: t },
        },
      })),
      (i = new Ht({
        props: {
          path: "/list",
          $$slots: { default: [eo] },
          $$scope: { ctx: t },
        },
      })),
      (a = new Ht({
        props: {
          path: "/system",
          $$slots: { default: [no] },
          $$scope: { ctx: t },
        },
      })),
      (d = new Ht({
        props: {
          path: "/edit",
          $$slots: { default: [so] },
          $$scope: { ctx: t },
        },
      })),
      (p = new Ht({
        props: {
          path: "/profile",
          $$slots: { default: [ro] },
          $$scope: { ctx: t },
        },
      })),
      (h = new Ht({
        props: {
          path: "/login",
          $$slots: { default: [oo] },
          $$scope: { ctx: t },
        },
      })),
      {
        c() {
          lt(e.$$.fragment),
            (n = k()),
            lt(s.$$.fragment),
            (r = k()),
            lt(o.$$.fragment),
            (l = k()),
            lt(i.$$.fragment),
            (c = k()),
            lt(a.$$.fragment),
            (u = k()),
            lt(d.$$.fragment),
            (f = k()),
            lt(p.$$.fragment),
            (g = k()),
            lt(h.$$.fragment);
        },
        m(t, x) {
          it(e, t, x),
            b(t, n, x),
            it(s, t, x),
            b(t, r, x),
            it(o, t, x),
            b(t, l, x),
            it(i, t, x),
            b(t, c, x),
            it(a, t, x),
            b(t, u, x),
            it(d, t, x),
            b(t, f, x),
            it(p, t, x),
            b(t, g, x),
            it(h, t, x),
            (m = !0);
        },
        p(t, n) {
          const r = {};
          (2097536 & n[0]) | (16384 & n[4]) &&
            (r.$$scope = { dirty: n, ctx: t }),
            e.$set(r);
          const l = {};
          (4225280 & n[0]) | (16384 & n[4]) &&
            (l.$$scope = { dirty: n, ctx: t }),
            s.$set(l);
          const c = {};
          (229632 & n[0]) | (16384 & n[4]) &&
            (c.$$scope = { dirty: n, ctx: t }),
            o.$set(c);
          const u = {};
          (537952528 & n[0]) | (16384 & n[4]) &&
            (u.$$scope = { dirty: n, ctx: t }),
            i.$set(u);
          const f = {};
          (1073907456 & n[0]) | (16384 & n[4]) &&
            (f.$$scope = { dirty: n, ctx: t }),
            a.$set(f);
          const g = {};
          (134217984 & n[0]) | (16384 & n[4]) &&
            (g.$$scope = { dirty: n, ctx: t }),
            d.$set(g);
          const m = {};
          (63701248 & n[0]) | (16384 & n[4]) &&
            (m.$$scope = { dirty: n, ctx: t }),
            p.$set(m);
          const b = {};
          (33554432 & n[0]) | (16384 & n[4]) &&
            (b.$$scope = { dirty: n, ctx: t }),
            h.$set(b);
        },
        i(t) {
          m ||
            (st(e.$$.fragment, t),
              st(s.$$.fragment, t),
              st(o.$$.fragment, t),
              st(i.$$.fragment, t),
              st(a.$$.fragment, t),
              st(d.$$.fragment, t),
              st(p.$$.fragment, t),
              st(h.$$.fragment, t),
              (m = !0));
        },
        o(t) {
          rt(e.$$.fragment, t),
            rt(s.$$.fragment, t),
            rt(o.$$.fragment, t),
            rt(i.$$.fragment, t),
            rt(a.$$.fragment, t),
            rt(d.$$.fragment, t),
            rt(p.$$.fragment, t),
            rt(h.$$.fragment, t),
            (m = !1);
        },
        d(t) {
          ct(e, t),
            t && x(n),
            ct(s, t),
            t && x(r),
            ct(o, t),
            t && x(l),
            ct(i, t),
            t && x(c),
            ct(a, t),
            t && x(u),
            ct(d, t),
            t && x(f),
            ct(p, t),
            t && x(g),
            ct(h, t);
        },
      }
    );
  }
  function Gr(t) {
    let e, n;
    return (
      (e = new Zt({ props: { title: "Подключение через " + t[0] + " сек." } })),
      {
        c() {
          lt(e.$$.fragment);
        },
        m(t, s) {
          it(e, t, s), (n = !0);
        },
        p(t, n) {
          const s = {};
          1 & n[0] && (s.title = "Подключение через " + t[0] + " сек."),
            e.$set(s);
        },
        i(t) {
          n || (st(e.$$.fragment, t), (n = !0));
        },
        o(t) {
          rt(e.$$.fragment, t), (n = !1);
        },
        d(t) {
          ct(e, t);
        },
      }
    );
  }
  function Kr(t) {
    let e, n;
    return (
      (e = new en({
        props: {
          show: t[8].dash,
          layoutJson: t[21],
          pages: t[7],
          wsPush: t[57],
        },
      })),
      {
        c() {
          lt(e.$$.fragment);
        },
        m(t, s) {
          it(e, t, s), (n = !0);
        },
        p(t, n) {
          const s = {};
          256 & n[0] && (s.show = t[8].dash),
            2097152 & n[0] && (s.layoutJson = t[21]),
            128 & n[0] && (s.pages = t[7]),
            e.$set(s);
        },
        i(t) {
          n || (st(e.$$.fragment, t), (n = !0));
        },
        o(t) {
          rt(e.$$.fragment, t), (n = !1);
        },
        d(t) {
          ct(e, t);
        },
      }
    );
  }
  function Qr(t) {
    let e, n, s, r;
    function o(e) {
      t[62](e);
    }
    function l(e) {
      t[63](e);
    }
    let i = {
      show: t[8].config,
      widgetsJson: t[12],
      itemsJson: t[11],
      saveConfig: t[58],
      cleanLogs: t[59],
      rebootEsp: t[60],
      moduleOrder: t[61],
      userdata: t[22],
    };
    return (
      void 0 !== t[13] && (i.configJson = t[13]),
      void 0 !== t[14] && (i.scenarioTxt = t[14]),
      (e = new Yn({ props: i })),
      z.push(() => ot(e, "configJson", o)),
      z.push(() => ot(e, "scenarioTxt", l)),
      {
        c() {
          lt(e.$$.fragment);
        },
        m(t, n) {
          it(e, t, n), (r = !0);
        },
        p(t, r) {
          const o = {};
          256 & r[0] && (o.show = t[8].config),
            4096 & r[0] && (o.widgetsJson = t[12]),
            2048 & r[0] && (o.itemsJson = t[11]),
            4194304 & r[0] && (o.userdata = t[22]),
            !n &&
            8192 & r[0] &&
            ((n = !0), (o.configJson = t[13]), Y(() => (n = !1))),
            !s &&
            16384 & r[0] &&
            ((s = !0), (o.scenarioTxt = t[14]), Y(() => (s = !1))),
            e.$set(o);
        },
        i(t) {
          r || (st(e.$$.fragment, t), (r = !0));
        },
        o(t) {
          rt(e.$$.fragment, t), (r = !1);
        },
        d(t) {
          ct(e, t);
        },
      }
    );
  }
  function to(t) {
    let e, n;
    return (
      (e = new as({
        props: {
          show: t[8].connection,
          rebootEsp: t[64],
          ssidClick: t[65],
          saveSett: t[66],
          saveMqtt: t[67],
          settingsJson: t[15],
          errorsJson: t[17],
          ssidJson: t[16],
        },
      })),
      {
        c() {
          lt(e.$$.fragment);
        },
        m(t, s) {
          it(e, t, s), (n = !0);
        },
        p(t, n) {
          const s = {};
          256 & n[0] && (s.show = t[8].connection),
            32768 & n[0] && (s.settingsJson = t[15]),
            131072 & n[0] && (s.errorsJson = t[17]),
            65536 & n[0] && (s.ssidJson = t[16]),
            e.$set(s);
        },
        i(t) {
          n || (st(e.$$.fragment, t), (n = !0));
        },
        o(t) {
          rt(e.$$.fragment, t), (n = !1);
        },
        d(t) {
          ct(e, t);
        },
      }
    );
  }
  function eo(t) {
    let e, n;
    return (
      (e = new $s({
        props: {
          show: t[8].list,
          deviceList: t[20],
          settingsJson: t[15],
          saveSett: t[68],
          rebootEsp: t[69],
          showInput: io,
          addDevInList: t[70],
          newDevice: t[29],
          sendToAllDevices: t[71],
          saveList: t[72],
          percent: t[4],
          devListOverride: t[73],
          applicationReboot: t[74],
        },
      })),
      {
        c() {
          lt(e.$$.fragment);
        },
        m(t, s) {
          it(e, t, s), (n = !0);
        },
        p(t, n) {
          const s = {};
          256 & n[0] && (s.show = t[8].list),
            1048576 & n[0] && (s.deviceList = t[20]),
            32768 & n[0] && (s.settingsJson = t[15]),
            536870912 & n[0] && (s.newDevice = t[29]),
            16 & n[0] && (s.percent = t[4]),
            e.$set(s);
        },
        i(t) {
          n || (st(e.$$.fragment, t), (n = !0));
        },
        o(t) {
          rt(e.$$.fragment, t), (n = !1);
        },
        d(t) {
          ct(e, t);
        },
      }
    );
  }
  function no(t) {
    let e, n, s;
    function r(e) {
      t[81](e);
    }
    let o = {
      show: t[8].system,
      errorsJson: t[17],
      settingsJson: t[15],
      saveSett: t[75],
      rebootEsp: t[76],
      uploadFirmware: t[77],
      setBrowserTime: t[78],
      cleanLogs: t[79],
      cancelAlarm: t[80],
      versionsList: t[9],
      coreMessages: t[30],
      onFileSelected: t[34],
    };
    return (
      void 0 !== t[10] && (o.choosingVersion = t[10]),
      (e = new Rs({ props: o })),
      z.push(() => ot(e, "choosingVersion", r)),
      {
        c() {
          lt(e.$$.fragment);
        },
        m(t, n) {
          it(e, t, n), (s = !0);
        },
        p(t, s) {
          const r = {};
          256 & s[0] && (r.show = t[8].system),
            131072 & s[0] && (r.errorsJson = t[17]),
            32768 & s[0] && (r.settingsJson = t[15]),
            512 & s[0] && (r.versionsList = t[9]),
            1073741824 & s[0] && (r.coreMessages = t[30]),
            !n &&
            1024 & s[0] &&
            ((n = !0), (r.choosingVersion = t[10]), Y(() => (n = !1))),
            e.$set(r);
        },
        i(t) {
          s || (st(e.$$.fragment, t), (s = !0));
        },
        o(t) {
          rt(e.$$.fragment, t), (s = !1);
        },
        d(t) {
          ct(e, t);
        },
      }
    );
  }
  function so(t) {
    let e, n;
    return (
      (e = new Ys({ props: { show: t[8].edit, espIP: t[27].ip } })),
      {
        c() {
          lt(e.$$.fragment);
        },
        m(t, s) {
          it(e, t, s), (n = !0);
        },
        p(t, n) {
          const s = {};
          256 & n[0] && (s.show = t[8].edit),
            134217728 & n[0] && (s.espIP = t[27].ip),
            e.$set(s);
        },
        i(t) {
          n || (st(e.$$.fragment, t), (n = !0));
        },
        o(t) {
          rt(e.$$.fragment, t), (n = !1);
        },
        d(t) {
          ct(e, t);
        },
      }
    );
  }
  function ro(t) {
    let e, n;
    return (
      (e = new Ir({
        props: {
          show: t[8].profile,
          flashProfileJson: t[18],
          userdata: t[22],
          updateBuild: t[82],
          allmodeinfo: t[23],
          profile: t[24],
          serverOnline: t[25],
          otaJson: t[19],
        },
      })),
      {
        c() {
          lt(e.$$.fragment);
        },
        m(t, s) {
          it(e, t, s), (n = !0);
        },
        p(t, n) {
          const s = {};
          256 & n[0] && (s.show = t[8].profile),
            262144 & n[0] && (s.flashProfileJson = t[18]),
            4194304 & n[0] && (s.userdata = t[22]),
            8388608 & n[0] && (s.allmodeinfo = t[23]),
            16777216 & n[0] && (s.profile = t[24]),
            33554432 & n[0] && (s.serverOnline = t[25]),
            524288 & n[0] && (s.otaJson = t[19]),
            e.$set(s);
        },
        i(t) {
          n || (st(e.$$.fragment, t), (n = !0));
        },
        o(t) {
          rt(e.$$.fragment, t), (n = !1);
        },
        d(t) {
          ct(e, t);
        },
      }
    );
  }
  function oo(t) {
    let e, n;
    return (
      (e = new or({ props: { show: !0, serverOnline: t[25] } })),
      {
        c() {
          lt(e.$$.fragment);
        },
        m(t, s) {
          it(e, t, s), (n = !0);
        },
        p(t, n) {
          const s = {};
          33554432 & n[0] && (s.serverOnline = t[25]), e.$set(s);
        },
        i(t) {
          n || (st(e.$$.fragment, t), (n = !0));
        },
        o(t) {
          rt(e.$$.fragment, t), (n = !1);
        },
        d(t) {
          ct(e, t);
        },
      }
    );
  }
  function lo(t) {
    let e,
      n,
      r,
      o,
      l,
      i,
      c,
      a,
      u,
      d,
      f,
      p,
      g,
      h,
      v,
      w,
      y,
      _,
      C,
      S,
      M,
      T,
      J,
      O,
      E,
      N,
      P,
      D,
      H,
      A,
      I,
      q,
      z,
      B,
      R,
      F,
      Z,
      W,
      Y,
      V,
      X,
      G,
      K,
      Q,
      tt,
      ot;
    U(t[52]);
    let at = t[6] && Zr(),
      ut = t[5] && Wr(t);
    function dt(t, e) {
      return t[22] ? Vr : Yr;
    }
    c = new Br({
      props: { color: !0 === t[26] ? "text-green-500" : "text-red-500" },
    });
    let ft = dt(t),
      pt = ft(t);
    const gt = [Gr, Xr],
      ht = [];
    function mt(t, e) {
      return t[26] || "/|" == t[31] ? 1 : 0;
    }
    return (
      (Y = mt(t)),
      (V = ht[Y] = gt[Y](t)),
      {
        c() {
          (e = $("div")),
            at && at.c(),
            (n = k()),
            (r = $("header")),
            (o = $("div")),
            ut && ut.c(),
            (l = k()),
            (i = $("div")),
            lt(c.$$.fragment),
            (a = k()),
            (u = $("nav")),
            (d = $("input")),
            (f = k()),
            (p = $("label")),
            (p.innerHTML = "<span></span>"),
            (g = k()),
            (h = $("ul")),
            (v = $("li")),
            (w = $("a")),
            (w.textContent = "Управление"),
            (y = k()),
            (_ = $("li")),
            (C = $("a")),
            (C.textContent = "Конфигуратор"),
            (S = k()),
            (M = $("li")),
            (T = $("a")),
            (T.textContent = "Подключение"),
            (J = k()),
            (O = $("li")),
            (E = $("a")),
            (E.textContent = "Системные"),
            (N = k()),
            (P = $("li")),
            (D = $("a")),
            (D.textContent = "Устройства"),
            (H = k()),
            (A = $("li")),
            (I = $("a")),
            (I.textContent = "Файлы"),
            (q = k()),
            pt.c(),
            (z = k()),
            (B = $("li")),
            (R = k()),
            (F = $("main")),
            (Z = $("ul")),
            (W = $("div")),
            V.c(),
            (G = k()),
            (K = $("footer")),
            (K.innerHTML =
              '<div class="flex justify-center content-center text-xxs text-gray-500">Developed by Dmitry Borisenko</div>'),
            L(i, "class", "pl-4 pr-4 py-1"),
            L(o, "class", "flex content-center items-center justify-end"),
            L(r, "class", "h-10 w-full bg-gray-100 overflow-auto shadow-md"),
            L(d, "class", "w-0 h-0"),
            L(d, "id", "menu__toggle"),
            L(d, "type", "checkbox"),
            L(p, "class", "menu__btn"),
            L(p, "for", "menu__toggle"),
            L(w, "class", "menu__item"),
            L(w, "href", "/"),
            L(C, "class", "menu__item"),
            L(C, "href", "/config"),
            L(T, "class", "menu__item"),
            L(T, "href", "/connection"),
            L(E, "class", "menu__item"),
            L(E, "href", "/system"),
            L(D, "class", "menu__item"),
            L(D, "href", "/list"),
            L(I, "class", "menu__item"),
            L(I, "href", "/edit"),
            L(B, "class", "flex flex-col pl-6 pt-3 w-full h-screen"),
            L(h, "class", "menu__box"),
            L(u, "class", "flex"),
            L(W, "class", "bg-cover pt-0 px-4"),
            L(Z, "class", "menu__main"),
            L(
              F,
              "class",
              (X =
                "flex-1 overflow-y-auto p-0 " +
                (!0 !== t[1] || t[2] ? "ml-0" : "ml-36"))
            ),
            L(K, "class", "h-4 bg-gray-100 border-gray-300 shadow-lg"),
            L(e, "class", "flex flex-col h-screen bg-gray-50");
        },
        m(s, x) {
          b(s, e, x),
            at && at.m(e, null),
            m(e, n),
            m(e, r),
            m(r, o),
            ut && ut.m(o, null),
            m(o, l),
            m(o, i),
            it(c, i, null),
            m(e, a),
            m(e, u),
            m(u, d),
            (d.checked = t[1]),
            m(u, f),
            m(u, p),
            m(u, g),
            m(u, h),
            m(h, v),
            m(v, w),
            m(h, y),
            m(h, _),
            m(_, C),
            m(h, S),
            m(h, M),
            m(M, T),
            m(h, J),
            m(h, O),
            m(O, E),
            m(h, N),
            m(h, P),
            m(P, D),
            m(h, H),
            m(h, A),
            m(A, I),
            m(h, q),
            pt.m(h, null),
            m(h, z),
            m(h, B),
            m(e, R),
            m(e, F),
            m(F, Z),
            m(Z, W),
            ht[Y].m(W, null),
            m(e, G),
            m(e, K),
            (Q = !0),
            tt ||
            ((ot = [
              j(Rr, "resize", t[52]),
              j(d, "change", t[55]),
              j(d, "change", t[56]),
            ]),
              (tt = !0));
        },
        p(t, s) {
          t[6]
            ? at
              ? 64 & s[0] && st(at, 1)
              : ((at = Zr()), at.c(), st(at, 1), at.m(e, n))
            : at &&
            (et(),
              rt(at, 1, 1, () => {
                at = null;
              }),
              nt()),
            t[5]
              ? ut
                ? ut.p(t, s)
                : ((ut = Wr(t)), ut.c(), ut.m(o, l))
              : ut && (ut.d(1), (ut = null));
          const r = {};
          67108864 & s[0] &&
            (r.color = !0 === t[26] ? "text-green-500" : "text-red-500"),
            c.$set(r),
            2 & s[0] && (d.checked = t[1]),
            ft !== (ft = dt(t)) &&
            (pt.d(1), (pt = ft(t)), pt && (pt.c(), pt.m(h, z)));
          let i = Y;
          (Y = mt(t)),
            Y === i
              ? ht[Y].p(t, s)
              : (et(),
                rt(ht[i], 1, 1, () => {
                  ht[i] = null;
                }),
                nt(),
                (V = ht[Y]),
                V ? V.p(t, s) : ((V = ht[Y] = gt[Y](t)), V.c()),
                st(V, 1),
                V.m(W, null)),
            (!Q ||
              (6 & s[0] &&
                X !==
                (X =
                  "flex-1 overflow-y-auto p-0 " +
                  (!0 !== t[1] || t[2] ? "ml-0" : "ml-36")))) &&
            L(F, "class", X);
        },
        i(t) {
          Q || (st(at), st(c.$$.fragment, t), st(V), (Q = !0));
        },
        o(t) {
          rt(at), rt(c.$$.fragment, t), rt(V), (Q = !1);
        },
        d(t) {
          t && x(e),
            at && at.d(),
            ut && ut.d(),
            ct(c),
            pt.d(),
            ht[Y].d(),
            (tt = !1),
            s(ot);
        },
      }
    );
  }
  let io = !1;
  async function co(t, e, n) {
    let s = t.slice(e, t.length),
      r = await s.text();
    try {
      (n.json = JSON.parse(r)), (n.parse = !0);
    } catch (t) {
      n.parse = !1;
    }
    return n.parse;
  }
  async function ao(t, e) {
    let n = t.slice(e, t.length);
    return await n.text();
  }
  function uo(t) {
    let e = t.shift();
    t.sort((t, e) => (t.name < e.name ? -1 : t.name > e.name ? 1 : 0)),
      t.unshift(e);
  }
  function fo(t, e) {
    for (var n in e) t[n] = e[n];
    return t;
  }
  function po(t, e) {
    for (var n in e) "status" !== n && (t[n] = e[n]);
    return t;
  }
  function go(t, e, n) {
    let s;
    a(t, Ct, (t) => n(97, (s = t))), Ct.mode.hash();
    let r,
      o,
      l,
      i = {},
      c = 60,
      u = c,
      d = !1,
      f = !0,
      p = !1,
      g = document.location.hostname,
      h = !0,
      m = !0,
      b = !1,
      x = [],
      v = {
        dash: !1,
        config: !1,
        connection: !1,
        list: !1,
        system: !1,
        dev: !1,
        edit: !1,
      },
      $ = {},
      w = [],
      y = [],
      k = [],
      _ = " ",
      j = {},
      C = {},
      L = {},
      S = {},
      M = {},
      T = [];
    T = [{ name: "--", id: "--", ip: g, ws: 0, status: !1 }];
    var J = [],
      O = [],
      N = [];
    let P,
      D,
      A = [],
      I = [],
      q = {},
      z = null,
      B = null,
      R = null,
      F = !1,
      Z = {
        itemsJson: !1,
        widgetsJson: !1,
        configJson: !1,
        scenarioTxt: !1,
        settingsJson: !1,
        ssidJson: !1,
        incDeviceList: !1,
        deviceListJson: !1,
        errorsJson: !1,
        statusJson: !1,
        paramsJson: !1,
        flashProfileJson: !1,
        otaJson: !1,
      },
      W = [],
      U = !1,
      Y = 0,
      V = {},
      X = [];
    function G() {
      n(31, (D = s.path.toString())),
        n(31, (D += "|")),
        console.log("[i]", "user on page:", D),
        yt(),
        "/edit|" === D && n(8, (v.edit = !0), v),
        "/|" === D
          ? (Mt(D), n(5, (m = !1)))
          : (n(5, (m = "/list|" !== D)), K());
    }
    function K() {
      void 0 !== Y && St(Y, D);
    }
    Ct.subscribe(G),
      H(async () => {
        console.log("[i]", "mounted"),
          await Q(),
          Pt(),
          n(1, (f = r > 900)),
          Jt(),
          (h = !0),
          tt(),
          jt(),
          setInterval(() => {
            T.forEach((t) => {
              if (t.status && W[t.ws] && 1 === W[t.ws].readyState) {
                W[t.ws].send("/pi|");
                const e = t.ws;
                let n = st(e);
                console.log(`[WS${e}] ping ${n}`),
                  i[e] && clearTimeout(i[e]),
                  (i[e] = setTimeout(
                    () =>
                      ((t) => {
                        console.log(`[WS${t}] Пинг-таймаут! Нет ответа 1.5 сек`);
                      })(e),
                    1500
                  ));
              }
            });
          }, 2e3);
      });
    const Q = async () => {

    };
    function tt() {
      Et(Y);
      for (let t = 0; t < T.length; t++)
        n(20, (T[t].ws = t), T),
          (!1 !== T[t].status && void 0 !== T[t].status) || (nt(t), rt(t));
    }
    function et(t, e) {
      T.forEach((s) => {
        s.ws === t &&
          ((s.status = e),
            (s.ping = 0),
            !0 === s.status
              ? console.log("[i]", s.ip, t, "status online")
              : (console.log("[i]", s.ip, t, "status offline"),
                (function (t) {
                  n(21, (I = I.filter((e) => e.ws !== t)));
                })(t),
                dt(t)));
      }),
        Jt(),
        n(20, T);
    }
    function nt(t) {
      let e = st(t);
      "error" === e
        ? (console.log(`[WS${t}] Ошибка соединения с ${e}`),
          i[t] && clearTimeout(i[t]))
        : ((W[t] = new WebSocket("ws://" + e + ":81")),
          (W.binaryType = "blob"),
          console.log("[i]", e, t, "started connecting..."));
    }
    function st(t) {
      let e = "error";
      return (
        T.forEach((n) => {
          t === n.ws && (e = n.ip);
        }),
        e
      );
    }
    function rt(t) {
      W[t] &&
        (st(t),
          W[t].addEventListener("open", (e) => {
            et(t, !0),
              h && 0 === t && St(t, "/devlist|"),
              "/|" === D ? St(t, D) : t === Y && K();
          }),
          W[t].addEventListener("message", (e) => {
            if ("string" == typeof e.data) {
              let n = e.data;
              if ("/po|" === e.data)
                return (
                  console.log(`[WS${t}] Получен pong`),
                  void (i[t] && clearTimeout(i[t]))
                );
              "/tstr|" === n && Lt(t, !0);
            }
            e.data instanceof Blob &&
              (t === Y &&
                (async function (t, e) {
                  var s = t.slice(0, 6);
                  let r = await s.text();
                  var o = t.slice(7, 11);
                  let l = await o.text();
                  if ("itemsj" === r) {
                    let e = {};
                    (await co(t, l, e))
                      ? (n(11, (w = e.json)), (Z.itemsJson = !0))
                      : (Z.itemsJson = !1);
                  }
                  if ("widget" === r) {
                    let e = {};
                    (await co(t, l, e))
                      ? (n(12, (y = e.json)), (Z.widgetsJson = !0))
                      : (Z.widgetsJson = !1);
                  }
                  if ("config" === r) {
                    let e = {};
                    (await co(t, l, e))
                      ? (n(13, (k = e.json)), (Z.configJson = !0))
                      : (Z.configJson = !1);
                  }
                  if (
                    ("scenar" === r && n(14, (_ = await ao(t, l))),
                      "settin" === r)
                  ) {
                    let e = {};
                    (await co(t, l, e))
                      ? (n(15, (j = e.json)), (Z.settingsJson = !0))
                      : (Z.settingsJson = !1);
                  }
                  if ("ssidli" === r) {
                    let e = {};
                    (await co(t, l, e))
                      ? (n(16, (C = e.json)), (Z.ssidJson = !0))
                      : (Z.ssidJson = !1);
                  }
                  if ("errors" === r) {
                    let e = {};
                    (await co(t, l, e))
                      ? (n(17, (L = e.json)), (Z.errorsJson = !0))
                      : (Z.errorsJson = !1);
                  }
                  if ("devlis" === r) {
                    let e = {};
                    (await co(t, l, e))
                      ? ((A = []),
                        (A = e.json),
                        (Z.incDeviceList = !0),
                        await (async function () {
                          h ? at() : ut(),
                            (h = !1),
                            n(20, T),
                            (Z.deviceListJson = !0),
                            ot(),
                            Jt(),
                            tt();
                        })())
                      : (Z.incDeviceList = !1);
                  }
                  if ("prfile" === r) {
                    let e = {};
                    (await co(t, l, e))
                      ? (n(18, (S = e.json)), (Z.flashProfileJson = !0))
                      : (Z.flashProfileJson = !1);
                  }
                  if ("otaupd" === r) {
                    let e = {};
                    (await co(t, l, e))
                      ? (n(19, (M = e.json)), (Z.otaJson = !0))
                      : (Z.otaJson = !1);
                  }
                  if ("corelg" === r) {
                    let e = await ao(t, l);
                    Tt(e);
                  }
                  await ot();
                })(e.data),
                "/|" === D &&
                (async function (t, e) {
                  var s = t.slice(0, 6);
                  let r = await s.text();
                  var o = t.slice(7, 11);
                  let l = await o.text();
                  if ("status" === r) {
                    let e = {};
                    (await co(t, l, e)) &&
                      (function (t) {
                        for (let e = 0; e < I.length; e++)
                          if (I[e].topic === t.topic) {
                            n(21, (I[e] = fo(I[e], t)), I),
                              n(21, (I[e].sent = !1), I);
                            break;
                          }
                      })(e.json);
                  }
                  if ("layout" === r) {
                    let s = {};
                    (await co(t, l, s)) &&
                      (async function (t, e) {
                        for (let n = 0; n < e.length; n++) e[n].ws = t;
                        n(21, (I = I.concat(e))),
                          console.log("[2]", t, "devLayout pushed to layout"),
                          dt(t);
                      })(e, s.json);
                  }
                  if ("params" === r) {
                    let s = {};
                    if (await co(t, l, s)) {
                      let t = s.json;
                      (q = { ...q, ...t }),
                        (function (t) {
                          for (const [t, e] of Object.entries(q))
                            for (let s = 0; s < I.length; s++) {
                              let r = I[s].topic;
                              if (
                                r &&
                                ((r = r.substring(
                                  r.lastIndexOf("/") + 1,
                                  r.length
                                )),
                                  t === r)
                              ) {
                                console.log("[i]", "updated =>" + r, e),
                                  n(21, (I[s].status = e), I);
                                break;
                              }
                            }
                          St(t, "/charts|");
                        })(e),
                        ot();
                    }
                  }
                  if ("charta" === r) {
                    let e,
                      n = await ao(t, l);
                    n = "[" + n.substring(0, n.length - 1) + "]";
                    try {
                      e = JSON.parse(n);
                    } catch (t) {
                      return;
                    }
                    let s = {},
                      r = {};
                    if (
                      !(await (async function (t, e, n) {
                        let s = t.slice(12, e),
                          r = await s.text();
                        try {
                          (n.json = JSON.parse(r)), (n.parse = !0);
                        } catch (t) {
                          n.parse = !1;
                        }
                        return n.parse;
                      })(t, l, s))
                    )
                      return;
                    r = s.json;
                    let o = {};
                    (o.status = e), (o = { ...o, ...r }), ft(o);
                  }
                  if ("chartb" === r) {
                    let e = {};
                    (await co(t, l, e)) && ft(e.json);
                  }
                })(e.data, t));
          }),
          W[t].addEventListener("close", (e) => {
            console.log(
              `[WS${t}] Соединение закрыто. Код: ${e.code}, Причина: ${e.reason}`
            ),
              i[t] && clearTimeout(i[t]),
              et(t, !1);
          }),
          W[t].addEventListener("error", (e) => {
            et(t, !1);
          }));
    }
    async function ot() {
      "/|" === D && n(8, (v.dash = !0), v),
        "/config|" === D &&
        Z.itemsJson &&
        Z.widgetsJson &&
        Z.configJson &&
        Z.settingsJson &&
        (kt(), n(8, (v.config = !0), v)),
        "/connection|" === D &&
        Z.ssidJson &&
        Z.settingsJson &&
        Z.errorsJson &&
        (kt(), n(8, (v.connection = !0), v)),
        "/list|" === D && Z.settingsJson && (kt(), n(8, (v.list = !0), v)),
        "/system|" === D &&
        Z.errorsJson &&
        Z.settingsJson &&
        (kt(),
          (async function () {
            if ((n(9, ($ = {})), j.serverip))
              try {
                let t = j.serverip + "/iotm/ver.json";
                console.log("url", t);
                let e = await fetch(t, { mode: "cors", method: "GET" });
                e.ok
                  ? (n(9, ($ = await e.json())),
                    n(9, ($ = $[L.bn])),
                    n(10, (l = L.bver)),
                    console.log(JSON.stringify($)))
                  : (n(10, (l = void 0)),
                    console.log(
                      "error, versions list not received",
                      e.statusText
                    ));
              } catch (t) {
                n(10, (l = void 0)),
                  console.log("error, versions list not received"),
                  console.log(t);
              }
            else console.log("error, server missing");
          })(),
          n(8, (v.system = !0), v)),
        "/profile|" === D &&
        Z.flashProfileJson &&
        (kt(), n(8, (v.profile = !0), v), await lt(), await it());
    }
    const lt = async () => {
      try {
        let t = await fetch(
          "http://" + t[0].ip,
          { mode: "cors", method: "GET" }
        );
        t.ok
          ? (n(23, (B = await t.json())), n(23, (B = B.message)))
          : console.log("error", t.statusText);
      } catch (t) {
        console.log("error", t);
      }
    },
      it = async () => {
        try {
          const t = un.get("token_iotm2");
          let e = await fetch(
            "http://" + t[0].ip,
            {
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${t}`,
              },
              mode: "cors",
              method: "GET",
            }
          );
          e.ok
            ? (n(24, (R = await e.json())), n(24, (R = R.message)), await ct())
            : console.log("error", e.statusText);
        } catch (t) {
          console.log("error", t);
        }
      },
      ct = async () => {
        n(
          24,
          (R.projectProp.platformio.default_envs =
            S.projectProp.platformio.default_envs),
          R
        );
        for (const [t, e] of Object.entries(R.modules)) {
          let n = S.modules[t];
          e.forEach((t) => {
            (t.active = !1),
              n &&
              n.forEach((e) => {
                e.path === t.path && (t.active = e.active);
              });
          });
        }
      };
    async function at() {
      n(20, (T = A)),
        uo(T),
        n(20, (T[0].status = !0), T),
        console.log("[i]", "[devlist]", "devlist overrided");
    }
    async function ut() {
      n(
        20,
        (T = (function (t, e) {
          var n = new Set(t.map((t) => t.ip));
          let s = [...t, ...e.filter((t) => !n.has(t.ip))];
          return s;
        })(T, A))
      ),
        uo(T),
        console.log("[i]", "[devlist]", "devlist combined");
    }
    function dt(t) {
      I.sort((t, e) => (t.descr < e.descr ? -1 : t.descr > e.descr ? 1 : 0)),
        n(7, (x = [])),
        Array.from(new Set(Array.from(I, ({ page: t }) => t))).forEach(
          (t, e, s) => {
            n(7, (x = [...x, JSON.parse(JSON.stringify({ page: t }))]));
          }
        ),
        x.sort((t, e) => (t.page < e.page ? -1 : t.page > e.page ? 1 : 0)),
        n(21, I),
        console.log("[3]", t, "layout sort, requested params..."),
        St(t, "/params|");
    }
    async function ft(t) {
      console.log("[i]", "collecting arrays");
      let e = !0;
      if (I.length > 0) {
        for (let s = 0; s < I.length; s++)
          if (I[s].topic === t.topic) {
            (e = !1), n(21, (I[s] = po(I[s], t)), I);
            let r = I[s].status,
              o = t.status;
            r
              ? ((r = [...r, ...o]), n(21, (I[s].status = r), I))
              : n(21, (I[s].status = o), I),
              n(21, (I[s].sent = !1), I);
          }
      } else console.log("[E]", "layoutJson missing");
      e && console.log("[E]", "topic not found ", t.topic);
    }
    function pt() {
      const t = Date.now();
      console.log("[i]", "Set Time: " + t / 1e3), St(Y, "/localt|" + t / 1e3);
    }
    let gt = null;
    async function ht() {
      if (!gt) return;
      const t = new FormData();
      t.append("file", gt);
      try {
        console.log("IP устройства:", P.ip);
        const e = await fetch(`http://${P.ip}/update`, {
          method: "POST",
          body: t,
        });
        e.ok
          ? console.log("OTA-обновление успешно отправлено")
          : console.error("Ошибка: " + e.statusText);
      } catch (t) {
        console.error("Ошибка отправки: " + t.message);
      }
    }
    function mt() {
      St(Y, "/tuoyal|" + JSON.stringify(wt())),
        (function () {
          for (let t = 0; t < k.length; t++) delete k[t].show;
        })(),
        St(Y, "/gifnoc|" + JSON.stringify(k)),
        St(Y, "/oiranecs|" + _),
        yt(),
        K();
    }
    function bt() {
      var t = Object.keys(j).length;
      console.log("[i]", "settingsJson length: " + t),
        t > 5
          ? ((function (t, e, n, s, r) {
            for (let e = 0; e < t.length; e++) {
              let s = t[e];
              for (const [t, e] of Object.entries(s))
                if ("ip" == t && e == n) {
                  s.name = r;
                  break;
                }
            }
          })(T, 0, st(Y), 0, j.name),
            n(20, T),
            St(Y, "/sgnittes|" + JSON.stringify(j)))
          : window.alert(
            "Ошибка размера settingsJson (возможно не был передан странице)"
          ),
        yt(),
        K();
    }
    function xt() {
      let t = Object.assign([], T);
      for (let e = 0; e < t.length; e++) t[e].status = !1;
      St(Y, "/tsil|" + JSON.stringify(t));
    }
    function vt() {
      St(Y, "/clean|");
    }
    function $t() {
      var t = Object.keys(j).length;
      St(Y, "/tuoyal|" + JSON.stringify(wt())),
        t > 5
          ? St(Y, "/sgnittes|" + JSON.stringify(j))
          : window.alert("Ошибка"),
        yt(),
        St(Y, "/mqtt|");
    }
    function wt() {
      let t = [];
      for (let e = 0; e < k.length; e++) {
        let n = Object.assign({}, k[e]),
          s = n.widget,
          r = !0;
        for (let e = 0; e < y.length; e++) {
          if (s === y[e].name) {
            let o = Object.assign({}, y[e]);
            if (
              ((o.page = n.page),
                (o.descr = n.descr),
                (o.topic = j.mqttPrefix + "/" + j.id + "/" + n.id),
                "nil" !== s && t.push(o),
                "chart" === o.widget && "bar" !== o.type)
            ) {
              "chart5" === o.name &&
                ((o.series = [n.series1, n.series2]),
                  console.log(o.series),
                  console.log(n)),
                "chart6" === o.name &&
                (o.series = [n.series1, n.series2, n.series3]);
              let e = {
                name: "inputDate",
                widget: "input",
                size: "small",
                color: "orange",
                type: "date",
              };
              (e.page = n.page),
                (e.topic = j.mqttPrefix + "/" + j.id + "/" + n.id + "-date"),
                (e.descr = n.descr),
                t.push(e);
            }
            r = !1;
            break;
          }
          r = !0;
        }
        r && console.log("[E]", "error, widget not found: " + s);
      }
      t.sort((t, e) => (t.descr < e.descr ? -1 : t.descr > e.descr ? 1 : 0));
      for (let e = 0; e < t.length; e++) t[e].order = e;
      return t;
    }
    function yt() {
      n(11, (w = [])),
        n(12, (y = [])),
        n(13, (k = [])),
        n(14, (_ = " ")),
        n(15, (j = {})),
        n(17, (L = {})),
        n(21, (I = [])),
        (q = {}),
        n(19, (M = {})),
        n(18, (S = {}));
      for (const [t, e] of Object.entries(v)) n(8, (v[t] = !1), v);
      kt();
    }
    function kt() {
      console.log("[i]", "parced flags cleared");
      for (const [t, e] of Object.entries(Z)) Z[t] = !1;
    }
    function _t(t, e, n) {
      St(
        t,
        "/control|" + e.substring(e.lastIndexOf("/") + 1, e.length) + "/" + n
      );
    }
    function jt() {
      var t;
      (tickerTask = setTimeout(jt, 1e3)),
        n(0, u--, u),
        d && U && ((d = !1), n(6, (b = !1)), (c = 60), n(0, (u = c))),
        n(4, (o = ((u - (t = c)) * (100 - 0)) / (0 - t) + 0)),
        u <= 0 &&
        ((function () {
          if (W) for (let t = 0; t < W.length; t++);
        })(),
          n(0, (u = c)),
          T.forEach((t) => {
            !1 === t.status || void 0 === t.status
              ? (nt(t.ws), rt(t.ws))
              : (St(t.ws, "/tst|"), Lt(t.ws, !1));
          }));
    }
    function Lt(t, e) {
      if (e) {
        J[t] && clearTimeout(J[t]), O[t] && (N[t] = Date.now() - O[t]);
        for (let e = 0; e < T.length; e++)
          T[e].ws === t && n(20, (T[e].ping = N[t]), T);
        n(20, T);
      } else
        (O[t] = Date.now()),
          (J[t] = setTimeout(() => {
            et(t, !1);
          }, 18e3));
    }
    function St(t, e) {
      W[t] && 1 === W[t].readyState && W[t].send(e);
    }
    function Mt(t) {
      T.forEach((e) => {
        !0 === e.status && St(e.ws, t);
      });
    }
    const Tt = (t) => {
      X.length >= 100 && X.shift(),
        n(30, (X = [...X, { msg: t }])),
        X.sort((t, e) => (t.time > e.time ? -1 : t.time < e.time ? 1 : 0));
    };
    function Jt() {
      Et(Y), n(26, (U = P.status));
    }
    function Ot() {
      "/list|" === D
        ? console.log("[i]", "user change dropdown on list page!!!")
        : (Jt(), yt(), G(), P.ip);
    }
    function Et(t) {
      for (let e = 0; e < T.length; e++) {
        let s = T[e];
        if (s.ws === t) {
          n(27, (P = s));
          break;
        }
      }
    }
    function Nt() {
      return (
        void 0 !== V.name &&
        void 0 !== V.ip &&
        void 0 !== V.id &&
        (n(29, (V.status = !1), V),
          n(29, (V.ws = T.length), V),
          A.push(V),
          ut(),
          tt(),
          !0)
      );
    }
    function Pt() {
      n(2, (p = r < 900));
    }
    function Dt() {
      St(Y, "/scan|");
    }
    function Ht() {
      (d = !0),
        St(Y, "/reboot|"),
        et(Y, !1),
        n(6, (b = !0)),
        n(26, (U = !1)),
        (c = 10),
        n(0, (u = c));
    }
    function At(t) {
      (d = !0),
        console.log(t),
        St(Y, "/update|" + t),
        n(6, (b = !0)),
        n(26, (U = !1)),
        (c = 20),
        n(0, (u = c));
    }
    function It() {
      console.log("[i]", "reboot svelte...");
      for (const [t, e] of Object.entries(v)) n(8, (v[t] = !1), v);
      n(6, (b = !0)),
        setTimeout(() => {
          location.reload();
        }, 1e3);
    }
    function qt(t) {
      console.log("[x]", t),
        n(17, (L[t] = 0), L),
        St(Y, '/rorre|{"' + t + '":0}');
    }
    function zt(t, e, n) {
      console.log("order: ", t, e, n);
      let s = { id: t, key: e, value: n };
      console.log(s), St(Y, "/order|" + JSON.stringify(s));
    }
    return [
      u,
      f,
      p,
      r,
      o,
      m,
      b,
      x,
      v,
      $,
      l,
      w,
      y,
      k,
      _,
      j,
      C,
      L,
      S,
      M,
      T,
      I,
      z,
      B,
      R,
      F,
      U,
      P,
      Y,
      V,
      X,
      D,
      at,
      pt,
      function (t) {
        gt = t;
      },
      ht,
      mt,
      bt,
      xt,
      vt,
      $t,
      _t,
      Mt,
      Ot,
      Nt,
      Pt,
      Dt,
      Ht,
      At,
      It,
      qt,
      zt,
      function () {
        n(3, (r = Rr.innerWidth));
      },
      function () {
        (Y = E(this)), n(28, Y), n(20, T);
      },
      () => Ot(),
      function () {
        (f = this.checked), n(1, f);
      },
      () => Pt(),
      (t, e, n) => _t(t, e, n),
      () => mt(),
      () => vt(),
      () => Ht(),
      (t, e, n) => zt(t, e, n),
      function (t) {
        (k = t), n(13, k);
      },
      function (t) {
        (_ = t), n(14, _);
      },
      () => Ht(),
      () => Dt(),
      () => bt(),
      () => $t(),
      () => bt(),
      () => Ht(),
      () => Nt(),
      (t) => Mt(t),
      () => xt(),
      () => at(),
      () => It(),
      () => bt(),
      () => Ht(),
      () => ht(),
      () => pt(),
      () => vt(),
      (t) => qt(t),
      function (t) {
        (l = t), n(10, l);
      },
      (t) => At(t),
    ];
  }
  new (class extends ut {
    constructor(t) {
      super(), at(this, t, go, lo, o, {}, null, [-1, -1, -1, -1, -1]);
    }
  })({ target: document.body, props: { name: "world" } });
})();
//# sourceMappingURL=bundle.js.map
